"""LanLens app: a small local web app (127.0.0.1 only) that the Mac app opens
in your browser. Scans, keeps watch, remembers devices and your labels."""
from __future__ import annotations

import copy
import csv
import datetime as _dt
import http.server
import io
import json
import logging
import os
import platform
import re
import secrets
import socketserver
import subprocess
import sys
import threading
import time
import traceback
import urllib.parse
import urllib.request
import webbrowser
import base64
from dataclasses import asdict
from pathlib import Path

from . import __version__, ask, datasets, insights, internet, macapp, net, security, thismac, tools
from .gear import GearMapper
from .health import Health, wifi_info
from .classify import CATEGORIES, CATEGORY_LABEL
from .output import payload, write_all
from .scanner import network_key, scan
from .store import Store, apply_labels, device_key, update_presence

HOME = Path.home() / ".lanlens"
REPORTS = Path.home() / "LanLens Reports"
INSTANCE = HOME / "server.json"
RECEIPTS = HOME / "receipts"
RECEIPT_TYPES = {".pdf": "application/pdf", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                 ".heic": "image/heic", ".gif": "image/gif", ".webp": "image/webp", ".txt": "text/plain"}
UI = Path(__file__).parent / "ui.html"
IDLE_EXIT = 900            # seconds without an open LanLens tab (and watch off) before quitting
INTERNET_EVERY = 1800      # refresh public IP / router info every 30 minutes
DEFAULT_ALERTS = {"new": True, "presence": True, "outage": True}


class App:
    def __init__(self):
        self.lock = threading.RLock()
        self.store = Store()
        self.token = secrets.token_urlsafe(24)
        self.port = 0
        self.status = {"scanning": False, "stage": "", "detail": "", "error": None}
        self.local = None
        self.net_key = None
        self.devices = []
        self.seen_before = False
        self.last_scan = None
        self.watch = {"on": False, "minutes": int(self.store.data["settings"].get("watch_minutes", 10)), "next": None}
        self.mac = {"status": "idle", "stage": "", "data": None}
        self.heartbeat = time.time()
        self.quit = threading.Event()
        self.new_since_open = []
        self.background = False
        self.health = Health()
        self.gear = GearMapper(self.store)
        self.update = {"available": None, "status": "", "error": None, "checked": None}
        self._outage_notified = False
        self.chat = []
        st = self.store.data["settings"]
        st.setdefault("alerts", dict(DEFAULT_ALERTS))
        st.setdefault("speedtest_hours", 0)
        st.setdefault("online_lookups", True)
        datasets.ONLINE = bool(st["online_lookups"])
        self.data_refresh = {"running": False, "last": None}
        self.inet = {"running": False, "data": None, "error": None}
        self._inet_at = 0.0
        self._auto_speed_at = 0.0
        self._upd_at = time.time()
        saved = security.load()
        self.sec = {"running": False, "stage": "", "error": None, "result": saved.get("last"),
                    "history": saved.get("history", [])}

    def alerts(self) -> dict:
        return {**DEFAULT_ALERTS, **(self.store.data["settings"].get("alerts") or {})}

    # ------------------------------------------------------------------
    def start_scan(self, reason: str = "manual") -> bool:
        with self.lock:
            if self.status["scanning"]:
                return False
            self.status = {"scanning": True, "stage": "Starting…", "detail": "", "error": None}
        threading.Thread(target=self._scan, args=(reason,), daemon=True).start()
        return True

    def _progress(self, msg: str):
        logging.info(msg)
        st = self.status
        if msg.startswith("Checking"):
            st["stage"], st["detail"] = "Looking for devices…", msg
        elif msg.startswith("Found"):
            st["stage"], st["detail"] = msg.split(".")[0] + ".", "Asking each device what it is…"
        elif msg.startswith("Looking closer"):
            st["stage"], st["detail"] = "Identifying quiet devices…", "Trying each brand's own discovery protocol…"
        elif msg.startswith("Done"):
            st["stage"], st["detail"] = "Finishing up…", ""

    def _scan(self, reason: str):
        try:
            local, devices = scan(progress=self._progress)
            if len(devices) <= 1:
                hint = ("If macOS asked whether LanLens may find devices on your local network, allow it: System Settings → "
                        "Privacy & Security → Local Network → turn on LanLens, then scan again."
                        if platform.system() == "Darwin" else "Check that you're connected to Wi-Fi or Ethernet.")
                raise RuntimeError(f"Only this computer was found on {local.network}. {hint}")
            key = network_key(local, devices)
            merged, seen_before = self.store.merge_scan(key, devices)
            with self.lock:
                self.local, self.net_key, self.devices, self.seen_before = local, key, merged, seen_before
                self.last_scan = _dt.datetime.now().isoformat(timespec="seconds")
            self.health.gateway = local.gateway
            labels = self.store.labels()
            changes = update_presence(self.store.presence(), merged, labels)
            self.store.save()
            for d, ev in changes:
                lab = labels.get(d.key, {})
                if lab.get("on_arrive" if ev == "arrived" else "on_leave") or lab.get("webhook"):
                    insights.run_automation(asdict(d), ev, lab)
            if changes and self.alerts()["presence"]:
                for d, ev in changes[:4]:
                    lab = labels.get(d.key, {})
                    if not lab.get("alert"):
                        continue
                    nm = lab.get("name") or d.name or d.vendor or d.ip
                    who = f"{lab['owner']} ({nm})" if lab.get("owner") else nm
                    notify(f"{who} {'is home' if ev == 'arrived' else 'left'}" if lab.get("owner")
                           else f"{who} {'came online' if ev == 'arrived' else 'went offline'}")
            new = [d for d in merged if d.new]
            if new:
                self.new_since_open.extend(device_key(d) for d in new)
                if reason == "watch" and self.alerts()["new"]:
                    names = ", ".join((self._label_name(d) or d.name or d.vendor or d.ip) for d in new[:3])
                    notify(f"New on your network: {names}" + (f" and {len(new) - 3} more" if len(new) > 3 else ""))
            self.status.update(scanning=False, stage="", detail="")
        except Exception as exc:
            logging.error("scan failed: %s", traceback.format_exc())
            self.status.update(scanning=False, stage="", detail="", error=str(exc))
        finally:
            if self.watch["on"]:
                self.watch["next"] = time.time() + self.watch["minutes"] * 60

    def _label_name(self, d):
        return (self.store.labels().get(d.key or "") or {}).get("name")

    def start_mac(self):
        with self.lock:
            if self.mac["status"] == "running":
                return
            self.mac.update(status="running", stage="Starting…")

        def work():
            try:
                data = thismac.collect(progress=lambda m: self.mac.update(stage=m))
                self.mac.update(status="done", data=data, stage="")
            except Exception:
                logging.error("this-mac failed: %s", traceback.format_exc())
                self.mac.update(status="error", stage="Couldn't read this Mac's details (see log).")
        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------------
    def view_devices(self) -> list[dict]:
        with self.lock:
            devs = copy.deepcopy(self.devices)
        apply_labels(devs, self.store.labels())
        order = {k: i for i, (k, _) in enumerate(CATEGORIES)}
        devs.sort(key=lambda d: (not d.online, order.get(d.category, 99),
                                 tuple(int(x) for x in d.ip.split(".")) if d.ip.count(".") == 3 else ()))
        out = []
        ups = self.store.up_since(self.net_key) if self.net_key else {}
        for d in devs:
            x = asdict(d)
            x["up_since"] = ups.get(d.key) if d.online else None
            x["new"] = d.new or (d.key in self.new_since_open)
            x["made_since"] = datasets.made_since(d.mac) if not d.randomized_mac else None
            x["app"] = insights.app_for(x)
            x["manual"] = insights.manual_link(d.vendor, d.model, d.type)
            x["receipts"] = self.receipts(d.key) if d.key else []
            out.append(x)
        return out

    def state(self) -> dict:
        self.heartbeat = time.time()
        devs = self.view_devices()
        scans = self.store.scans(self.net_key) if self.net_key else []
        labels = self.store.labels()
        pres = self.store.presence()
        people = []
        for d in devs:
            lab = labels.get(d["key"] or "") or {}
            if lab.get("owner"):
                p = pres.get(d["key"]) or {}
                people.append({"key": d["key"], "owner": lab["owner"], "name": d["name"] or d["type"],
                               "home": p.get("home", d["online"]), "since": p.get("since") or d["last_seen"]})
        sr = self.sec.get("result") or {}
        return {
            "people": people,
            "security": {"score": sr.get("score"), "grade": sr.get("grade"), "time": sr.get("time"),
                         "counts": sr.get("counts")} if sr else None,
            "version": __version__, "status": self.status, "last_scan": self.last_scan, "seen_before": self.seen_before,
            "network": str(self.local.network) if self.local else None,
            "interface": self.local.interface if self.local else None,
            "self_ip": self.local.ip if self.local else None, "gateway": self.local.gateway if self.local else None,
            "categories": CATEGORIES, "devices": devs, "scan_count": len(scans),
            "first_scan": scans[0]["time"] if scans else None,
            "watch": {"on": self.watch["on"], "minutes": self.watch["minutes"],
                      "next_in": max(0, int(self.watch["next"] - time.time())) if self.watch["on"] and self.watch["next"] else None},
            "mac": {"status": self.mac["status"], "stage": self.mac["stage"]},
            "platform": platform.system(),
            "health_now": self.health.data["samples"][-1] if self.health.data["samples"] else None,
            "settings": self.settings_view(),
            "update": {k: self.update[k] for k in ("available", "status", "error")},
            "gear": {"running": self.gear.status["running"], "stage": self.gear.status["stage"],
                     "error": self.gear.status["error"], "mapped": bool(self.gear.result)},
        }

    def settings_view(self) -> dict:
        app = macapp.app_path()
        st = self.store.data["settings"]
        return {"alerts": self.alerts(), "speedtest_hours": st.get("speedtest_hours", 0), "online_lookups": datasets.ONLINE,
                "start_at_login": macapp.login_item_enabled(), "has_api_key": bool(macapp.get_api_key()),
                "can_login_item": macapp.IS_MAC and macapp.in_applications(app), "is_mac": macapp.IS_MAC,
                "update_feed": bool(macapp.feed_url(st.get("update_feed"))), "update_source": st.get("update_feed") or "",
                "isp_plan": st.get("isp_plan") or {}, "digest": bool(st.get("digest")), "price_kwh": float(st.get("price_kwh") or 0.17),
                "background": self.background}

    def lan_devices(self):
        with self.lock:
            devs = copy.deepcopy(self.devices)
        apply_labels(devs, self.store.labels())
        return devs

    def ask(self, q: str) -> dict:
        scans = self.store.scans(self.net_key) if self.net_key else []
        ctx = {"devices": self.view_devices(), "network": str(self.local.network) if self.local else None,
               "first_scan": scans[0]["time"] if scans else None,
               "topology": self.gear.view(self.lan_devices()), "health": self.health.summary(24),
               "mac": self.mac.get("data"), "internet": self.inet.get("data"), "security": self.sec.get("result")}
        res = ask.answer(q, ctx, key=macapp.get_api_key())
        self.chat = (self.chat + [{"q": q, **res, "t": _dt.datetime.now().isoformat(timespec="seconds")}])[-30:]
        return res

    # ------------------------------------------------------------------
    # Internet: public IP, provider, router (UPnP), double NAT
    # ------------------------------------------------------------------
    def _gateway(self):
        if self.local and self.local.gateway:
            return self.local.gateway
        return net.default_gateway()[0]

    def refresh_internet(self) -> dict:
        pub = internet.public_info()
        router = internet.router_info(self._gateway())
        hops = None
        if not router.get("wan_ip"):
            try:
                hops = tools.traceroute("1.1.1.1", max_hops=8)["hops"]
            except Exception:
                hops = None
        nat = internet.nat_status(pub.get("ip"), router.get("wan_ip"), hops)
        try:
            dns = tools.dns_servers()
        except Exception:
            dns = []
        data = {"public": pub, "router": router, "nat": nat, "hops": hops, "dns": dns,
                "checked": _dt.datetime.now().isoformat(timespec="seconds")}
        if self.health.record_public_ip(pub.get("ip"), pub.get("isp")):
            logging.info("public IP changed to %s", pub.get("ip"))
        self.health.save()
        self.inet.update(data=data, error=None)
        self._inet_at = time.time()
        return data

    def start_internet(self) -> bool:
        with self.lock:
            if self.inet["running"]:
                return False
            self.inet["running"] = True
            self._inet_at = time.time()

        def work():
            try:
                self.refresh_internet()
            except Exception as exc:
                logging.error("internet check failed: %s", traceback.format_exc())
                self.inet["error"] = f"Couldn't check your internet connection: {exc}"[:200]
            finally:
                self.inet["running"] = False
        threading.Thread(target=work, daemon=True).start()
        return True

    # ------------------------------------------------------------------
    # Security check
    # ------------------------------------------------------------------
    def start_security(self, deep: bool = False) -> bool:
        with self.lock:
            if self.sec["running"]:
                return False
            self.sec.update(running=True, stage="Checking your router…", error=None)

        def work():
            try:
                devs = self.view_devices()
                if not devs:
                    raise RuntimeError("Scan your network first.")
                data = self.inet.get("data")
                if not data or time.time() - self._inet_at > 600:
                    data = self.refresh_internet()
                wifi = getattr(self.health, "last_wifi", None) or wifi_info()
                gw = next((d for d in devs if d.get("is_gateway") and d.get("online")), None)
                gw_https = security.admin_https(gw["ip"]) if gw and 80 in (gw.get("ports") or []) else None
                self.sec["stage"] = "Checking CISA's list of actively exploited flaws…"
                vulns = thismac.kev()
                nvd = {}
                if datasets.ONLINE:
                    cands = [d for d in devs if d.get("online") and d.get("model") and not d.get("is_self")
                             and (d.get("is_gateway") or d.get("category") in ("iot", "network", "printer", "server", "media"))][:8]
                    for i, d in enumerate(cands):
                        self.sec["stage"] = f"Looking up published vulnerabilities (NVD) {i + 1}/{len(cands)}…"
                        try:
                            nvd[d["key"]] = datasets.nvd_lookup(d["model"])
                        except Exception:
                            pass
                recalls = {}
                if datasets.ONLINE:
                    cands = [d for d in devs if d.get("online") and not d.get("is_self") and d.get("vendor")
                             and d.get("category") not in ("computer", "mobile")]
                    brands = sorted({d["vendor"].split(" (")[0] for d in cands})[:15]
                    for i, b in enumerate(brands):
                        self.sec["stage"] = f"Checking product safety recalls (CPSC) {i + 1}/{len(brands)}…"
                        try:
                            recs = datasets._recall_brand(b)
                        except Exception:
                            continue
                        for d in cands:
                            if d["vendor"].split(" (")[0] == b:
                                hits = datasets.recall_matches(d["vendor"], d.get("model"), d.get("type"), recs)
                                if hits:
                                    recalls[d["key"]] = hits
                ages = {d["key"]: d.get("made_since") for d in devs if d.get("made_since")}
                deep_ports = None
                if deep:
                    self.sec["stage"] = "Checking every port on every device…"
                    deep_ports = security.deep_scan(devs, progress=lambda m: self.sec.update(stage=m))
                res = security.evaluate(devs, data.get("router") or {}, wifi, data.get("nat"), deep_ports, vulns, gw_https, nvd,
                                        recalls, ages)
                res["kev_ok"] = vulns is not None
                security.save(res)
                self.sec["history"] = (self.sec.get("history", []) + [{"t": res["time"], "score": res["score"]}])[-200:]
                self.sec.update(result=res, running=False, stage="")
            except Exception as exc:
                logging.error("security check failed: %s", traceback.format_exc())
                self.sec.update(running=False, stage="", error=str(exc)[:300])
        threading.Thread(target=work, daemon=True).start()
        return True

    def refresh_data(self, force: bool = False) -> bool:
        if not datasets.ONLINE or self.data_refresh["running"]:
            return False
        self.data_refresh["running"] = True

        def work():
            try:
                brands = sorted({d.vendor for d in self.devices if d.vendor})
                self.data_refresh["last"] = datasets.refresh_due(brands, force=force)
                logging.info("database refresh: %s", self.data_refresh["last"])
            finally:
                self.data_refresh["running"] = False
        threading.Thread(target=work, daemon=True).start()
        return True

    def strips(self, hours: int = 24, buckets: int = 24) -> dict:
        if not self.net_key:
            return {}
        return self.store.strips(self.net_key, hours, buckets)

    # ------------------------------------------------------------------
    # Insights (apps, Matter/Thread, weak links, screen time, energy, router swap)
    # ------------------------------------------------------------------
    def insights(self) -> dict:
        devs = self.view_devices()
        st = self.store.data["settings"]
        hist = self.store.history(self.net_key) if self.net_key else {"times": [], "devices": {}}
        fps = {k: v.get("fp") for k, v in hist["devices"].items()}
        price = float(st.get("price_kwh") or 0.17)
        return {"apps": insights.apps_summary(devs), "matter": insights.matter_thread([d for d in devs if d["online"]]),
                "weak": insights.weak_connections(hist, devs), "screen": insights.screen_time(hist, devs),
                "watched_days": insights.watched_days(hist), "energy": insights.energy(devs, hist, price),
                "swap": insights.swap_status(st.get("swap"), devs, fps), "warranty": insights.warranty_due(devs, 60),
                "runs": list(reversed(insights.RUNS)), "isp_plan": st.get("isp_plan") or {}, "price_kwh": price,
                "digest": bool(st.get("digest"))}

    def receipts(self, key: str) -> list[dict]:
        folder = RECEIPTS / _safe_key(key)
        try:
            return [{"name": p.name, "size": p.stat().st_size} for p in sorted(folder.iterdir()) if p.is_file()]
        except OSError:
            return []

    def digest_text(self) -> str:
        devs = self.view_devices()
        week = (_dt.datetime.now() - _dt.timedelta(days=7)).isoformat()
        new = [d for d in devs if (d.get("first_seen") or "") >= week and not d.get("is_self")]
        h = self.health.summary(24 * 7)
        sr = self.sec.get("result") or {}
        parts = [f"{sum(1 for d in devs if d['online'])} devices online", f"{len(new)} new this week",
                 f"{len(h['outages'])} internet outage{'s' if len(h['outages']) != 1 else ''}"]
        if sr.get("grade"):
            parts.append(f"security grade {sr['grade']}")
        return "Your week: " + ", ".join(parts) + "."

    def check_update(self):
        try:
            self._upd_at = time.time()
            self.update.update(available=macapp.check_update(__version__, self.store.data["settings"].get("update_feed")), error=None,
                               checked=_dt.datetime.now().isoformat(timespec="seconds"))
        except Exception as exc:
            self.update.update(error=f"Couldn't check for updates: {exc}"[:200])

    def install_update(self):
        feed = self.update.get("available")
        if not feed:
            return

        def work():
            try:
                new = macapp.install_update(feed, progress=lambda m: self.update.update(status=m))
                self.update.update(status="Restarting into the new version…")
                macapp.relaunch_later(new)
                time.sleep(1)
                self.quit.set()
            except Exception as exc:
                logging.error("update failed: %s", traceback.format_exc())
                self.update.update(status="", error=str(exc))
        threading.Thread(target=work, daemon=True).start()

    def csv(self) -> str:
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["status", "category", "type", "name", "ip", "mac", "maker", "model", "confidence", "first_seen",
                    "last_seen", "trusted", "owner", "notes", "why", "other_names", "services", "open_ports", "warnings"])
        for d in self.view_devices():
            w.writerow(["online" if d["online"] else "offline", CATEGORY_LABEL.get(d["category"], ""), d["type"],
                        d["name"] or "", d["ip"], d["mac"] or "", d["vendor"] or "", d["model"] or "", d["confidence"],
                        d["first_seen"] or "", d["last_seen"] or "", "yes" if d["trusted"] else "", d["owner"], d["user_notes"],
                        "; ".join(d["reasons"]), ", ".join(d["hostnames"]), " ".join(d["services"]),
                        " ".join(map(str, d["ports"])), "; ".join(d["notes"])])
        return buf.getvalue()

    def tick(self, now: float | None = None):
        now = now or time.time()
        if self.watch["on"] and self.watch["next"] and now >= self.watch["next"] and not self.status["scanning"]:
            self.watch["next"] = None
            self.start_scan("watch")
        if now - self._upd_at > 24 * 3600 and not self.update.get("available"):
            self._upd_at = now
            threading.Thread(target=self.check_update, daemon=True).start()
        if now - self._inet_at > INTERNET_EVERY and not self.inet["running"]:
            self.start_internet()
        hours = int(self.store.data["settings"].get("speedtest_hours") or 0)
        if hours and now - self._auto_speed_at > 3600 and not self.health.speed["running"]:
            last = self.health.data["speedtests"][-1]["time"] if self.health.data["speedtests"] else None
            if not last or _dt.datetime.now() - _dt.datetime.fromisoformat(last) >= _dt.timedelta(hours=hours):
                self._auto_speed_at = now
                self.health.run_speed_test()
        down = bool(self.health._down_since)
        if down and not self._outage_notified:
            self._outage_notified = True
            if self.alerts()["outage"]:
                notify(f"{self.health._down_kind or 'Internet down'} — LanLens is logging the outage.")
        elif not down and self._outage_notified:
            self._outage_notified = False
            o = self.health.data["outages"][-1] if self.health.data["outages"] else None
            if o and self.alerts()["outage"]:
                mins = max(1, round((_dt.datetime.fromisoformat(o["end"]) - _dt.datetime.fromisoformat(o["start"])).total_seconds() / 60))
                notify(f"Back online after about {mins} min.")
        st = self.store.data["settings"]
        today = _dt.date.today().isoformat()
        if self.devices and st.get("reminded") != today and _dt.datetime.now().hour >= 9:
            st["reminded"] = today
            due = [w for w in insights.warranty_due(self.view_devices(), 30) if w["days_left"] in (30, 7, 1)]
            names = {d["key"]: d["name"] or d["vendor"] or d["ip"] for d in self.view_devices()}
            for w in due[:3]:
                notify(f"Warranty for {names.get(w['key'], 'a device')} ends in {w['days_left']} day{'s' if w['days_left'] != 1 else ''}.")
            if st.get("digest") and _dt.date.today().weekday() == 6 and self.devices:
                notify(self.digest_text())
            self.store.save()
        if not self.background and not self.watch["on"] and now - self.heartbeat > IDLE_EXIT and not self.status["scanning"]:
            logging.info("no open LanLens tab for a while; quitting")
            self.quit.set()

    def watch_loop(self):
        while not self.quit.is_set():
            time.sleep(2)
            self.tick()


APP: App | None = None


def _safe_key(key: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", key)[:80] or "_"


def notify(msg: str):
    logging.info("notify: %s", msg)
    if platform.system() == "Darwin":
        safe = msg.replace("\\", "").replace('"', "'")
        subprocess.run(["osascript", "-e", f'display notification "{safe}" with title "LanLens" sound name "Glass"'],
                       capture_output=True, timeout=10)


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "LanLens"

    def log_message(self, *a):
        pass

    # --- security: only our own page may call the API ---------------------
    def _host_ok(self) -> bool:
        host = (self.headers.get("Host") or "").lower()
        return host in (f"127.0.0.1:{APP.port}", f"localhost:{APP.port}")

    def _token_ok(self, qs) -> bool:
        tok = self.headers.get("X-LanLens-Token") or (qs.get("t") or [""])[0]
        return secrets.compare_digest(tok, APP.token)

    def _send(self, code: int, body, ctype="application/json", extra=None):
        b = body if isinstance(body, bytes) else (body if isinstance(body, str) else json.dumps(body)).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + ("; charset=utf-8" if ctype.startswith(("text", "application/json")) else ""))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _body(self, limit: int = 100_000) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        if not n or n > limit:
            return {}
        try:
            return json.loads(self.rfile.read(n))
        except ValueError:
            return {}

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(u.query)
        if not self._host_ok():
            return self._send(403, {"error": "forbidden"})
        if u.path == "/":
            if not self._token_ok(qs):
                return self._send(403, "<p style='font-family:sans-serif'>Open LanLens from your Applications folder.</p>", "text/html")
            page = UI.read_text().replace("__TOKEN__", APP.token).replace("__VERSION__", __version__)
            return self._send(200, page, "text/html",
                              {"Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline'; "
                                                          "script-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                                                          "connect-src 'self'; frame-ancestors 'none'"})
        if not self._token_ok(qs):
            return self._send(403, {"error": "forbidden"})
        if u.path == "/api/ping":
            return self._send(200, {"ok": True, "version": __version__})
        if u.path == "/api/state":
            return self._send(200, APP.state())
        if u.path == "/api/mac":
            if qs.get("refresh") or APP.mac["status"] == "idle":
                APP.start_mac()
            return self._send(200, {"status": APP.mac["status"], "stage": APP.mac["stage"], "data": APP.mac["data"]})
        if u.path == "/api/health":
            hours = max(1, min(24 * 14, int((qs.get("hours") or ["24"])[0])))
            return self._send(200, APP.health.summary(hours))
        if u.path == "/api/gear":
            return self._send(200, {"status": APP.gear.status, "settings": APP.gear.settings(),
                                    "result": APP.gear.view(APP.lan_devices())})
        if u.path == "/api/chat":
            return self._send(200, {"chat": APP.chat, "has_api_key": bool(macapp.get_api_key())})
        if u.path == "/api/internet":
            if qs.get("refresh") or (APP.inet["data"] is None and not APP.inet["running"]):
                APP.start_internet()
            return self._send(200, {**APP.inet, "ip_changes": APP.health.data["ip_changes"][-20:]})
        if u.path == "/api/security":
            return self._send(200, APP.sec)
        if u.path == "/api/datasets":
            return self._send(200, {"rows": datasets.status(), "online": datasets.ONLINE, **APP.data_refresh})
        if u.path == "/api/strips":
            hours = max(1, min(24 * 7, int((qs.get("hours") or ["24"])[0])))
            return self._send(200, {"hours": hours, "strips": APP.strips(hours, 24)})
        if u.path == "/api/timeline":
            key = (qs.get("key") or [""])[0]
            hours = max(1, min(24 * 10, int((qs.get("hours") or ["24"])[0])))
            if not APP.net_key or not key:
                return self._send(200, {"segments": []})
            return self._send(200, APP.store.timeline(APP.net_key, key, hours))
        if u.path == "/api/activity":
            hours = max(1, min(24 * 10, int((qs.get("hours") or ["48"])[0])))
            if not APP.net_key:
                return self._send(200, {"events": []})
            names = {d["key"]: d["name"] or d["vendor"] or d["ip"] for d in APP.view_devices()}
            return self._send(200, {"events": APP.store.activity(APP.net_key, hours, names)})
        if u.path == "/api/insights":
            return self._send(200, APP.insights())
        if u.path == "/api/isp-report.html":
            days = max(1, min(90, int((qs.get("days") or ["30"])[0])))
            page = insights.isp_report_html(APP.store.data["settings"].get("isp_plan") or {}, APP.health.summary(24 * days),
                                            APP.inet.get("data"), days)
            return self._send(200, page, "text/html", {"Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; "
                                                                                  "script-src 'unsafe-inline'"})
        if u.path == "/api/receipt":
            key, name = (qs.get("key") or [""])[0], (qs.get("name") or [""])[0]
            p = RECEIPTS / _safe_key(key) / Path(name).name
            if not key or not name or not p.is_file():
                return self._send(404, {"error": "not found"})
            ctype = RECEIPT_TYPES.get(p.suffix.lower(), "application/octet-stream")
            return self._send(200, p.read_bytes(), ctype, {"Content-Disposition": f'inline; filename="{p.name}"'})
        if u.path == "/api/export.csv":
            name = f"lanlens-{_dt.datetime.now():%Y-%m-%d}.csv"
            return self._send(200, APP.csv(), "text/csv", {"Content-Disposition": f'attachment; filename="{name}"'})
        if u.path == "/api/report.html":
            if not APP.local:
                return self._send(409, {"error": "no scan yet"})
            devs = copy.deepcopy([d for d in APP.devices if d.online])
            apply_labels(devs, APP.store.labels())
            out = REPORTS / _dt.datetime.now().strftime("%Y-%m-%d %H.%M.%S")
            paths = write_all(out, payload(APP.local, devs, APP.seen_before))
            return self._send(200, paths["report"].read_bytes(), "text/html",
                              {"Content-Disposition": f'attachment; filename="lanlens-report-{_dt.datetime.now():%Y-%m-%d}.html"'})
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        u = urllib.parse.urlparse(self.path)
        if not self._host_ok() or not self._token_ok({}):
            return self._send(403, {"error": "forbidden"})
        b = self._body(30_000_000 if u.path == "/api/receipt" else 100_000)
        if u.path == "/api/scan":
            return self._send(200, {"started": APP.start_scan()})
        if u.path == "/api/watch":
            mins = int(b.get("minutes") or APP.watch["minutes"])
            mins = max(2, min(240, mins))
            APP.watch.update(on=bool(b.get("on")), minutes=mins,
                             next=time.time() + mins * 60 if b.get("on") else None)
            APP.store.data["settings"]["watch_minutes"] = mins
            APP.store.save()
            return self._send(200, {"ok": True})
        if u.path == "/api/label":
            key = str(b.get("key") or "")
            if not key:
                return self._send(400, {"error": "missing key"})
            from .store import LABEL_FIELDS
            fields = {k: b[k] for k in LABEL_FIELDS if k in b}
            for k in ("name", "notes", "type", "owner", "purchase_date", "warranty_until", "price", "store", "on_arrive", "on_leave", "webhook"):
                if isinstance(fields.get(k), str):
                    fields[k] = fields[k].strip()[:200]
            if "alert" in fields:
                fields["alert"] = bool(fields["alert"])
            if fields.get("webhook") and not re.match(r"^https?://", fields["webhook"]):
                return self._send(400, {"error": "The web address must start with http:// or https://"})
            return self._send(200, APP.store.set_label(key, **fields))
        if u.path == "/api/forget":
            key = str(b.get("key") or "")
            if APP.net_key and key:
                APP.store.forget(APP.net_key, key)
                with APP.lock:
                    APP.devices = [d for d in APP.devices if d.key != key or d.online]
            return self._send(200, {"ok": True})
        if u.path == "/api/seen":
            APP.new_since_open = []
            with APP.lock:
                for d in APP.devices:
                    d.new = False
            return self._send(200, {"ok": True})
        if u.path == "/api/datasets/refresh":
            return self._send(200, {"started": APP.refresh_data(force=True)})
        if u.path == "/api/security/run":
            return self._send(200, {"started": APP.start_security(bool(b.get("deep")))})
        if u.path.startswith("/api/tools/"):
            return self._tool(u.path.rsplit("/", 1)[-1], b)
        if u.path == "/api/speedtest":
            return self._send(200, {"started": APP.health.run_speed_test()})
        if u.path == "/api/gear/run":
            err = APP.gear.start(b.get("seeds") or [], str(b.get("username") or ""), b.get("password") or None,
                                 bool(b.get("remember")), b.get("platform") or None, APP.lan_devices)
            return self._send(200 if not err else 400, {"error": err})
        if u.path == "/api/gear/forget":
            from .gear import delete_password
            st = APP.gear.settings()
            delete_password(APP.gear._account(st))
            APP.store.data["settings"].pop("gear", None)
            APP.store.save()
            APP.gear.result = None
            return self._send(200, {"ok": True})
        if u.path == "/api/ask":
            q = str(b.get("q") or "").strip()[:500]
            if not q:
                return self._send(400, {"error": "empty question"})
            return self._send(200, APP.ask(q))
        if u.path == "/api/settings":
            err = None
            if "start_at_login" in b:
                err = macapp.set_login_item(bool(b["start_at_login"]))
            if b.get("api_key"):
                macapp.set_api_key(str(b["api_key"]).strip())
            if b.get("clear_api_key"):
                macapp.set_api_key(None)
            st = APP.store.data["settings"]
            if "update_feed" in b:
                v = str(b["update_feed"] or "").strip()[:300]
                if v and not macapp.normalize_feed(v):
                    err = "Enter a GitHub repository like yourname/lanlens-releases, or the full https address of latest.json."
                else:
                    st["update_feed"] = v
                    APP.update.update(available=None, error=None)
            if isinstance(b.get("alerts"), dict):
                st["alerts"] = {**APP.alerts(), **{k: bool(v) for k, v in b["alerts"].items() if k in DEFAULT_ALERTS}}
            if "online_lookups" in b:
                st["online_lookups"] = datasets.ONLINE = bool(b["online_lookups"])
            if "speedtest_hours" in b and int(b["speedtest_hours"] or 0) in (0, 6, 12, 24):
                st["speedtest_hours"] = int(b["speedtest_hours"] or 0)
            APP.store.save()
            return self._send(200, {"error": err, "settings": APP.settings_view()})
        if u.path == "/api/insights/settings":
            st = APP.store.data["settings"]
            if "price_kwh" in b:
                try:
                    st["price_kwh"] = max(0.01, min(2.0, float(b["price_kwh"])))
                except (TypeError, ValueError):
                    return self._send(400, {"error": "Enter the electricity price like 0.17"})
            if isinstance(b.get("isp_plan"), dict):
                p = b["isp_plan"]
                plan = {"provider": str(p.get("provider") or "").strip()[:80]}
                for k in ("down", "up", "price"):
                    try:
                        plan[k] = float(p[k]) if str(p.get(k) or "").strip() else None
                    except (TypeError, ValueError):
                        return self._send(400, {"error": "Speeds and price must be numbers"})
                st["isp_plan"] = plan
            if "digest" in b:
                st["digest"] = bool(b["digest"])
            APP.store.save()
            return self._send(200, {"ok": True})
        if u.path == "/api/swap/start":
            hist = APP.store.history(APP.net_key) if APP.net_key else {"devices": {}}
            APP.store.data["settings"]["swap"] = insights.swap_start(APP.view_devices(), {k: v.get("fp") for k, v in hist["devices"].items()})
            APP.store.save()
            return self._send(200, {"ok": True})
        if u.path == "/api/swap/stop":
            APP.store.data["settings"].pop("swap", None)
            APP.store.save()
            return self._send(200, {"ok": True})
        if u.path == "/api/automation/test":
            key = str(b.get("key") or "")
            lab = APP.store.labels().get(key) or {}
            dev = next((d for d in APP.view_devices() if d["key"] == key), None)
            if not dev or not (lab.get("on_arrive") or lab.get("on_leave") or lab.get("webhook")):
                return self._send(400, {"error": "Save a Shortcut name or web address for this device first."})
            return self._send(200, {"started": insights.run_automation(dev, str(b.get("event") or "arrived"), lab)})
        if u.path == "/api/receipt":
            key, name = str(b.get("key") or ""), Path(str(b.get("name") or "")).name
            ext = Path(name).suffix.lower()
            if not key or not name or ext not in RECEIPT_TYPES:
                return self._send(400, {"error": "Add a PDF, photo or text file."})
            try:
                data = base64.b64decode(str(b.get("data") or ""), validate=True)
            except ValueError:
                return self._send(400, {"error": "That file couldn't be read."})
            if len(data) > 20_000_000:
                return self._send(400, {"error": "Files up to 20 MB, please."})
            folder = RECEIPTS / _safe_key(key)
            folder.mkdir(parents=True, exist_ok=True)
            (folder / name).write_bytes(data)
            return self._send(200, {"receipts": APP.receipts(key)})
        if u.path == "/api/receipt/delete":
            key, name = str(b.get("key") or ""), Path(str(b.get("name") or "")).name
            p = RECEIPTS / _safe_key(key) / name
            if key and name and p.is_file():
                p.unlink()
            return self._send(200, {"receipts": APP.receipts(key)})
        if u.path == "/api/update/check":
            APP.check_update()
            return self._send(200, {k: APP.update[k] for k in ("available", "status", "error")})
        if u.path == "/api/update/install":
            APP.install_update()
            return self._send(200, {"ok": True})
        if u.path == "/api/quit":
            self._send(200, {"ok": True})
            APP.quit.set()
            return
        return self._send(404, {"error": "not found"})


    def _tool(self, name: str, b: dict):
        try:
            if name == "ping":
                res = tools.ping(str(b.get("host") or ""), int(b.get("count") or 5))
            elif name == "traceroute":
                res = tools.traceroute(str(b.get("host") or ""))
            elif name == "dns":
                res = tools.dns_lookup(str(b.get("host") or ""), str(b.get("type") or "A"))
            elif name == "dnsbench":
                res = tools.dns_benchmark()
            elif name == "ports":
                res = tools.port_check(str(b.get("host") or ""), thorough=b.get("thorough", True) is not False)
            elif name == "wake":
                mac = str(b.get("mac") or "")
                if not mac and b.get("key"):
                    mac = next((d.mac for d in APP.devices if d.key == b["key"] and d.mac), "")
                bc = [str(APP.local.network.broadcast_address)] if APP.local else []
                res = tools.wake(mac, bc)
            else:
                return self._send(404, {"error": "not found"})
            return self._send(200, res)
        except (ValueError, RuntimeError) as exc:
            return self._send(400, {"error": str(exc)})
        except Exception as exc:
            logging.error("tool %s failed: %s", name, traceback.format_exc())
            return self._send(500, {"error": f"Something went wrong: {exc}"[:200]})


def _existing_instance() -> str | None:
    """URL of a LanLens that's already running this same version. An older
    version still running (e.g. after an update) is asked to quit instead."""
    try:
        info = json.loads(INSTANCE.read_text())
        url = f"http://127.0.0.1:{info['port']}"
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        req = urllib.request.Request(f"{url}/api/ping", headers={"X-LanLens-Token": info["token"]})
        with opener.open(req, timeout=2) as r:
            running = json.loads(r.read() or b"{}").get("version")
        if running == __version__:
            return f"{url}/?t={info['token']}"
        logging.info("LanLens %s is still running; asking it to quit so %s can start", running or "(older)", __version__)
        q = urllib.request.Request(f"{url}/api/quit", data=b"{}", method="POST",
                                   headers={"X-LanLens-Token": info["token"], "Content-Type": "application/json"})
        try:
            opener.open(q, timeout=3).read()
        except Exception:
            pass
        for _ in range(20):                      # wait up to ~10 s for it to close
            time.sleep(0.5)
            try:
                opener.open(req, timeout=1)
            except Exception:
                break
    except Exception:
        return None
    return None


def _mark_good():
    """Tell the starter this (possibly updated) code runs fine, so it keeps using it."""
    try:
        import lanlens_boot
        lanlens_boot.mark_good()
    except Exception:
        pass


def main(open_browser: bool = True, background: bool | None = None) -> int:
    if background is None:
        background = "--background" in sys.argv
    if background:
        open_browser = False
    global APP
    HOME.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("zeroconf").setLevel(logging.CRITICAL)
    existing = _existing_instance()
    if existing:
        logging.info("LanLens is already running; opening it")
        if open_browser:
            webbrowser.open(existing)
        _mark_good()
        return 0
    logging.info("LanLens %s starting (python %s, %s)", __version__, sys.version.split()[0], platform.platform())
    APP = App()
    APP.background = background
    if background:
        APP.watch.update(on=True, next=time.time() + APP.watch["minutes"] * 60)

    class S(socketserver.ThreadingMixIn, http.server.HTTPServer):
        daemon_threads = True
        allow_reuse_address = True
    srv = S(("127.0.0.1", 0), Handler)
    APP.port = srv.server_address[1]
    INSTANCE.write_text(json.dumps({"port": APP.port, "token": APP.token, "pid": os.getpid()}))
    try:
        os.chmod(INSTANCE, 0o600)
    except OSError:
        pass
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    _mark_good()
    threading.Thread(target=APP.watch_loop, daemon=True).start()
    threading.Thread(target=APP.health.monitor, args=(APP.quit,), daemon=True).start()
    threading.Thread(target=APP.check_update, daemon=True).start()
    APP.start_internet()
    APP.refresh_data()
    menubar = macapp.start_menubar()
    url = f"http://127.0.0.1:{APP.port}/?t={APP.token}"
    logging.info("app page: http://127.0.0.1:%s/", APP.port)
    APP.start_scan("open")
    if open_browser:
        webbrowser.open(url)
    try:
        APP.quit.wait()
    except KeyboardInterrupt:
        pass
    srv.shutdown()
    APP.health.save()
    if menubar:
        try:
            menubar.terminate()
        except Exception:
            pass
    try:
        INSTANCE.unlink()
    except OSError:
        pass
    logging.info("LanLens closed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
