"""Insights built from what LanLens already knows about your devices:

* which app controls each device
* Matter / Thread readiness
* weak connections (drop-outs and slow responses)
* screen time for TVs and consoles (time online, not what's watched)
* always-on energy estimate
* router-swap / moving checklist
* internet-provider evidence report
* warranty reminders and arrival/departure automations
"""
from __future__ import annotations

import datetime as _dt
import html
import json
import logging
import platform
import re
import statistics
import subprocess
import threading
import urllib.request

# ---------------------------------------------------------------------------
# Which app controls what
# ---------------------------------------------------------------------------
# (pattern on "maker type model services", app name). First match wins.
APPS = [
    (r"\bring\b", "Ring"), (r"\bblink\b", "Blink"), (r"\barlo\b", "Arlo"), (r"\bwyze\b", "Wyze"), (r"\beufy\b|anker", "eufy Security"),
    (r"amcrest", "Amcrest View Pro"), (r"reolink", "Reolink"), (r"\bnest\b|google nest|chromecast|google home|googlecast|google cast|\bgoogle\b", "Google Home"),
    (r"fire ?tv|amzn-wplay", "Fire TV app / Alexa"), (r"\becho\b|alexa|\bamazon\b", "Alexa"), (r"philips hue|\bhue\b|signify", "Philips Hue"),
    (r"\btapo\b", "Tapo"), (r"tp-?link|kasa", "Kasa"), (r"tuya|smart life|gosund|teckin|treatlife|globe", "Smart Life"),
    (r"sonos", "Sonos"), (r"\broku\b", "Roku"), (r"samsung.*(tv|television)|smartthings|physical graph", "SmartThings"),
    (r"\blg\b.*(tv|webos)|lg electronics|thinq", "LG ThinQ"), (r"ecobee", "ecobee"), (r"netatmo", "Netatmo"), (r"shelly", "Shelly"),
    (r"irobot|roomba", "iRobot Home"), (r"roborock", "Roborock"), (r"\bxbox\b|microsoft.*console", "Xbox"),
    (r"playstation|sony interactive", "PlayStation App"), (r"nintendo", "Nintendo Switch Parental Controls"),
    (r"synology", "Synology"), (r"\bqnap\b", "QNAP Qfinder"), (r"\bhp\b|hewlett", "HP Smart"), (r"brother", "Brother Mobile Connect"),
    (r"epson", "Epson Smart Panel"), (r"canon", "Canon PRINT"), (r"withings", "Withings Health Mate"), (r"lifx", "LIFX"),
    (r"nanoleaf", "Nanoleaf"), (r"govee", "Govee Home"), (r"meross", "Meross"), (r"belkin|wemo", "Wemo"), (r"\beero\b", "eero"),
    (r"orbi", "Orbi"), (r"netgear", "Nighthawk"), (r"ubiquiti|unifi", "UniFi"), (r"\bmyq\b|chamberlain", "myQ"),
    (r"august|yale", "August / Yale Access"), (r"rachio", "Rachio"), (r"homekit|_hap\.", "Apple Home"),
    (r"apple tv|homepod|audioaccessory", "Apple Home"), (r"matter", "Any Matter app (Apple Home, Google Home, Alexa, SmartThings)"),
]
_SKIP_APPS = ("computer", "mobile")


def app_for(d: dict) -> str | None:
    if d.get("category") in _SKIP_APPS or d.get("is_self"):
        return None
    text = " ".join(str(x) for x in [d.get("vendor"), d.get("vendor_org"), d.get("type"), d.get("model"),
                                     " ".join(d.get("services") or []), (d.get("identity") or {}).get("Built on", "")]).lower()
    if d.get("is_gateway") or d.get("category") == "network":
        for pat, app in ((r"tp-?link", "TP-Link Deco / Tether"), (r"\beero\b|amazon", "eero"), (r"google|nest", "Google Home"),
                         (r"netgear", "Nighthawk / Orbi"), (r"asus", "ASUS Router"), (r"linksys", "Linksys"),
                         (r"ubiquiti|unifi", "UniFi"), (r"arris|commscope|technicolor|sagemcom|xfinity|comcast", "Your provider's app")):
            if re.search(pat, text):
                return app
    for pat, app in APPS:
        if re.search(pat, text):
            return app
    return None


def apps_summary(devs: list[dict]) -> list[dict]:
    by: dict[str, list] = {}
    for d in devs:
        a = app_for(d)
        if a:
            by.setdefault(a, []).append(d["key"])
    return sorted(({"app": a, "devices": ks, "count": len(ks)} for a, ks in by.items()), key=lambda x: -x["count"])


# ---------------------------------------------------------------------------
# Matter / Thread readiness
# ---------------------------------------------------------------------------
def matter_thread(devs: list[dict]) -> dict:
    hubs, controllers, matter = [], [], []
    for d in devs:
        svc = " ".join(d.get("services") or [])
        if "_meshcop._udp" in svc or "_trel._udp" in svc:
            hubs.append(d["key"])
        if "_matterd._udp" in svc:
            controllers.append(d["key"])
        if "_matter._tcp" in svc or "_matterc._udp" in svc:
            matter.append(d["key"])
    advice = []
    if hubs:
        advice.append(f"You have {len(hubs)} Thread hub{'s' if len(hubs) > 1 else ''}: battery sensors and locks that use Thread can join "
                      "without extra bridges.")
    else:
        advice.append("No Thread hub found. A HomePod mini, Apple TV 4K, recent Nest Hub or Echo (4th gen) adds one, "
                      "which Thread sensors and locks need.")
    if controllers:
        advice.append(f"{len(controllers)} device{'s' if len(controllers) > 1 else ''} can add Matter devices to your home.")
    if matter:
        advice.append(f"{len(matter)} Matter device{'s' if len(matter) > 1 else ''} found. They can be shared between Apple Home, "
                      "Google Home, Alexa and SmartThings at the same time.")
    return {"thread_hubs": hubs, "controllers": controllers, "matter_devices": matter, "advice": advice}


# ---------------------------------------------------------------------------
# History-based insights
# ---------------------------------------------------------------------------
def _pts(times: list[str]) -> list[_dt.datetime]:
    return [_dt.datetime.fromisoformat(t) for t in times]


def weak_connections(hist: dict, devs: list[dict], hours: int = 24) -> list[dict]:
    """Devices that keep dropping off or answer slowly. Phones and laptops are left out: they sleep normally."""
    times = hist["times"]
    cutoff = (_dt.datetime.now() - _dt.timedelta(hours=hours)).isoformat()
    recent = [t for t in times if t >= cutoff]
    out = []
    for d in devs:
        if d.get("is_self") or d.get("category") in ("mobile", "computer"):
            continue
        rec = hist["devices"].get(d["key"])
        if not rec or not recent:
            continue
        seen = rec["seen"]
        states = [t in seen for t in recent]
        if not any(states):
            continue
        drops = sum(1 for a, b in zip(states, states[1:]) if a and not b)
        rtts = [v for t, v in rec.get("rtt", []) if t >= cutoff]
        med = round(statistics.median(rtts), 1) if rtts else None
        p90 = round(sorted(rtts)[int(len(rtts) * 0.9) - 1 if len(rtts) > 1 else 0], 1) if rtts else None
        level = "weak" if drops >= 3 or (p90 or 0) > 200 else "fair" if drops >= 1 or (p90 or 0) > 100 else "good"
        why = []
        if drops:
            why.append(f"dropped off {drops} time{'s' if drops > 1 else ''} in {hours} h")
        if p90 and p90 > 100:
            why.append(f"slow answers (up to {round(p90)} ms)")
        out.append({"key": d["key"], "drops": drops, "rtt_median": med, "rtt_p90": p90, "level": level, "why": why})
    rank = {"weak": 0, "fair": 1, "good": 2}
    return sorted(out, key=lambda x: (rank[x["level"]], -x["drops"], -(x["rtt_p90"] or 0)))


def _online_hours_by_day(times: list[str], seen: set, days: int = 7) -> list[dict]:
    pts = _pts(times)
    today = _dt.date.today()
    start = today - _dt.timedelta(days=days - 1)
    watched = {t[:10] for t in times}
    hours = {start + _dt.timedelta(days=i): 0.0 for i in range(days)}
    for (t, raw), nxt in zip(zip(pts, times), pts[1:] + [_dt.datetime.now()]):
        if raw in seen and t.date() >= start:
            gap = min((nxt - t).total_seconds(), 1800) / 3600     # count at most 30 min per scan
            hours[t.date()] = hours.get(t.date(), 0) + gap
    return [{"date": d.isoformat(), "hours": round(h, 1) if d.isoformat() in watched else None} for d, h in hours.items()]


def screen_time(hist: dict, devs: list[dict], days: int = 7) -> list[dict]:
    out = []
    for d in devs:
        kind = f"{d.get('type')} {d.get('model')}".lower()
        if not re.search(r"\btv\b|television|console|xbox|playstation|nintendo|roku|fire ?tv|apple tv|chromecast|streaming|stream", kind):
            continue
        rec = hist["devices"].get(d["key"])
        if not rec:
            continue
        by_day = _online_hours_by_day(hist["times"], rec["seen"], days)
        known = [x["hours"] for x in by_day if x["hours"] is not None]
        if not known:
            continue
        out.append({"key": d["key"], "days": by_day, "avg": round(sum(known) / len(known), 1)})
    return sorted(out, key=lambda x: -x["avg"])


def watched_days(hist: dict, days: int = 7) -> int:
    since = (_dt.date.today() - _dt.timedelta(days=days - 1)).isoformat()
    return len({t[:10] for t in hist["times"] if t[:10] >= since})


# ---------------------------------------------------------------------------
# Always-on energy estimate
# ---------------------------------------------------------------------------
# Typical power while connected and idle/standby (watts). Rough by design.
WATTS = [
    (r"nas|network storage|server", 25), (r"console|xbox|playstation", 10), (r"router|gateway", 10),
    (r"access point|mesh|extender|switch|network", 7), (r"smart display|hub|nest hub|echo show", 4),
    (r"printer", 3), (r"camera|doorbell", 3), (r"chime", 1.5), (r"speaker|echo|homepod|sonos|google home|nest mini", 3),
    (r"fire tv|roku|chromecast|apple tv|stream", 2.5), (r"\btv\b|television", 1.5), (r"thermostat", 2),
    (r"plug|switch|outlet", 0.8), (r"light|bulb|lamp", 0.4), (r"vacuum", 3), (r"appliance|washer|dryer|fridge|oven", 2),
]


def energy(devs: list[dict], hist: dict, price_kwh: float = 0.17) -> dict:
    items = []
    times = hist["times"]
    week = (_dt.datetime.now() - _dt.timedelta(days=7)).isoformat()
    recent = [t for t in times if t >= week]
    for d in devs:
        if d.get("is_self") or d.get("category") in ("mobile", "computer"):
            continue
        text = f"{d.get('type')} {d.get('model')} {d.get('vendor')}".lower()
        if d.get("is_gateway"):
            text = "router " + text
        w = next((w for pat, w in WATTS if re.search(pat, text)), 2.0)
        rec = hist["devices"].get(d["key"])
        frac = (sum(1 for t in recent if t in rec["seen"]) / len(recent)) if rec and recent else (1.0 if d.get("online") else 0.0)
        kwh = w * frac * 8760 / 1000
        items.append({"key": d["key"], "watts": w, "online_share": round(frac, 2), "kwh_year": round(kwh, 1),
                      "cost_year": round(kwh * price_kwh, 2)})
    items.sort(key=lambda x: -x["kwh_year"])
    total_w = round(sum(i["watts"] * i["online_share"] for i in items), 1)
    kwh = round(sum(i["kwh_year"] for i in items))
    return {"total_watts": total_w, "kwh_year": kwh, "cost_year": round(kwh * price_kwh), "price_kwh": price_kwh, "items": items}


# ---------------------------------------------------------------------------
# Router swap / moving checklist
# ---------------------------------------------------------------------------
def swap_start(devs: list[dict], fingerprints: dict) -> dict:
    week = (_dt.datetime.now() - _dt.timedelta(days=7)).isoformat()
    base = [{"key": d["key"], "mac": d.get("mac"), "fp": fingerprints.get(d["key"]), "maker": d.get("vendor") or ("Private Wi-Fi address" if d.get("randomized_mac") else None),
             "name": d.get("name"), "type": d.get("type"), "ip": d.get("ip")}
            for d in devs if not d.get("is_self") and (d.get("online") or (d.get("last_seen") or "") >= week)]
    return {"started": _dt.datetime.now().isoformat(timespec="seconds"), "baseline": base}


def swap_status(swap: dict | None, devs: list[dict], fingerprints: dict) -> dict | None:
    if not swap:
        return None
    started = swap["started"]
    back, missing = [], []
    for b in swap["baseline"]:
        hit = next((d for d in devs if (d.get("last_seen") or "") >= started and
                    (d["key"] == b["key"] or (b.get("mac") and d.get("mac") == b["mac"]) or
                     (b.get("fp") and fingerprints.get(d["key"]) == b["fp"]))), None)
        (back if hit else missing).append({**b, "now": hit["key"] if hit else None})
    return {"started": started, "back": back, "missing": missing, "total": len(swap["baseline"])}


# ---------------------------------------------------------------------------
# Internet-provider evidence report (printable; "Save as PDF" from the browser)
# ---------------------------------------------------------------------------
def isp_report_html(plan: dict, h: dict, inet: dict | None, days: int = 30) -> str:
    e = html.escape
    sp = [x for x in h.get("speedtests", []) if x.get("down_mbps") is not None]
    cutoff = (_dt.datetime.now() - _dt.timedelta(days=days)).isoformat()
    sp = [x for x in sp if x["time"] >= cutoff]
    down_plan = float(plan.get("down") or 0) or None
    up_plan = float(plan.get("up") or 0) or None
    downs = [x["down_mbps"] for x in sp]
    below = [x for x in sp if down_plan and x["down_mbps"] < 0.8 * down_plan]
    outs = h.get("outages", [])
    mins = sum(((_dt.datetime.fromisoformat(o["end"]) if o.get("end") else _dt.datetime.now())
                - _dt.datetime.fromisoformat(o["start"])).total_seconds() / 60 for o in outs)
    pub = (inet or {}).get("public") or {}
    def pct(v):
        return f"{round(100 * v / down_plan)}% of plan" if down_plan and v is not None else ""
    rows = "".join(f"<tr><td>{e(_dt.datetime.fromisoformat(x['time']).strftime('%b %d, %Y %I:%M %p'))}</td><td>{x['down_mbps']}</td>"
                   f"<td>{x.get('up_mbps') if x.get('up_mbps') is not None else ''}</td><td>{x.get('latency_ms', '')}</td><td>{pct(x['down_mbps'])}</td></tr>"
                   for x in reversed(sp)) or "<tr><td colspan=5>No speed tests in this period.</td></tr>"
    orows = "".join(f"<tr><td>{e(_dt.datetime.fromisoformat(o['start']).strftime('%b %d, %Y %I:%M %p'))}</td>"
                    f"<td>{e(_dt.datetime.fromisoformat(o['end']).strftime('%I:%M %p')) if o.get('end') else 'ongoing'}</td><td>{e(o.get('kind', ''))}</td>"
                    f"<td>{max(1, round(((_dt.datetime.fromisoformat(o['end']) if o.get('end') else _dt.datetime.now()) - _dt.datetime.fromisoformat(o['start'])).total_seconds() / 60))} min</td></tr>"
                    for o in reversed(outs)) or "<tr><td colspan=4>No outages recorded.</td></tr>"
    med = round(statistics.median(downs)) if downs else None
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>Internet service report</title>
<style>body{{font:14px/1.5 -apple-system,Helvetica,Arial,sans-serif;color:#19203A;max-width:820px;margin:32px auto;padding:0 20px}}
h1{{font-size:24px;margin:0 0 4px}}h2{{font-size:16px;margin:24px 0 8px}}table{{width:100%;border-collapse:collapse;font-size:13px}}
td,th{{text-align:left;padding:6px 8px;border-bottom:1px solid #E3E7F3}}th{{color:#6B7393;font-weight:600}}
.kpis{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:16px 0}}.k{{border:1px solid #E3E7F3;border-radius:10px;padding:10px 12px}}
.k b{{display:block;font-size:22px}}.muted{{color:#6B7393;font-size:12.5px}}button{{font:inherit;padding:8px 14px;border-radius:8px;border:1px solid #2F6BFF;background:#2F6BFF;color:#fff;cursor:pointer}}
@media print{{button{{display:none}}body{{margin:0}}}}</style></head><body>
<button onclick="window.print()">Print or save as PDF</button>
<h1>Internet service report</h1>
<div class="muted">Generated {e(_dt.datetime.now().strftime('%B %d, %Y'))} by LanLens · last {days} days · {e(plan.get('provider') or pub.get('isp') or 'Internet provider')}{' · public IP ' + e(pub['ip']) if pub.get('ip') else ''}</div>
<h2>Plan</h2><p>{e(plan.get('provider') or 'Provider not set')}: {e(str(plan.get('down') or '?'))} Mbps down / {e(str(plan.get('up') or '?'))} Mbps up{(' · $' + e(str(plan.get('price'))) + '/month') if plan.get('price') else ''}</p>
<div class="kpis"><div class="k"><span class="muted">Speed tests</span><b>{len(sp)}</b></div>
<div class="k"><span class="muted">Median download</span><b>{med if med is not None else '—'} Mbps</b><span class="muted">{pct(med) if med is not None else ''}</span></div>
<div class="k"><span class="muted">Tests below 80% of plan</span><b>{len(below)}{f' of {len(sp)}' if sp else ''}</b></div>
<div class="k"><span class="muted">Outages</span><b>{len(outs)}</b><span class="muted">{round(mins)} min total</span></div></div>
<p class="muted">Internet reachability is checked every minute while LanLens runs ({e(str(h.get('samples', 0)))} checks; monitoring since {e(_dt.datetime.fromisoformat(h['monitoring_since']).strftime('%b %d, %Y') if h.get('monitoring_since') else 'n/a')}). Uptime in this period: {h.get('uptime_pct', '—')}%. Speeds are measured on this Mac's connection; tests over Wi-Fi can be lower than the line speed, so tests on Ethernet make the strongest evidence.</p>
<h2>Speed tests</h2><table><tr><th>When</th><th>Download (Mbps)</th><th>Upload (Mbps)</th><th>Latency (ms)</th><th>vs plan</th></tr>{rows}</table>
<h2>Outages</h2><table><tr><th>Started</th><th>Ended</th><th>What</th><th>Lasted</th></tr>{orows}</table>
<p class="muted" style="margin-top:24px">Upload plan {e(str(up_plan or '?'))} Mbps. Measurements: Cloudflare speed test servers; reachability to 1.1.1.1, 8.8.8.8 and 9.9.9.9.</p>
</body></html>"""


# ---------------------------------------------------------------------------
# Warranty reminders
# ---------------------------------------------------------------------------
def warranty_due(devs: list[dict], days: int = 30) -> list[dict]:
    today = _dt.date.today()
    out = []
    for d in devs:
        w = (d.get("extra") or {}).get("warranty_until")
        try:
            end = _dt.date.fromisoformat(w) if w else None
        except ValueError:
            end = None
        if end and end - today <= _dt.timedelta(days=days):
            out.append({"key": d["key"], "until": end.isoformat(), "days_left": (end - today).days})
    return sorted(out, key=lambda x: x["days_left"])


def manual_link(maker: str | None, model: str | None, kind: str | None) -> str | None:
    if not maker or maker in ("Unknown maker", "Private Wi-Fi address"):
        return None
    thing = model or re.sub(re.escape(maker), "", kind or "", flags=re.I).strip(" /-") or None
    q = " ".join(filter(None, [maker, thing, "manual"]))
    return "https://duckduckgo.com/?q=" + urllib.request.quote(q)


# ---------------------------------------------------------------------------
# Arrival / departure automations
# ---------------------------------------------------------------------------
RUNS: list[dict] = []
_runs_lock = threading.Lock()


def _log_run(entry: dict) -> None:
    with _runs_lock:
        RUNS.append(entry)
        del RUNS[:-30]


def run_automation(device: dict, event: str, label: dict) -> list[str]:
    """Run the Shortcut and/or call the web address set for this device's arrive/leave event (in the background)."""
    started = []
    shortcut = label.get("on_arrive" if event == "arrived" else "on_leave")
    hook = label.get("webhook")
    name = label.get("name") or device.get("name") or device.get("vendor") or device.get("ip")
    ts = _dt.datetime.now().isoformat(timespec="seconds")

    def go_shortcut():
        if platform.system() != "Darwin":
            _log_run({"t": ts, "key": device.get("key"), "what": f"Shortcut “{shortcut}”", "ok": False, "detail": "Shortcuts need macOS"})
            return
        try:
            r = subprocess.run(["shortcuts", "run", shortcut], capture_output=True, text=True, timeout=120)
            _log_run({"t": ts, "key": device.get("key"), "what": f"Shortcut “{shortcut}”", "ok": r.returncode == 0,
                      "detail": (r.stderr or r.stdout or "").strip()[:200]})
        except Exception as exc:
            _log_run({"t": ts, "key": device.get("key"), "what": f"Shortcut “{shortcut}”", "ok": False, "detail": str(exc)[:200]})

    def go_hook():
        body = json.dumps({"event": event, "device": name, "maker": device.get("vendor"), "type": device.get("type"),
                           "ip": device.get("ip"), "time": ts, "source": "LanLens"}).encode()
        try:
            req = urllib.request.Request(hook, data=body, method="POST", headers={"Content-Type": "application/json", "User-Agent": "LanLens"})
            with urllib.request.urlopen(req, timeout=15) as r:
                _log_run({"t": ts, "key": device.get("key"), "what": "Web address", "ok": 200 <= r.status < 300, "detail": f"HTTP {r.status}"})
        except Exception as exc:
            _log_run({"t": ts, "key": device.get("key"), "what": "Web address", "ok": False, "detail": str(exc)[:200]})

    if shortcut:
        threading.Thread(target=go_shortcut, daemon=True).start()
        started.append("shortcut")
    if hook and re.match(r"^https?://", hook):
        threading.Thread(target=go_hook, daemon=True).start()
        started.append("webhook")
    if started:
        logging.info("automation for %s (%s): %s", name, event, ", ".join(started))
    return started
