"""Security check for the whole network, with a score and a to-do list.

Uses only what LanLens can see without logging in to anything:
* your router: UPnP, ports it has opened to the internet, how its admin page
  is served, risky services (Telnet, FTP)
* your Wi-Fi's encryption (from this Mac's connection)
* every device's open ports (quick check from each scan, or the thorough check)
* CISA's list of actively exploited flaws, matched to device makers and models
"""
from __future__ import annotations

import concurrent.futures as cf
import datetime as _dt
import json
import re
from pathlib import Path

from . import tools
from .probes import _open

SAVED = Path.home() / ".lanlens" / "security.json"
WEIGHT = {"high": 15, "medium": 6, "low": 2, "info": 0}
DEVICE_PORTS_CAP = 30      # open ports on individual devices can cost at most this many points in total
SEV_ORDER = {"high": 0, "medium": 1, "low": 2, "info": 3}
RISKY_FORWARD = {21, 22, 23, 80, 139, 445, 554, 3389, 5900, 8080, 5555, 2375}


def now_iso() -> str:
    return _dt.datetime.now().isoformat(timespec="seconds")


def _norm(s: str | None) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def kev_for(vendor: str | None, model: str | None, vulns: list[dict] | None) -> list[dict]:
    """Actively exploited flaws CISA lists for this maker + product (product name must appear in the model)."""
    if not vulns or not vendor or not model:
        return []
    v, m = _norm(vendor), _norm(model)
    hits = []
    for x in vulns:
        prod, vend = _norm(x.get("product")), _norm(x.get("vendorProject"))
        if len(prod) < 4 or prod in ("multiple products", "multiple routers", "firmware", "routers", "router"):
            continue
        if not vend or not (v.startswith(vend.split()[0]) or vend.startswith(v.split()[0])):
            continue
        if re.search(rf"\b{re.escape(prod)}\b", m):
            hits.append(x)
    return hits


def wifi_finding(wifi: dict | None) -> dict | None:
    if not wifi or wifi.get("wired"):
        return None
    sec = (wifi.get("security") or "").lower()
    name = wifi.get("ssid") or "Your Wi-Fi"
    if not sec:
        return None
    if sec in ("none", "open") or "none" in sec:
        return {"severity": "high", "area": "wifi", "title": f"{name} has no password",
                "detail": "Anyone nearby can join and see unencrypted traffic.",
                "fix": "In your router's Wi-Fi settings, choose WPA2 or WPA3 Personal and set a long password."}
    if "wep" in sec:
        return {"severity": "high", "area": "wifi", "title": f"{name} uses WEP encryption",
                "detail": "WEP can be cracked in minutes.", "fix": "Switch to WPA2 or WPA3 Personal in your router."}
    if re.search(r"\bwpa\b(?!2|3)|wpa personal|tkip", sec) and "wpa2" not in sec and "wpa3" not in sec:
        return {"severity": "high", "area": "wifi", "title": f"{name} uses old WPA encryption",
                "detail": "The original WPA (TKIP) is broken.", "fix": "Switch to WPA2 or WPA3 Personal in your router."}
    if "wpa3" in sec:
        return {"severity": "ok", "area": "wifi", "title": f"{name} uses WPA3, the newest Wi-Fi encryption"}
    if "wpa2" in sec:
        return {"severity": "ok", "area": "wifi", "title": f"{name} uses WPA2 encryption",
                "detail": "Good. If all your devices support it, WPA3 (or WPA2/WPA3 mixed) is even better."}
    return None


def admin_https(ip: str) -> bool | None:
    """Does the router's web page on port 80 send you to HTTPS?"""
    try:
        with _open(f"http://{ip}/", timeout=3) as r:
            return r.geturl().startswith("https")
    except Exception:
        return None


def device_findings(d: dict, ports: list[int], vulns) -> list[dict]:
    out = []
    nm = d.get("name") or d.get("vendor") or d.get("ip")
    cat = d.get("category")
    issues, names = [], []
    sev = None
    for p in ports:
        name, risk, note = tools.SERVICES.get(p, (None, None, ""))
        if not risk or (p in (80, 8080, 8000, 8081, 81, 8888, 9000) and cat not in ("iot", "network", "printer", "media")):
            continue
        if p in (445, 139, 548, 3389, 5900, 22) and cat in ("computer", "server"):
            risk = "low" if p != 3389 else "medium"
        if p in (80, 8080, 81) and d.get("is_gateway"):
            continue                                         # handled by the router check
        issues.append(f"{name} (port {p}): {note}")
        names.append(name)
        sev = risk if sev is None or SEV_ORDER[risk] < SEV_ORDER[sev] else sev
    if issues:
        shown = list(dict.fromkeys(names))
        out.append({"severity": sev, "area": "device", "device": d.get("key"),
                    "title": f"{nm}: {', '.join(shown[:3])}{' and more' if len(shown) > 3 else ''} open",
                    "detail": " · ".join(issues),
                    "fix": "Turn off services you don't use in the device's settings or app, and change default passwords."})
    hits = kev_for(d.get("vendor") or (d.get("upnp") or {}).get("manufacturer"), d.get("model"), vulns)
    if hits:
        cves = ", ".join(h.get("cveID", "") for h in sorted(hits, key=lambda h: h.get("dateAdded", ""), reverse=True)[:3])
        out.append({"severity": "medium", "area": "device", "device": d.get("key"),
                    "title": f"{nm}: model has actively exploited flaws on record",
                    "detail": f"CISA lists {len(hits)} actively exploited vulnerabilit{'ies' if len(hits) > 1 else 'y'} for "
                              f"{d.get('model')} ({cves}). Older firmware is the usual way in.",
                    "fix": "Install the latest firmware from the maker's app or website. If the device is no longer "
                           "supported, plan to replace it."})
    return out


def evaluate(devices: list[dict], router: dict, wifi: dict | None, nat: dict | None,
             deep_ports: dict | None = None, vulns: list[dict] | None = None, gw_https: bool | None = None,
             nvd: dict | None = None, recalls: dict | None = None, ages: dict | None = None) -> dict:
    """Pure function: findings + score from what's already been collected."""
    deep_ports = deep_ports or {}
    findings: list[dict] = []
    passed: list[str] = []
    online = [d for d in devices if d.get("online")]
    by_ip = {d["ip"]: d for d in online}
    gw = next((d for d in online if d.get("is_gateway")), None)

    # --- router -------------------------------------------------------------
    if gw:
        gports = deep_ports.get(gw["key"], gw.get("ports") or [])
        gname = router.get("model") or gw.get("name") or "Your router"
        if router.get("upnp"):
            fw = [f for f in router.get("forwards", []) if f.get("enabled", True)]
            if fw:
                for f in fw:
                    dev = by_ip.get(f.get("internal_ip") or "")
                    who = (dev.get("name") or dev.get("vendor") or dev["ip"]) if dev else (f.get("internal_ip") or "a device")
                    risky = int(f.get("internal_port") or 0) in RISKY_FORWARD or int(f.get("external_port") or 0) in RISKY_FORWARD
                    findings.append({"severity": "high" if risky else "low", "area": "router",
                                     "device": dev.get("key") if dev else None,
                                     "title": f"Port {f.get('external_port')}/{f.get('protocol')} is open to the internet → {who}",
                                     "detail": f"Opened automatically over UPnP" + (f" by “{f['description']}”" if f.get("description") else "")
                                               + f". Anyone on the internet can reach port {f.get('internal_port')} on this device.",
                                     "fix": "If you don't need remote access to this device, turn off UPnP on the router "
                                            "(and remove the forward), or turn off remote access in the device's app."})
            else:
                passed.append("No ports have been opened to the internet through UPnP")
            findings.append({"severity": "low", "area": "router", "title": "UPnP is turned on in the router",
                             "detail": "Any device or app on your network can open ports to the internet without asking. "
                                       "Game consoles and some video apps rely on it.",
                             "fix": "Turn off UPnP in the router settings unless a console or app needs it."})
        elif router.get("upnp") is False:
            passed.append("Router doesn't let devices open internet ports automatically (UPnP off)")
        if 23 in gports:
            findings.append({"severity": "high", "area": "router", "device": gw["key"], "title": f"{gname} has Telnet open",
                             "detail": "Telnet is an unencrypted remote login commonly attacked by botnets.",
                             "fix": "Turn off Telnet in the router's administration settings."})
        if 21 in gports:
            findings.append({"severity": "medium", "area": "router", "device": gw["key"], "title": f"{gname} has FTP file sharing on",
                             "detail": "FTP sends passwords unencrypted (often for a USB drive plugged into the router).",
                             "fix": "Turn off FTP / USB file sharing if you don't use it."})
        if 445 in gports:
            findings.append({"severity": "low", "area": "router", "device": gw["key"], "title": f"{gname} shares files (SMB)",
                             "detail": "Usually a USB drive plugged into the router.",
                             "fix": "Make sure it requires a password, or turn it off if unused."})
        if 80 in gports and 443 not in gports and gw_https is not True:
            findings.append({"severity": "medium", "area": "router", "device": gw["key"],
                             "title": "Router admin page isn't encrypted",
                             "detail": "Your router's settings page is served over plain HTTP, so its password can be read by "
                                       "anything else on your network.",
                             "fix": "Turn on HTTPS for the admin page if the router offers it, and use a strong admin password."})
        elif 443 in gports or gw_https:
            passed.append("Router admin page is available over HTTPS")
        if not {21, 23} & set(gports):
            passed.append("Router has no Telnet or FTP open")
        model = router.get("model_name") or gw.get("model")
        hits = kev_for(router.get("manufacturer") or gw.get("vendor"), model, vulns)
        if hits:
            cves = ", ".join(h.get("cveID", "") for h in sorted(hits, key=lambda h: h.get("dateAdded", ""), reverse=True)[:3])
            findings.append({"severity": "medium", "area": "router", "device": gw["key"],
                             "title": f"{gname}: this router model has actively exploited flaws on record",
                             "detail": f"CISA lists {len(hits)} for {model} ({cves}).",
                             "fix": "Update the router's firmware (in its app or admin page). If it no longer gets updates, replace it."})

    # --- Wi-Fi ----------------------------------------------------------------
    wf = wifi_finding(wifi)
    if wf:
        if wf["severity"] == "ok":
            passed.append(wf["title"])
        else:
            findings.append(wf)

    # --- devices ---------------------------------------------------------------
    for d in online:
        if d.get("is_self") or d.get("is_gateway"):
            continue
        findings += device_findings(d, deep_ports.get(d["key"], d.get("ports") or []), vulns)

    # --- published vulnerabilities (NVD) for exact models ---------------------------
    for d in online:
        n = (nvd or {}).get(d.get("key"))
        if n and n.get("recent"):
            nm = d.get("name") or d.get("vendor") or d["ip"]
            findings.append({"severity": "low", "area": "router" if d.get("is_gateway") else "device", "device": d.get("key"),
                             "title": f"{nm}: {n['recent']} published vulnerabilit{'ies' if n['recent'] > 1 else 'y'} for this model in 3 years",
                             "detail": f"NVD lists {n['total']} in total for “{d.get('model')}”; newest: {', '.join(n['latest'])}. "
                                       "Most are fixed by firmware updates.",
                             "fix": "Make sure automatic firmware updates are on, or update it from the maker's app."})

    # --- safety recalls (U.S. CPSC) -------------------------------------------------
    for d in online:
        for r in (recalls or {}).get(d.get("key"), [])[:2]:
            nm = d.get("name") or d.get("vendor") or d["ip"]
            how = "same model number" if r.get("match") == "model" else "same maker and kind of product"
            findings.append({"severity": "medium" if r.get("match") == "model" else "info", "area": "safety", "device": d.get("key"),
                             "title": f"{nm}: safety recall — {r.get('title', '')[:110]}",
                             "detail": f"Recalled {r.get('date', '')[:10]} ({how}). Hazard: {r.get('hazard') or 'see notice'}"[:400],
                             "fix": (r.get("remedy") or "Check the recall notice to see whether your unit is affected.")[:300],
                             "url": r.get("url")})

    # --- end of support ------------------------------------------------------------
    for d in online:
        if d.get("is_self"):
            continue
        eol = [x for x in kev_for(d.get("vendor"), d.get("model"), vulns)
               if re.search(r"end[- ]of[- ](life|support|service)|\beol\b|discontinue", (x.get("requiredAction", "") + " " + x.get("notes", "")).lower())]
        nm = d.get("name") or d.get("vendor") or d["ip"]
        if eol:
            findings.append({"severity": "high", "area": "router" if d.get("is_gateway") else "device", "device": d.get("key"),
                             "title": f"{nm}: no longer supported by its maker",
                             "detail": f"CISA says to stop using {d.get('model')} because it no longer gets security fixes ({eol[0].get('cveID')}).",
                             "fix": "Replace it. Until then, turn off remote access and keep it off the internet."})
            continue
        since = (ages or {}).get(d.get("key"))
        if since and since < f"{_dt.date.today().year - 9}" and (d.get("is_gateway") or d.get("category") in ("network", "iot", "printer", "media")):
            findings.append({"severity": "info", "area": "device", "device": d.get("key"),
                             "title": f"{nm}: older hardware (made in {since[:4]} or later)",
                             "detail": "Makers usually stop sending security updates 5–8 years after a product comes out.",
                             "fix": "Check the maker's app or website for recent firmware updates; replace it if updates stopped."})

    # --- housekeeping ------------------------------------------------------------
    unknown = [d for d in online if d.get("category") == "unknown" and not d.get("trusted")]
    if unknown:
        findings.append({"severity": "low", "area": "network", "title": f"{len(unknown)} device{'s' if len(unknown) > 1 else ''} LanLens couldn't identify",
                         "detail": ", ".join((d.get("name") or d.get("vendor") or d["ip"]) for d in unknown[:6]) + ("…" if len(unknown) > 6 else ""),
                         "fix": "Open each one and either name it and mark “I know this device”, or find out what it is."})
    untrusted = [d for d in online if not d.get("trusted") and not d.get("is_self")]
    if online and len(untrusted) == len([d for d in online if not d.get("is_self")]) and len(untrusted) > 3:
        findings.append({"severity": "info", "area": "network", "title": "Mark the devices you recognize",
                         "detail": "Once known devices are marked, anything new stands out right away.",
                         "fix": "Open a device and turn on “I know this device”."})
    if nat and nat.get("status") in ("double", "cgnat"):
        findings.append({"severity": "info", "area": "network", "title": nat["title"], "detail": nat["detail"], "fix": ""})

    findings.sort(key=lambda f: (SEV_ORDER.get(f["severity"], 9), f.get("area", ""), f["title"]))
    dev_pts = sum(WEIGHT.get(f["severity"], 0) for f in findings if f.get("area") == "device")
    other_pts = sum(WEIGHT.get(f["severity"], 0) for f in findings if f.get("area") != "device")
    score = max(0, 100 - other_pts - min(dev_pts, DEVICE_PORTS_CAP))
    grade = "A" if score >= 90 else "B" if score >= 80 else "C" if score >= 65 else "D" if score >= 50 else "F"
    counts = {s: sum(1 for f in findings if f["severity"] == s) for s in ("high", "medium", "low", "info")}
    return {"time": now_iso(), "score": score, "grade": grade, "counts": counts, "findings": findings, "passed": passed,
            "router": router, "nat": nat, "wifi_security": (wifi or {}).get("security"),
            "deep": bool(deep_ports), "devices_checked": len(online)}


def deep_scan(devices: list[dict], progress=lambda m: None, workers: int = 4) -> dict:
    """Thorough port check of every online device. {device_key: [open ports]}"""
    targets = [d for d in devices if d.get("online") and not d.get("is_self") and tools.is_lan(d["ip"])]
    out: dict = {}
    done = 0

    def one(d):
        try:
            return d["key"], [p["port"] for p in tools.port_check(d["ip"], thorough=True)["open"]]
        except Exception:
            return d["key"], d.get("ports") or []
    with cf.ThreadPoolExecutor(max_workers=workers) as ex:
        for k, ports in ex.map(one, targets):
            out[k] = ports
            done += 1
            progress(f"Checked {done} of {len(targets)} devices…")
    return out


def save(result: dict) -> None:
    try:
        hist = []
        if SAVED.exists():
            hist = json.loads(SAVED.read_text()).get("history", [])
        hist = (hist + [{"t": result["time"], "score": result["score"]}])[-200:]
        SAVED.parent.mkdir(parents=True, exist_ok=True)
        SAVED.write_text(json.dumps({"last": result, "history": hist}))
    except (OSError, ValueError):
        pass


def load() -> dict:
    try:
        return json.loads(SAVED.read_text())
    except (OSError, ValueError):
        return {}
