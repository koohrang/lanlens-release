"""Find the local network and every device on it (no admin rights needed).

How presence detection works: we send one tiny UDP packet to every address in
the subnet. Before the operating system can send it, it has to ask "who has
this IP?" on the local network (ARP). Every powered-on device answers that,
even if it ignores pings, so afterwards the OS's ARP table lists them all.
"""
from __future__ import annotations

import ipaddress
import platform
import re
import socket
import subprocess
import time
from dataclasses import dataclass

import psutil

from .vendors import normalize_mac

SYSTEM = platform.system()          # 'Darwin' | 'Linux' | 'Windows'


@dataclass
class LocalNet:
    interface: str
    ip: str
    network: ipaddress.IPv4Network
    mac: str | None
    gateway: str | None


def _run(cmd: list[str], timeout: float = 5) -> str:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout
    except (OSError, subprocess.SubprocessError):
        return ""


def default_gateway() -> tuple[str | None, str | None]:
    """(gateway_ip, interface)"""
    if SYSTEM == "Linux":
        try:
            with open("/proc/net/route") as fh:
                for line in fh.readlines()[1:]:
                    f = line.split()
                    if f[1] == "00000000" and int(f[3], 16) & 2:
                        gw = socket.inet_ntoa(int(f[2], 16).to_bytes(4, "little"))
                        return gw, f[0]
        except OSError:
            pass
    elif SYSTEM == "Darwin":
        out = _run(["route", "-n", "get", "default"])
        gw = re.search(r"gateway:\s*(\S+)", out)
        ifc = re.search(r"interface:\s*(\S+)", out)
        return (gw.group(1) if gw else None), (ifc.group(1) if ifc else None)
    elif SYSTEM == "Windows":
        out = _run(["route", "print", "-4", "0.0.0.0"])
        m = re.search(r"^\s*0\.0\.0\.0\s+0\.0\.0\.0\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)", out, re.M)
        if m:
            return m.group(1), m.group(2)       # interface given as its IP on Windows
    return None, None


def _primary_ip() -> str | None:
    """IP the OS would use to reach the internet (no packet is actually sent)."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("192.0.2.1", 9))
            return s.getsockname()[0]
    except OSError:
        return None


_TUNNEL = ("utun", "ipsec", "ppp", "tun", "tap", "wg", "gif", "stf", "awdl", "llw", "bridge", "docker", "veth",
           "vmnet", "vboxnet", "zt", "tailscale", "lo")


def detect(interface: str | None = None, subnet: str | None = None) -> LocalNet:
    gw, gw_if = default_gateway()
    addrs = psutil.net_if_addrs()
    stats = psutil.net_if_stats()
    primary = _primary_ip()
    cands = []
    for name, items in addrs.items():
        if interface and name != interface:
            continue
        if not interface and (name.lower().startswith(_TUNNEL) or (name in stats and not stats[name].isup)):
            continue
        mac = None
        for b in items:
            if b.family == getattr(psutil, "AF_LINK", -1) or b.family == getattr(socket, "AF_PACKET", -2):
                mac = normalize_mac(b.address)
        for a in items:
            if a.family != socket.AF_INET or not a.netmask:
                continue
            if a.address.startswith(("127.", "169.254.")):
                continue
            net = ipaddress.ip_network(f"{a.address}/{a.netmask}", strict=False)
            if net.prefixlen >= 31 and not interface:
                continue
            score = (3 if a.address == primary else 0) + (2 if gw_if in (name, a.address) else 0) \
                + (1 if gw and ipaddress.ip_address(gw) in net else 0) + (1 if name in ("en0", "eth0", "Wi-Fi", "Ethernet") else 0)
            cands.append((score, name, a.address, net, mac))
    if not cands:
        raise RuntimeError("Couldn't find an active Wi-Fi or Ethernet connection. Are you connected to a network?")
    score, name, ip, net, mac = max(cands, key=lambda c: c[0])
    if subnet:
        net = ipaddress.ip_network(subnet, strict=False)
    g = gw if gw and ipaddress.ip_address(gw) in net else None
    return LocalNet(interface=name, ip=ip, network=net, mac=mac, gateway=g)


def trigger_arp(hosts: list[str], passes: int = 2) -> None:
    """Make the OS resolve every address so live devices land in the ARP table."""
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.setblocking(False)
        for p in range(passes):
            for i, h in enumerate(hosts):
                for _ in range(3):
                    try:
                        s.sendto(b"\x00", (h, 9))      # port 9 = 'discard'
                        break
                    except BlockingIOError:
                        time.sleep(0.01)
                    except OSError:
                        time.sleep(0.02)                # ENOBUFS on macOS: pause briefly
                        break
                if i % 64 == 63:
                    time.sleep(0.03)
            time.sleep(1.2 if p == 0 else 1.8)


def arp_table(interface: str | None = None) -> dict[str, str]:
    """{ip: mac} for complete entries."""
    table: dict[str, str] = {}
    if SYSTEM == "Linux":
        try:
            with open("/proc/net/arp") as fh:
                for line in fh.readlines()[1:]:
                    f = line.split()
                    if len(f) >= 6 and f[2] != "0x0" and (not interface or f[5] == interface):
                        mac = normalize_mac(f[3])
                        if mac:
                            table[f[0]] = mac
        except OSError:
            pass
    elif SYSTEM == "Darwin":
        out = _run(["arp", "-an"] + (["-i", interface] if interface else []), timeout=10)
        for m in re.finditer(r"\((\d+\.\d+\.\d+\.\d+)\) at ([0-9a-fA-F:]+) on (\S+)", out):
            mac = normalize_mac(m.group(2))
            if mac:
                table[m.group(1)] = mac
    elif SYSTEM == "Windows":
        out = _run(["arp", "-a"], timeout=10)
        for m in re.finditer(r"(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F]{2}(?:-[0-9a-fA-F]{2}){5})\s+dynamic", out):
            mac = normalize_mac(m.group(2))
            if mac:
                table[m.group(1)] = mac
    return table


def sweep(local: LocalNet, max_hosts: int = 4096, progress=None) -> dict[str, str]:
    hosts = [str(h) for h in local.network.hosts()]
    if len(hosts) > max_hosts:
        raise ValueError(f"{local.network} has {len(hosts)} addresses. Use --subnet to pick a smaller range "
                         f"(or --max-hosts to allow it).")
    hosts = [h for h in hosts if h != local.ip]
    if progress:
        progress(f"Checking {len(hosts)} addresses on {local.network} ({local.interface})…")
    trigger_arp(hosts)
    found = {ip: mac for ip, mac in arp_table(local.interface).items()
             if ipaddress.ip_address(ip) in local.network}
    if not found and local.interface:
        found = {ip: mac for ip, mac in arp_table(None).items() if ipaddress.ip_address(ip) in local.network}
    return found
