"""lanlens: see every device on your network, sorted by type."""
from __future__ import annotations

import argparse
import datetime as _dt
import logging
import sys
import webbrowser
from pathlib import Path

from . import __version__
from .output import payload, print_summary, write_all
from .scanner import network_key, scan
from .store import Store, apply_labels


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="lanlens",
                                description="Find every device on your local network and sort it by type.")
    p.add_argument("--version", action="version", version=f"lanlens {__version__}")
    p.add_argument("-i", "--interface", help="network interface to scan from (default: the active one, e.g. en0)")
    p.add_argument("-s", "--subnet", help="range to scan, e.g. 192.168.1.0/24 (default: your current network)")
    p.add_argument("--no-ports", action="store_true", help="skip the quick port check (fewer clues, slightly faster)")
    p.add_argument("-o", "--output", help="folder for the report (default: ./lanlens-<date>)")
    p.add_argument("--no-open", action="store_true", help="don't open the report in your browser")
    p.add_argument("--max-hosts", type=int, default=4096, help="refuse ranges bigger than this (default 4096)")
    p.add_argument("-v", "--verbose", action="store_true")
    args = p.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.ERROR)
    if not args.verbose:
        logging.getLogger("zeroconf").setLevel(logging.CRITICAL)

    say = lambda m="": print(m, flush=True)
    say(f"lanlens {__version__}: scanning your local network (read-only)")
    try:
        local, devices = scan(args.interface, args.subnet, ports=not args.no_ports,
                              max_hosts=args.max_hosts, progress=lambda m: say("  " + m))
    except (RuntimeError, ValueError) as exc:
        say(f"  {exc}")
        return 1
    except KeyboardInterrupt:
        say("\nStopped.")
        return 130
    store = Store()
    merged, seen_before = store.merge_scan(network_key(local, devices), devices)
    apply_labels(merged, store.labels())
    data = payload(local, [d for d in merged if d.online], seen_before)
    out = Path(args.output) if args.output else Path.cwd() / f"lanlens-{_dt.datetime.now():%Y%m%d-%H%M}"
    paths = write_all(out, data)
    print_summary(data, say)
    say(f"  Report: {paths['report']}")
    say(f"  CSV:    {paths['csv']}")
    if not args.no_open:
        try:
            webbrowser.open(paths["report"].resolve().as_uri())
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
