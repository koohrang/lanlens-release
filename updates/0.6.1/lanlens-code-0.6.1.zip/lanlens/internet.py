"""Your internet connection, seen from both ends (no logins):

* Public IP, provider (ISP) and network number (ASN), from Cloudflare's
  speed-test metadata endpoint (the same server the speed test uses).
* What your router itself says over UPnP, the open standard most home routers
  answer on the local network: its internet-side address, link status, how
  long the link has been up, total data in/out and any port forwards that
  devices have opened.
* Whether you're behind a second router ("double NAT") or your provider's
  shared address ("CGNAT"), which breaks remote access and some games.
"""
from __future__ import annotations

import datetime as _dt
import ipaddress
import json
import os
import re
import socket
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

from .probes import _open, _OPENER

META_URL = os.environ.get("LANLENS_META_URL", "https://speed.cloudflare.com/meta")
TRACE_URL = os.environ.get("LANLENS_TRACE_URL", "https://1.1.1.1/cdn-cgi/trace")
CGNAT = ipaddress.ip_network("100.64.0.0/10")


def now_iso() -> str:
    return _dt.datetime.now().isoformat(timespec="seconds")


# ---------------------------------------------------------------------------
# Public IP and provider
# ---------------------------------------------------------------------------
def public_info(timeout: float = 6.0) -> dict:
    """{"ip", "isp", "asn", "city", "region", "country", "colo"} (whatever is known)."""
    out: dict = {}
    try:
        with _open(META_URL, timeout=timeout) as r:
            j = json.loads(r.read(20000))
        colo = j.get("colo")
        out = {"ip": j.get("clientIp"), "isp": j.get("asOrganization"), "asn": j.get("asn"),
               "city": j.get("city"), "region": j.get("region"), "country": j.get("country"),
               "colo": colo.get("iata") if isinstance(colo, dict) else colo}
        if isinstance(colo, dict) and not out.get("country"):
            out["country"] = colo.get("cca2")
    except Exception:
        pass
    if not out.get("ip"):
        try:
            with _open(TRACE_URL, timeout=timeout) as r:
                kv = dict(line.split("=", 1) for line in r.read(4000).decode().splitlines() if "=" in line)
            out.update({"ip": kv.get("ip"), "country": out.get("country") or kv.get("loc"),
                        "colo": out.get("colo") or kv.get("colo")})
        except Exception:
            pass
    return {k: v for k, v in out.items() if v not in (None, "")}


# ---------------------------------------------------------------------------
# UPnP Internet Gateway Device (your router)
# ---------------------------------------------------------------------------
IGD_TYPES = ("urn:schemas-upnp-org:device:InternetGatewayDevice:2",
             "urn:schemas-upnp-org:device:InternetGatewayDevice:1")
WAN_SERVICES = ("urn:schemas-upnp-org:service:WANIPConnection:2", "urn:schemas-upnp-org:service:WANIPConnection:1",
                "urn:schemas-upnp-org:service:WANPPPConnection:1")
COMMON_IF = "urn:schemas-upnp-org:service:WANCommonInterfaceConfig:1"


def find_igd(gateway: str, wait: float = 2.5) -> str | None:
    """Ask for an Internet Gateway Device; return the description URL the router gives."""
    if os.environ.get("LANLENS_IGD_URL"):                       # tests
        return os.environ["LANLENS_IGD_URL"]
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP) as s:
        s.settimeout(0.4)
        s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
        end = time.time() + wait
        sent = 0
        while time.time() < end:
            if sent < 2:
                for st in IGD_TYPES:
                    msg = (f"M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\n"
                           f"MX: 2\r\nST: {st}\r\n\r\n").encode()
                    for dst in ((gateway, 1900), ("239.255.255.250", 1900)):
                        try:
                            s.sendto(msg, dst)
                        except OSError:
                            pass
                sent += 1
            try:
                data, (ip, _) = s.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                return None
            if ip != gateway:
                continue
            m = re.search(rb"(?im)^location:\s*(\S+)", data)
            if m:
                return m.group(1).decode("utf-8", "ignore")
    return None


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def parse_description(xml: bytes, base: str) -> dict:
    """Router identity plus control URLs for the WAN services."""
    root = ET.fromstring(xml)
    info: dict = {"services": {}}
    url_base = None
    for el in root.iter():
        if _local(el.tag) == "URLBase" and (el.text or "").strip():
            url_base = el.text.strip()
    base = url_base or base
    top = next((el for el in root.iter() if _local(el.tag) == "device"), None)
    if top is not None:
        for child in top:
            t = _local(child.tag)
            if t in ("friendlyName", "manufacturer", "modelName", "modelNumber", "modelDescription", "serialNumber"):
                info[t] = (child.text or "").strip()
    for svc in root.iter():
        if _local(svc.tag) != "service":
            continue
        f = {_local(c.tag): (c.text or "").strip() for c in svc}
        st, ctl = f.get("serviceType", ""), f.get("controlURL", "")
        if st and ctl and st not in info["services"]:
            info["services"][st] = urllib.parse.urljoin(base, ctl)
    return info


def soap(url: str, service: str, action: str, args: dict | None = None, timeout: float = 4.0) -> dict:
    body = "".join(f"<{k}>{v}</{k}>" for k, v in (args or {}).items())
    env = ('<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
           's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body>'
           f'<u:{action} xmlns:u="{service}">{body}</u:{action}></s:Body></s:Envelope>').encode()
    req = urllib.request.Request(url, data=env, method="POST", headers={
        "Content-Type": 'text/xml; charset="utf-8"', "SOAPAction": f'"{service}#{action}"', "User-Agent": "lanlens"})
    with _OPENER.open(req, timeout=timeout) as r:
        raw = r.read(200_000)
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:                      # some routers send sloppy XML; the values are still readable
        return {m.group(1): m.group(2).strip() for m in
                re.finditer(rb"<(?:\w+:)?(New\w+)>([^<]*)</".decode(), raw.decode("utf-8", "replace"))}
    out = {}
    for el in root.iter():
        if len(el) == 0 and el.text is not None:
            out[_local(el.tag)] = el.text.strip()
    return out


def router_info(gateway: str | None) -> dict:
    """Everything the router will tell us without a login. {} if it doesn't speak UPnP."""
    if not gateway:
        return {}
    loc = find_igd(gateway)
    if not loc:
        return {"upnp": False}
    try:
        with _open(loc, timeout=4) as r:
            desc = parse_description(r.read(300_000), loc)
    except Exception:
        return {"upnp": False}
    out: dict = {"upnp": True, "model": " ".join(filter(None, [desc.get("manufacturer"), desc.get("modelName"),
                                                               desc.get("modelNumber")])) or None,
                 "name": desc.get("friendlyName"), "manufacturer": desc.get("manufacturer"),
                 "model_name": desc.get("modelName"), "model_number": desc.get("modelNumber"), "forwards": []}
    svcs = desc["services"]
    wan = next(((st, svcs[st]) for st in WAN_SERVICES if st in svcs), None)
    if wan:
        st, url = wan
        try:
            out["wan_ip"] = soap(url, st, "GetExternalIPAddress").get("NewExternalIPAddress") or None
        except Exception:
            pass
        try:
            s = soap(url, st, "GetStatusInfo")
            out["link"] = s.get("NewConnectionStatus")
            up = s.get("NewUptime")
            if up and up.isdigit():
                out["uptime_s"] = int(up)
        except Exception:
            pass
        for i in range(64):                                      # port forwards opened over UPnP
            try:
                e = soap(url, st, "GetGenericPortMappingEntry", {"NewPortMappingIndex": i}, timeout=3)
            except Exception:
                break
            if not e.get("NewExternalPort"):
                break
            out["forwards"].append({"external_port": e.get("NewExternalPort"), "protocol": e.get("NewProtocol"),
                                    "internal_ip": e.get("NewInternalClient"), "internal_port": e.get("NewInternalPort"),
                                    "description": e.get("NewPortMappingDescription") or "",
                                    "enabled": e.get("NewEnabled", "1") in ("1", "true")})
    if COMMON_IF in svcs:
        url = svcs[COMMON_IF]
        for action, key, field in (("GetTotalBytesReceived", "bytes_in", "NewTotalBytesReceived"),
                                   ("GetTotalBytesSent", "bytes_out", "NewTotalBytesSent")):
            try:
                v = soap(url, COMMON_IF, action).get(field)
                if v and v.isdigit():
                    out[key] = int(v)
            except Exception:
                pass
        try:
            p = soap(url, COMMON_IF, "GetCommonLinkProperties")
            for k, f in (("down_bps", "NewLayer1DownstreamMaxBitRate"), ("up_bps", "NewLayer1UpstreamMaxBitRate")):
                if (p.get(f) or "").isdigit() and int(p[f]) > 0:
                    out[k] = int(p[f])
            if p.get("NewWANAccessType"):
                out["access_type"] = p["NewWANAccessType"]
        except Exception:
            pass
    return out


# ---------------------------------------------------------------------------
# Double NAT / CGNAT
# ---------------------------------------------------------------------------
def nat_status(public_ip: str | None, wan_ip: str | None, hops: list[dict] | None = None) -> dict:
    """Plain-English verdict on how many address translations sit between you and the internet."""
    def kind(ip):
        try:
            a = ipaddress.ip_address(ip)
        except (ValueError, TypeError):
            return None
        if a in CGNAT:
            return "cgnat"
        return "private" if a.is_private else "public"

    if wan_ip:
        k = kind(wan_ip)
        if k == "cgnat":
            return {"status": "cgnat", "title": "Shared address from your provider (CGNAT)",
                    "detail": f"Your router's internet address ({wan_ip}) is in the range providers share between "
                              "customers. Port forwarding and reaching home devices remotely won't work without help "
                              "from your provider (ask for a public IPv4 address) or a relay such as Tailscale."}
        if k == "private":
            return {"status": "double", "title": "Double NAT (a router behind a router)",
                    "detail": f"Your router gets a private address ({wan_ip}) from another router or modem in front "
                              "of it. This often breaks gaming, VPNs and port forwarding. Fix: put the ISP modem in "
                              "bridge mode, or set your own router to access-point mode."}
        if public_ip and k == "public" and wan_ip != public_ip:
            return {"status": "cgnat", "title": "Your provider shares your public address",
                    "detail": f"Your router's internet address ({wan_ip}) differs from the address the internet sees "
                              f"({public_ip}). Inbound connections and port forwarding are unlikely to work."}
        if k == "public":
            return {"status": "ok", "title": "Normal (one router, public address)",
                    "detail": "Your router holds your public internet address directly."}
    if hops:
        priv = [h["ip"] for h in hops[1:6] if h.get("ip") and kind(h["ip"]) == "private"]
        cg = [h["ip"] for h in hops[:6] if h.get("ip") and kind(h["ip"]) == "cgnat"]
        if cg:
            return {"status": "cgnat", "title": "Shared address from your provider (CGNAT)",
                    "detail": f"The path to the internet passes {cg[0]}, an address providers use for shared "
                              "(carrier-grade) NAT. Inbound connections to your home won't work directly."}
        if priv:
            return {"status": "double", "title": "Probably double NAT (a router behind a router)",
                    "detail": f"After your router, traffic passes another private address ({priv[0]}). That's usually "
                              "a second router or the ISP modem also routing. Gaming, VPNs and port forwarding may suffer."}
        if len(hops) > 1:
            return {"status": "ok", "title": "Normal (one router)",
                    "detail": "Traffic goes straight from your router to your provider."}
    return {"status": "unknown", "title": "Couldn't tell",
            "detail": "Your router doesn't answer UPnP and the path check didn't finish."}


def human_bytes(n: int | None) -> str | None:
    if n is None:
        return None
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return None
