"""LanLens menu-bar icon (macOS). Runs as its own small process and talks to
the LanLens app over its local API. If anything here fails, the app keeps
working without the icon."""
from __future__ import annotations

import json
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

import rumps

INSTANCE = Path.home() / ".lanlens" / "server.json"
_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def _info():
    return json.loads(INSTANCE.read_text())


def call(path, body=None):
    info = _info()
    req = urllib.request.Request(f"http://127.0.0.1:{info['port']}{path}",
                                 data=json.dumps(body).encode() if body is not None else None,
                                 method="POST" if body is not None else "GET",
                                 headers={"X-LanLens-Token": info["token"], "Content-Type": "application/json"})
    with _opener.open(req, timeout=5) as r:
        return json.loads(r.read())


class Bar(rumps.App):
    def __init__(self):
        super().__init__("LanLens", title="◉", quit_button=None)
        self.status_item = rumps.MenuItem("Starting…")
        self.health_item = rumps.MenuItem("Internet: checking…")
        self.new_item = rumps.MenuItem("")
        self.watch_item = rumps.MenuItem("Keep watching", callback=self.toggle_watch)
        self.login_item = rumps.MenuItem("Start at login", callback=self.toggle_login)
        self.menu = [rumps.MenuItem("Open LanLens", callback=self.open_app), rumps.MenuItem("Scan now", callback=self.scan),
                     None, self.status_item, self.health_item, self.new_item, None,
                     self.watch_item, self.login_item, None, rumps.MenuItem("Quit LanLens", callback=self.quit_all)]
        self.failures = 0
        self.timer = rumps.Timer(self.refresh, 15)
        self.timer.start()
        self.refresh(None)

    def refresh(self, _):
        try:
            s = call("/api/state?light=1")
            self.failures = 0
        except Exception:
            self.failures += 1
            if self.failures >= 4:          # the app has quit; so do we
                rumps.quit_application()
            return
        online = sum(1 for d in s["devices"] if d["online"])
        new = [d for d in s["devices"] if d["new"]]
        self.title = f"◉ {online}" + (f" +{len(new)}" if new else "")
        self.status_item.title = ("Scanning…" if s["status"]["scanning"] else f"{online} devices online")
        self.new_item.title = (f"New: {', '.join((d['name'] or d['ip']) for d in new[:3])}" if new else "No new devices")
        h = s.get("health_now") or {}
        self.health_item.title = ("Internet: " + (f"OK · {h['inet']:.0f} ms" if h.get("up") and h.get("inet") is not None
                                                  else "down" if h and not h.get("up") else "checking…"))
        self.watch_item.state = 1 if s["watch"]["on"] else 0
        self.login_item.state = 1 if s.get("settings", {}).get("start_at_login") else 0

    def open_app(self, _):
        info = _info()
        webbrowser.open(f"http://127.0.0.1:{info['port']}/?t={info['token']}")

    def scan(self, _):
        try:
            call("/api/scan", {})
        except Exception:
            pass

    def toggle_watch(self, item):
        try:
            call("/api/watch", {"on": not bool(item.state)})
            self.refresh(None)
        except Exception:
            pass

    def toggle_login(self, item):
        try:
            r = call("/api/settings", {"start_at_login": not bool(item.state)})
            if r.get("error"):
                rumps.alert("LanLens", r["error"])
            self.refresh(None)
        except Exception:
            pass

    def quit_all(self, _):
        try:
            call("/api/quit", {})
        except Exception:
            pass
        rumps.quit_application()


def main():
    try:
        from AppKit import NSApplication
        NSApplication.sharedApplication().setActivationPolicy_(1)    # menu-bar only, no Dock icon
    except Exception:
        pass
    for _ in range(20):
        if INSTANCE.exists():
            break
        time.sleep(0.5)
    Bar().run()


if __name__ == "__main__":
    sys.exit(main())
