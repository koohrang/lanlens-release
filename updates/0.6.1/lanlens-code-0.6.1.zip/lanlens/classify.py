"""Decide what each device is: category, specific type, confidence and why.

Every clue adds weighted votes for a category (and optionally a specific
type). Strong clues (what a device announces about itself) outweigh weak ones
(who made its network chip).
"""
from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, field

CATEGORIES = [
    ("network", "Network"),
    ("computer", "Computers"),
    ("mobile", "Mobile"),
    ("iot", "IoT & Smart Home"),
    ("media", "Media & Entertainment"),
    ("printer", "Printers & Scanners"),
    ("server", "Servers & Storage"),
    ("unknown", "Unknown"),
]
CATEGORY_LABEL = dict(CATEGORIES)

STRONG, MEDIUM, WEAK = 10, 5, 2


@dataclass
class Device:
    ip: str
    mac: str | None
    vendor: str | None = None
    vendor_org: str | None = None
    randomized_mac: bool = False
    name: str | None = None
    hostnames: list[str] = field(default_factory=list)
    model: str | None = None
    category: str = "unknown"
    type: str = "Unknown device"
    confidence: str = "low"
    reasons: list[str] = field(default_factory=list)
    services: list[str] = field(default_factory=list)
    ports: list[int] = field(default_factory=list)
    upnp: dict = field(default_factory=dict)
    http_title: str | None = None
    is_self: bool = False
    is_gateway: bool = False
    new: bool = False
    first_seen: str | None = None
    notes: list[str] = field(default_factory=list)
    # history & presence
    key: str | None = None
    online: bool = True
    last_seen: str | None = None
    seen_count: int = 0
    rtt_ms: float | None = None
    ttl: int | None = None
    os_guess: str | None = None
    # deeper identification: {"source": "detail"}
    identity: dict = field(default_factory=dict)
    # your own labels
    auto_name: str | None = None
    user_notes: str = ""
    trusted: bool = False
    owner: str = ""
    alert: bool = False


class Votes:
    def __init__(self):
        self.score = defaultdict(float)
        self.types = defaultdict(lambda: defaultdict(float))
        self.reasons = defaultdict(list)

    def add(self, cat, weight, reason, typ=None):
        self.score[cat] += weight
        if typ:
            self.types[cat][typ] += weight
        if reason and reason not in self.reasons[cat]:
            self.reasons[cat].append(reason)


# ---------------------------------------------------------------------------
# Clue tables
# ---------------------------------------------------------------------------
# mDNS service -> (category, weight, type)
MDNS = {
    "_ipp._tcp": ("printer", STRONG, "Printer"), "_ipps._tcp": ("printer", STRONG, "Printer"),
    "_printer._tcp": ("printer", STRONG, "Printer"), "_pdl-datastream._tcp": ("printer", STRONG, "Printer"),
    "_scanner._tcp": ("printer", MEDIUM, "Scanner"), "_uscan._tcp": ("printer", MEDIUM, "Scanner"),
    "_hap._tcp": ("iot", STRONG, "HomeKit accessory"), "_hap._udp": ("iot", STRONG, "HomeKit accessory"),
    "_matter._tcp": ("iot", STRONG, "Matter smart-home device"), "_matterc._udp": ("iot", STRONG, "Matter smart-home device"),
    "_meshcop._udp": ("iot", MEDIUM, "Thread border router"), "_hue._tcp": ("iot", STRONG, "Philips Hue bridge"),
    "_esphomelib._tcp": ("iot", STRONG, "ESPHome device"), "_shelly._tcp": ("iot", STRONG, "Shelly smart relay"),
    "_home-assistant._tcp": ("iot", STRONG, "Home Assistant hub"), "_mqtt._tcp": ("iot", MEDIUM, "MQTT broker"),
    "_rtsp._tcp": ("iot", MEDIUM, "IP camera"), "_axis-video._tcp": ("iot", STRONG, "IP camera"),
    "_sonos._tcp": ("media", STRONG, "Sonos speaker"), "_spotify-connect._tcp": ("media", MEDIUM, "Speaker / streamer"),
    "_amzn-wplay._tcp": ("media", STRONG, "Fire TV"), "_roku._tcp": ("media", STRONG, "Roku"),
    "_androidtvremote2._tcp": ("media", STRONG, "Android / Google TV"), "_nvstream._tcp": ("media", MEDIUM, "NVIDIA Shield / game stream"),
    "_raop._tcp": ("media", WEAK, "AirPlay speaker"),
    "_companion-link._tcp": ("mobile", WEAK, "Apple device"), "_apple-mobdev2._tcp": ("mobile", STRONG, "iPhone / iPad"),
    "_rdlink._tcp": ("mobile", MEDIUM, "iPhone / iPad"),
    "_smb._tcp": ("computer", MEDIUM, None), "_afpovertcp._tcp": ("computer", MEDIUM, None),
    "_workstation._tcp": ("computer", MEDIUM, "Linux computer"), "_rfb._tcp": ("computer", MEDIUM, None),
    "_ssh._tcp": ("computer", WEAK, None), "_sftp-ssh._tcp": ("computer", WEAK, None),
    "_adisk._tcp": ("server", MEDIUM, "Network storage"), "_nfs._tcp": ("server", MEDIUM, "Network storage"),
    "_plexmediasvr._tcp": ("server", STRONG, "Plex media server"), "_daap._tcp": ("server", WEAK, None),
}

# Apple model identifiers (from _device-info / _airplay 'model')
APPLE_MODELS = [
    (r"^iPhone", "mobile", "iPhone"), (r"^iPad", "mobile", "iPad"), (r"^Watch", "mobile", "Apple Watch"),
    (r"^iPod", "mobile", "iPod"), (r"^AppleTV", "media", "Apple TV"), (r"^AudioAccessory", "iot", "HomePod"),
    (r"^MacBook", "computer", "MacBook"), (r"^iMac", "computer", "iMac"), (r"^Macmini", "computer", "Mac mini"),
    (r"^MacPro", "computer", "Mac Pro"), (r"^Mac\d|^Mac1[0-9]", "computer", "Mac"),
]

# Google Cast 'md' model names
CAST_MODELS = [
    (r"Google Home|Nest Mini|Nest Audio|Home Mini|Nest Hub|Home Max|Nest Wifi point", "iot", "Google smart speaker / display"),
    (r"Chromecast|Google TV Streamer", "media", "Chromecast"),
    (r"TV|BRAVIA|SHIELD|Android", "media", "Smart TV / streamer"),
]

# Names (hostname, mDNS, NetBIOS, UPnP friendly name) -> category/type
NAME_RULES = [
    (r"iphone", "mobile", "iPhone"), (r"ipad", "mobile", "iPad"), (r"apple-?watch", "mobile", "Apple Watch"),
    (r"galaxy|android|pixel|oneplus|redmi|xiaomi-|moto[- ]?[gez]|huawei-|oppo|vivo|nokia-|sm-[agsnf]\d", "mobile", "Phone / tablet"),
    (r"macbook|imac|mac-?mini|mac-?studio|^mac(-?\d+)?$|^mac-", "computer", "Mac"),
    (r"desktop-|laptop|-pc\b|^pc-|thinkpad|surface|workstation|\bwin(dows)?-|latitude|optiplex|elitebook|ideapad|chromebook", "computer", "PC / laptop"),
    (r"raspberrypi|\brpi\b", "computer", "Raspberry Pi"),
    (r"printer|laserjet|officejet|deskjet|epson|\bet-\d|brother|mfc-|hl-l|canon|pixma|imageclass|xerox|lexmark|kyocera|ricoh", "printer", "Printer"),
    (r"apple-?tv|roku|fire-?tv|firestick|aft[a-z]{2,}|chromecast|bravia|webos|lgwebos|\b\w*tv\b|smart-?tv|\[tv\]|vizio|tizen", "media", "TV / streaming device"),
    (r"xbox|playstation|\bps[345]\b|nintendo|switch-?oled", "media", "Game console"),
    (r"sonos|homepod|bose|denon|marantz|yamaha", "media", "Speaker"),
    (r"echo|alexa|google-?home|nest-?(mini|audio|hub)", "iot", "Smart speaker"),
    (r"\bcam\b|camera|doorbell|ipc|nvr|dvr|hikvision|reolink|wyze|arlo|blink|ring-|eufy", "iot", "Camera / doorbell"),
    (r"thermostat|ecobee|nest-?(learning|thermostat)", "iot", "Thermostat"),
    (r"plug|switch-?\d|bulb|light|lamp|tasmota|shelly|sonoff|esp[-_]?\w*|wemo|kasa|tuya|smartlife|hue|lifx|meross|govee", "iot", "Smart plug / light"),
    (r"roomba|irobot|vacuum|roborock", "iot", "Robot vacuum"),
    (r"smartthings|hubitat|homey|home-?assistant|hassio|zigbee|bridge", "iot", "Smart-home hub"),
    (r"\bnas\b|synology|diskstation|qnap|truenas|unraid|readynas|mycloud|ds\d{3,4}", "server", "Network storage (NAS)"),
    (r"server|\bsrv\b|proxmox|esxi|vcenter|hyper-?v|plex", "server", "Server"),
    (r"router|gateway|\bgw\b|firewall|pfsense|opnsense|unifi|udm|usg|eero|orbi|deco|velop|mesh|extender|repeater|\bap\b|access-?point|switch\b|edgerouter|mikrotik|fritz", "network", "Network device"),
]

# Vendor -> (category, weight, type). Ambiguous vendors get low weights.
VENDOR_RULES = [
    (r"^Ring$", "iot", MEDIUM + 1, "Ring camera / doorbell / chime"),
    (r"^Nintendo$", "media", MEDIUM + 1, "Nintendo Switch"),
    (r"^Sonos$", "media", MEDIUM + 1, "Sonos speaker"),
    (r"^Roku$", "media", MEDIUM + 1, "Roku"),
    (r"Cisco|Juniper|Arista|Ubiquiti|MikroTik|Fortinet|Palo Alto|HPE Aruba|Ruckus|Cambium|Meraki|Extreme|Zyxel|"
     r"D-Link|eero|Linksys|ARRIS|Technicolor|Sagemcom|CommScope|Calix|Actiontec|Plume|Starlink|AVM|Netgear|NETGEAR|Edimax|"
     r"Peplink|Sophos|SonicWall|WatchGuard|Cradlepoint|Inseego", "network", MEDIUM, "Network device"),
    (r"TP-Link|ASUS|Huawei|ZTE", "network", WEAK, "Network device"),
    (r"Espressif|Tuya|Shelly|Belkin|Philips Hue|Ring|Arlo|Wyze|ecobee|Google Nest|iRobot|Hikvision|Dahua|Axis|Reolink|"
     r"Amcrest|EZVIZ|Sonoff|Chamberlain|Lutron|LIFX|SimpliSafe|Honeywell|Resideo|Rachio|Withings|Ecovacs|Roborock|"
     r"Universal Electronics|Silicon Labs|Texas Instruments|Particle|Wiz|Leedarson|Meross|Govee|Yeelight|Aqara|Lumi|"
     r"SmartThings|Midea|Tado|Netatmo|Eufy|Anker|Blink|Immedia", "iot", MEDIUM, "Smart-home device"),
    (r"Amazon", "iot", WEAK, "Amazon device (Echo / Fire TV / Ring)"),
    (r"Roku|Sonos|VIZIO|TCL|Hisense|Bose|Nintendo|Sony PlayStation|NVIDIA|Denon|Marantz|D&M|Yamaha|Harman|Sling|"
     r"Funai|Vestel|Skyworth|Sharp", "media", MEDIUM, "Media device"),
    (r"^LG$|^Sony$|Samsung", "media", WEAK, None),
    (r"Epson|Brother|Canon|Xerox|Lexmark|Kyocera|Ricoh|Konica|Zebra|Fuji Xerox|Fujifilm", "printer", MEDIUM, "Printer"),
    (r"^HP$", "printer", WEAK, None),
    (r"Synology|QNAP|Western Digital|Seagate|Buffalo|Drobo|Asustor|TerraMaster|Supermicro", "server", MEDIUM, "Network storage / server"),
    (r"virtual machine|Docker container", "server", STRONG, "Virtual machine / container"),
    (r"Dell|Lenovo|Intel|Micro-Star|MSI|Acer|Framework|Gigabyte|Foxconn|Quanta|Compal|Wistron|Pegatron|Lite-On|"
     r"AzureWave|Realtek|Liteon|Clevo|Microsoft", "computer", WEAK, "PC / laptop"),
    (r"Raspberry Pi", "computer", MEDIUM, "Raspberry Pi"),
    (r"OnePlus|Motorola|OPPO|vivo|Xiaomi|Fairphone|HMD|Realme|Nothing|Google$", "mobile", WEAK, "Phone / tablet"),
    (r"^Apple$", "computer", WEAK, None),       # Apple alone could be anything; tie-broken by other clues
    (r"^Apple$", "mobile", WEAK, None),
]

# Open ports -> (category, weight, type, reason)
PORT_RULES = {
    62078: ("mobile", STRONG, "iPhone / iPad", "answers on the iPhone/iPad sync port (62078)"),
    9100: ("printer", STRONG, "Printer", "printer port 9100 is open"),
    631: ("printer", MEDIUM, "Printer", "IPP printing port 631 is open"),
    515: ("printer", MEDIUM, "Printer", "LPD printing port 515 is open"),
    554: ("iot", MEDIUM, "IP camera", "video streaming port 554 (RTSP) is open"),
    8009: ("media", MEDIUM, "Google Cast device", "Google Cast port 8009 is open"),
    1400: ("media", STRONG, "Sonos speaker", "Sonos control port 1400 is open"),
    3389: ("computer", STRONG, "Windows PC", "Windows Remote Desktop port is open"),
    445: ("computer", MEDIUM, None, "file sharing (SMB) is on"),
    548: ("computer", WEAK, None, "Apple file sharing (AFP) is on"),
    5900: ("computer", MEDIUM, None, "screen sharing (VNC) is on"),
    1883: ("iot", MEDIUM, "IoT hub", "MQTT (IoT messaging) port is open"),
    8883: ("iot", MEDIUM, "IoT hub", "MQTT over TLS port is open"),
    32400: ("server", STRONG, "Plex media server", "Plex port 32400 is open"),
    53: ("network", MEDIUM, None, "runs a DNS server"),
}

UPNP_RULES = [
    (r"InternetGatewayDevice|WANDevice|WFADevice", "network", STRONG, "Router / Wi-Fi gateway"),
    (r"MediaServer", "server", WEAK, None),
    (r"dial-multiscreen|roku:ecp", "media", STRONG, "Smart TV / streamer"),
    (r"MediaRenderer", "media", MEDIUM, "Media player / TV"),
    (r"ZonePlayer", "media", STRONG, "Sonos speaker"),
    (r"Belkin|wemo|controllee|lightswitch|insight", "iot", STRONG, "Smart plug / switch"),
    (r"hue|Philips", "iot", STRONG, "Philips Hue bridge"),
    (r"Printer", "printer", STRONG, "Printer"),
    (r"NetworkCamera|Camera|DigitalSecurityCamera|Hikvision|Dahua|Axis", "iot", STRONG, "IP camera"),
    (r"Xbox", "media", STRONG, "Xbox"), (r"PlayStation|PS5|PS4", "media", STRONG, "PlayStation"),
    (r"Synology|QNAP|DiskStation|NAS", "server", STRONG, "Network storage (NAS)"),
    (r"\[TV\]|Smart TV|BRAVIA|webOS|Tizen|AQUOS|VIZIO|FireTV|Fire TV|Roku", "media", STRONG, "Smart TV / streamer"),
    (r"Echo|Alexa", "iot", STRONG, "Echo smart speaker"),
]

TITLE_RULES = [
    (r"router|gateway|modem|firewall|unifi|edgeos|pfsense|opnsense|mikrotik|routeros|fritz|netgear|tp-link|"
     r"asus ?wrt|openwrt|dd-wrt|access point|eero|orbi|velop|xfinity|airport|cisco|aruba|meraki|sonicwall|fortigate", "network", MEDIUM, "Router / network device"),
    (r"printer|laserjet|officejet|embedded web server|epson|brother|canon|xerox|lexmark|kyocera|ricoh|web image monitor|cups", "printer", STRONG, "Printer"),
    (r"camera|ipcam|nvr|dvr|hikvision|dahua|reolink|amcrest|axis|web service|netsurveillance", "iot", MEDIUM, "IP camera / recorder"),
    (r"synology|diskstation|qnap|truenas|freenas|unraid|openmediavault|my cloud", "server", STRONG, "Network storage (NAS)"),
    (r"tasmota|esphome|shelly|sonoff|wled|openbeken", "iot", STRONG, "Smart plug / switch"),
    (r"home assistant|homebridge|hubitat|openhab|node-red|octoprint", "iot", STRONG, "Smart-home hub"),
    (r"proxmox|vmware esxi|idrac|ilo|ipmi|jenkins|grafana|portainer|plex", "server", STRONG, "Server"),
    (r"ups|apc|cyberpower|eaton|pdu", "iot", MEDIUM, "Power / UPS device"),
]

SNMP_RULES = [
    (r"HP |Hewlett|LaserJet|OfficeJet|Brother|EPSON|Canon|Xerox|Lexmark|Kyocera|RICOH|Konica|Zebra|JetDirect", "printer", STRONG, "Printer"),
    (r"Synology|DiskStation|QNAP|TrueNAS|FreeNAS|ReadyNAS|ASUSTOR|TerraMaster", "server", STRONG, "Network storage (NAS)"),
    (r"Cisco|Juniper|JUNOS|Aruba|ProCurve|RouterOS|MikroTik|EdgeOS|UniFi|Ubiquiti|NETGEAR|FortiGate|PAN-OS|"
     r"Arista|Meraki|Ruckus|Zyxel|D-Link|TP-LINK|OpenWrt|pfSense|OPNsense", "network", STRONG, "Network device"),
    (r"APC|Smart-UPS|CyberPower|Eaton|PowerWalker", "iot", STRONG, "UPS / power device"),
    (r"Windows", "computer", MEDIUM, "Windows PC"),
    (r"Linux", "computer", WEAK, None),
]


def _first_match(rules, text):
    for pat, *rest in rules:
        if re.search(pat, text, re.I):
            return rest
    return None


def classify(d: Device, extra: dict | None = None) -> Device:
    v = Votes()
    x = extra or {}
    names_text = " ".join(filter(None, [d.name, *d.hostnames])).lower()

    if d.is_self:
        v.add("computer", 100, "this is the computer running the scan", "This computer")
    if d.is_gateway:
        v.add("network", 50, "it's your default gateway (router)", "Router / gateway")

    # --- what the device announces about itself (strong) ------------------
    for svc in d.services:
        r = MDNS.get(svc)
        if r:
            cat, w, typ = r
            v.add(cat, w, f"advertises {svc.strip('_').split('._')[0]} (Bonjour)", typ)
    model = d.model or ""
    if model:
        hit = _first_match(APPLE_MODELS, model)
        if hit:
            cat, typ = hit
            v.add(cat, STRONG * 2, f"reports Apple model {model}", typ)
        hit = _first_match(CAST_MODELS, model)
        if hit and "_googlecast._tcp" in d.services:
            cat, typ = hit
            v.add(cat, STRONG * 2, f"Google Cast model '{model}'", typ)
    if "_googlecast._tcp" in d.services and not model:
        v.add("media", MEDIUM, "supports Google Cast", "Google Cast device")

    up = " ".join(str(x) for x in d.upnp.values())
    if up.strip():
        for pat, cat, w, typ in UPNP_RULES:
            if re.search(pat, up, re.I):
                v.add(cat, w, f"UPnP: {d.upnp.get('friendlyName') or d.upnp.get('modelName') or d.upnp.get('deviceType', '')[:40]}".strip(), typ)

    # --- device-specific discovery protocols (strong) ----------------------
    # rules from Home Assistant: brand/type from DHCP names, Bonjour, UPnP, HomeKit models
    for h in x.get("rules", [])[:3]:
        v.add(h["category"], {"strong": STRONG + 1, "medium": MEDIUM, "weak": WEAK}[h["w"]], h["why"], h["type"])
    if x.get("kasa"):
        kind = (x["kasa"].get("kind") or "").upper()
        v.add("iot", STRONG * 2, f"answers TP-Link Kasa discovery ({x['kasa'].get('model') or 'model unknown'})",
              "Smart light" if "BULB" in kind else "Smart plug / switch")
    if x.get("ubiquiti"):
        mdl = (x["ubiquiti"].get("model") or "").upper()
        typ = ("Wi-Fi access point" if re.match(r"^(U6|U7|UAP|UAL|UAC|AC|UWB|E7)", mdl) else
               "Network switch" if re.match(r"^(USW|US-|US8|US16|US24|US48|USL|USF)", mdl) else
               "Router / gateway" if re.match(r"^(UDM|UDR|UXG|USG|UCG|UX|ER-)", mdl) else "UniFi device")
        v.add("network", STRONG * 2, f"answers Ubiquiti discovery ({x['ubiquiti'].get('model') or 'UniFi'})", typ)
    if x.get("yeelight"):
        v.add("iot", STRONG * 2, "answers Yeelight discovery", "Smart light")
    if x.get("tuya"):
        v.add("iot", STRONG * 2, "broadcasts like a Tuya smart device", "Tuya smart device")
    if x.get("roku"):
        v.add("media", STRONG * 2, f"Roku device info ({x['roku'].get('model') or 'Roku'})",
              "Roku TV" if x["roku"].get("is_tv") else "Roku streamer")
    if x.get("cast"):
        hit = _first_match(CAST_MODELS, x["cast"].get("model") or "")
        if hit:
            v.add(hit[0], STRONG * 2, f"Google Cast reports '{x['cast'].get('model')}'", hit[1])
        else:
            v.add("media", STRONG, "Google Cast device info", "Google Cast device")
    if x.get("snmp", {}).get("descr"):
        hit = _first_match(SNMP_RULES, x["snmp"]["descr"])
        if hit:
            cat, w, typ = hit
            v.add(cat, w, f"SNMP says '{x['snmp']['descr'][:60]}'", typ)
    cert_text = " ".join(filter(None, [x.get("cert", {}).get("cn"), x.get("cert", {}).get("org"),
                                       *x.get("cert", {}).get("sans", [])]))
    if cert_text:
        hit = _first_match(TITLE_RULES, cert_text) or _first_match([(p, c, MEDIUM, t) for p, c, t in NAME_RULES], cert_text)
        if hit:
            cat, w, typ = hit
            v.add(cat, w, f"HTTPS certificate names '{cert_text[:50]}'", typ)
    ssh = x.get("ssh") or ""
    if ssh:
        if re.search(r"dropbear", ssh, re.I):
            v.add("network", WEAK, "embedded SSH server (dropbear)", None)
            v.add("iot", WEAK, None, None)
        elif re.search(r"Ubuntu|Debian|Raspbian|Fedora|FreeBSD", ssh, re.I):
            v.add("computer", MEDIUM, f"SSH reports {ssh.split('-', 2)[-1][:40]}", "Linux computer")
        elif re.search(r"Cisco|ROSSSH|Juniper", ssh, re.I):
            v.add("network", STRONG, "network-equipment SSH server", "Network device")
    if d.ttl and 65 <= d.ttl <= 128 and not d.is_self:
        v.add("computer", WEAK, "answers like Windows (TTL 128)", "Windows PC")

    # --- names --------------------------------------------------------------
    if names_text:
        for pat, cat, typ in NAME_RULES:
            if re.search(pat, names_text, re.I):
                # Apple devices name themselves ("Sara's iPhone", "Rezas-MacBook-Pro"): a reliable clue
                w = STRONG if typ in ("iPhone", "iPad", "Apple Watch", "Mac") else MEDIUM + 1
                v.add(cat, w, f"name looks like a {typ.lower()}", typ)
                break

    # --- ports ------------------------------------------------------------
    for p in d.ports:
        r = PORT_RULES.get(p)
        if r:
            cat, w, typ, why = r
            if p == 53 and not d.is_gateway:
                w = WEAK
            v.add(cat, w, why, typ)
    if 7000 in d.ports and d.vendor == "Apple":
        v.add("media", WEAK, "AirPlay receiver", None)
    if 22 in d.ports and not d.services:
        v.add("computer", WEAK, "SSH is on", None)
        v.add("network", WEAK, "SSH is on", None)

    if d.http_title:
        hit = _first_match(TITLE_RULES, d.http_title)
        if hit:
            cat, w, typ = hit
            v.add(cat, w, f"web page title '{d.http_title}'", typ)

    # --- maker of the network chip (weak/medium) --------------------------
    if d.vendor:
        for pat, cat, w, typ in VENDOR_RULES:
            if re.search(pat, d.vendor, re.I):
                v.add(cat, w, f"made by {d.vendor}", typ)
    if d.randomized_mac:
        v.add("mobile", MEDIUM - 1, "uses a private (randomized) Wi-Fi address, typical of phones, tablets and laptops",
              "Phone, tablet or laptop")
        v.add("computer", WEAK, None, None)

    # --- decide -------------------------------------------------------------
    if not v.score:
        d.category, d.type, d.confidence = "unknown", "Unknown device", "low"
        d.reasons = ["it didn't announce anything about itself"]
        return d
    ranked = sorted(v.score.items(), key=lambda kv: kv[1], reverse=True)
    cat, top = ranked[0]
    second = ranked[1][1] if len(ranked) > 1 else 0
    if top < 4:
        d.category = "unknown"
        hint = max(v.types[cat].items(), key=lambda kv: kv[1])[0] if v.types.get(cat) else CATEGORY_LABEL[cat]
        d.type = f"Possibly: {hint}"
        d.confidence = "low"
        d.reasons = v.reasons[cat][:3] or ["only weak clues"]
        return d
    d.category = cat
    types = v.types.get(cat)
    d.type = max(types.items(), key=lambda kv: kv[1])[0] if types else _default_type(cat, d)
    d.confidence = "high" if top >= 12 and top >= second * 2 else ("medium" if top >= 6 else "low")
    d.reasons = v.reasons[cat][:4]
    return d


def _default_type(cat: str, d: Device) -> str:
    if cat == "computer":
        if d.vendor == "Apple":
            return "Mac"
        if 3389 in d.ports or 445 in d.ports:
            return "Windows PC"
        return "Computer"
    if cat == "mobile":
        return "Apple device" if d.vendor == "Apple" else "Phone / tablet"
    return {"network": "Network device", "iot": "Smart-home device", "media": "Media device",
            "printer": "Printer", "server": "Server"}.get(cat, "Unknown device")


def risk_notes(d: Device) -> list[str]:
    notes = []
    if 23 in d.ports:
        notes.append("Telnet is open (unencrypted remote login)")
    if d.category == "iot" and 80 in d.ports and 443 not in d.ports:
        notes.append("Admin page is unencrypted (HTTP only)")
    if d.is_gateway and "InternetGatewayDevice" in str(d.upnp.get("deviceType", "")) + str(d.upnp.get("st", "")):
        notes.append("UPnP port-forwarding is enabled on the router")
    if d.category == "iot" and 554 in d.ports:
        notes.append("Camera video stream port (RTSP) is reachable on the network")
    return notes
