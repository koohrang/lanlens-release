"""Public databases LanLens uses to recognize devices, with offline copies
bundled in the app and fresh copies downloaded by LanLens itself.

  IEEE registries (MA-L, MA-M, MA-S)  who made a network chip/device     monthly
  Google Play supported devices       Android model codes -> names        weekly
  IANA service-name registry          what a Bonjour service/port means   monthly
  CSA Matter ledger (DCL)             Matter vendor/product numbers       per device, cached
  Wikidata (CC0)                      which company owns a brand          monthly
  NVD API                             published vulnerabilities per model per model, cached
  CISA KEV                            actively exploited flaws            daily (thismac.kev)

Only public reference data is downloaded. The only things sent out are the
Matter vendor/product numbers, brand names (Wikidata) and model names (NVD)
needed for those lookups; never addresses, device names or anything personal.
This product uses the NVD API but is not endorsed or certified by the NVD.
"""
from __future__ import annotations

import csv
import datetime as _dt
import gzip
import io
import json
import logging
import re
import threading
import time
import urllib.parse
import urllib.request
from functools import lru_cache
from pathlib import Path

DATA = Path(__file__).parent / "data"
CACHE = Path.home() / ".lanlens" / "cache"
UA = "Mozilla/5.0 (Macintosh) LanLens/0.6 (+network inventory app)"
_lock = threading.RLock()
STATUS: dict[str, dict] = {}
ONLINE = True            # set from Settings → "Online database updates"


def _get(url: str, timeout: float = 30, accept: str | None = None) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, **({"Accept": accept} if accept else {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _age_days(p: Path) -> float:
    try:
        return (time.time() - p.stat().st_mtime) / 86400
    except OSError:
        return 1e9


def _save_json_gz(p: Path, obj) -> None:
    CACHE.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    with gzip.open(tmp, "wt", encoding="utf-8") as fh:
        json.dump(obj, fh, separators=(",", ":"))
    tmp.replace(p)


def _load_json_gz(*paths: Path):
    for p in paths:
        try:
            with gzip.open(p, "rt", encoding="utf-8") as fh:
                return json.load(fh), p
        except (OSError, ValueError):
            continue
    return None, None


# ---------------------------------------------------------------------------
# IEEE registries
# ---------------------------------------------------------------------------
IEEE_URLS = {"l": "https://standards-oui.ieee.org/oui/oui.csv", "m": "https://standards-oui.ieee.org/oui28/mam.csv",
             "s": "https://standards-oui.ieee.org/oui36/oui36.csv"}


@lru_cache(maxsize=1)
def ieee() -> dict:
    d, src = _load_json_gz(CACHE / "ieee.json.gz", DATA / "ieee.json.gz")
    d = d or {"l": {}, "m": {}, "s": {}}
    STATUS["ieee"] = {"entries": sum(len(d.get(k, {})) for k in "lms"),
                      "source": "downloaded" if src and src.parent == CACHE else "built in"}
    return d


def ieee_lookup(mac: str) -> str | None:
    """Organization for a MAC, most specific registry first (MA-S, then MA-M, then MA-L)."""
    h = re.sub(r"[^0-9A-Fa-f]", "", mac or "").upper()
    if len(h) < 6:
        return None
    d = ieee()
    return d["s"].get(h[:9]) or d["m"].get(h[:7]) or d["l"].get(h[:6])


def refresh_ieee() -> None:
    out = {"l": {}, "m": {}, "s": {}}
    for k, url in IEEE_URLS.items():
        raw = _get(url, timeout=60).decode("utf-8", "replace")
        n = {"l": 6, "m": 7, "s": 9}[k]
        for row in csv.DictReader(io.StringIO(raw)):
            a = (row.get("Assignment") or "").strip().upper()
            org = (row.get("Organization Name") or "").strip()
            if len(a) == n and org:
                out[k][a] = org
    if len(out["l"]) < 20000:
        raise RuntimeError("IEEE download looked incomplete")
    old, _ = _load_json_gz(DATA / "ieee.json.gz")
    if old:                                            # keep IAB entries (retired registry) from the bundle
        for a, org in old.get("s", {}).items():
            out["s"].setdefault(a, org)
    _save_json_gz(CACHE / "ieee.json.gz", out)
    ieee.cache_clear()


# ---------------------------------------------------------------------------
# Android model codes (Google Play supported devices)
# ---------------------------------------------------------------------------
ANDROID_URL = "https://cdn.jsdelivr.net/gh/bsthen/device-models/devices.json"


@lru_cache(maxsize=1)
def android() -> dict:
    d, src = _load_json_gz(CACHE / "android.json.gz", DATA / "android.json.gz")
    m = (d or {}).get("models", {})
    STATUS["android"] = {"entries": len(m), "source": "downloaded" if src and src.parent == CACHE else "built in"}
    return m


def android_lookup(text: str | None) -> tuple[str, str] | None:
    """(brand, marketing name) for a model code like SM-S921U, if text is or contains one."""
    if not text:
        return None
    m = android()
    t = text.strip().upper()
    if t in m:
        return tuple(m[t])
    for tok in re.split(r"[\s_/()]+", t):
        if len(tok) >= 5 and any(c.isdigit() for c in tok) and tok in m:
            return tuple(m[tok])
    return None


def refresh_android() -> None:
    data = json.loads(_get(ANDROID_URL, timeout=60))
    out = {}
    for code, v in data.items():
        if len(code.strip()) >= 3 and v.get("name"):
            brand, name = (v.get("brand") or "").strip(), v["name"].strip()
            out[code.strip().upper()] = [brand, name if not brand or name.lower().startswith(brand.lower()) else f"{brand} {name}"]
    if len(out) < 10000:
        raise RuntimeError("Android list looked incomplete")
    _save_json_gz(CACHE / "android.json.gz", {"models": out})
    android.cache_clear()


# ---------------------------------------------------------------------------
# IANA service names (what a Bonjour service or port is)
# ---------------------------------------------------------------------------
IANA_URL = "https://www.iana.org/assignments/service-names-port-numbers/service-names-port-numbers.csv"
# Plain-English names for common services; used until/unless the IANA registry has been downloaded,
# and preferred over IANA's terser descriptions for these.
SERVICE_NAMES = {
    "airplay": "AirPlay video/screen receiver", "raop": "AirPlay audio receiver", "companion-link": "Apple device link (Handoff, remote)",
    "googlecast": "Google Cast (Chromecast) receiver", "androidtvremote2": "Android TV remote control", "spotify-connect": "Spotify Connect speaker",
    "hap": "Apple HomeKit accessory", "homekit": "Apple HomeKit", "matter": "Matter smart-home device", "matterc": "Matter device ready to pair",
    "matterd": "Matter controller", "meshcop": "Thread network border router", "trel": "Thread radio link", "ipp": "Printer (IPP)",
    "ipps": "Printer (secure IPP)", "printer": "Printer (LPD)", "pdl-datastream": "Printer (raw printing)", "scanner": "Scanner",
    "uscan": "Scanner (eSCL)", "smb": "Windows/Mac file sharing", "afpovertcp": "Apple file sharing", "ssh": "Secure remote login (SSH)",
    "sftp-ssh": "Secure file transfer", "http": "Web page", "https": "Secure web page", "workstation": "Computer on the network",
    "device-info": "Device information", "sleep-proxy": "Bonjour sleep proxy (Apple TV/HomePod)", "rdlink": "Apple remote desktop link",
    "apple-mobdev2": "iPhone/iPad sync over Wi-Fi", "touch-able": "Apple Remote app target", "airport": "AirPort base station",
    "sonos": "Sonos speaker", "hue": "Philips Hue bridge", "amzn-wplay": "Amazon Fire TV casting (WhisperPlay)", "amzn-alexa": "Amazon Alexa",
    "esphomelib": "ESPHome smart device", "shelly": "Shelly smart relay", "elg": "Elgato light", "nanoleafapi": "Nanoleaf lights",
    "home-assistant": "Home Assistant server", "mqtt": "Smart-home messaging (MQTT)", "rfb": "Screen sharing (VNC)", "daap": "iTunes music sharing",
    "dacp": "iTunes remote control", "adisk": "Time Machine backup disk", "nvstream": "NVIDIA game streaming", "roku-rcp": "Roku remote control",
    "aqara": "Aqara smart-home hub", "miio": "Xiaomi smart device", "ewelink": "Sonoff/eWeLink smart device", "wled": "WLED light controller",
    "linkplay": "LinkPlay speaker", "sengled": "Sengled light", "plexmediasvr": "Plex media server", "asquic": "Apple services (QUIC)",
}


@lru_cache(maxsize=1)
def iana() -> dict:
    d, src = _load_json_gz(CACHE / "iana.json.gz")
    d = d or {"services": {}, "ports": {}}
    STATUS["iana"] = {"entries": len(d["services"]) + len(SERVICE_NAMES),
                      "source": "downloaded" if src else "built in (common services)"}
    return d


def service_meaning(svc: str) -> str | None:
    """'_amzn-wplay._tcp' -> 'Amazon Fire TV casting (WhisperPlay)'."""
    name = svc.split("._sub.")[-1].strip("_").split("._")[0].lower()
    if name in SERVICE_NAMES:
        return SERVICE_NAMES[name]
    return iana()["services"].get(name)


def port_meaning(port: int) -> str | None:
    return iana()["ports"].get(str(port))


def refresh_iana() -> None:
    raw = _get(IANA_URL, timeout=60).decode("utf-8", "replace")
    services, ports = {}, {}
    for row in csv.DictReader(io.StringIO(raw)):
        name = (row.get("Service Name") or "").strip().lower()
        desc = (row.get("Description") or "").strip()
        port = (row.get("Port Number") or "").strip()
        if name and desc and name not in services:
            services[name] = desc[:120]
        if port.isdigit() and desc and (row.get("Transport Protocol") or "").lower() == "tcp" and port not in ports:
            ports[port] = desc[:120]
    if len(services) < 1000:
        raise RuntimeError("IANA registry looked incomplete")
    _save_json_gz(CACHE / "iana.json.gz", {"services": services, "ports": ports})
    iana.cache_clear()


# ---------------------------------------------------------------------------
# Matter (CSA Distributed Compliance Ledger)
# ---------------------------------------------------------------------------
DCL = "https://on.dcl.csa-iot.org"
TEST_VIDS = {0xFFF1, 0xFFF2, 0xFFF3, 0xFFF4}


def _dcl_cache() -> dict:
    try:
        return json.loads((CACHE / "matter.json").read_text())
    except (OSError, ValueError):
        return {}


def matter_ids(services: list[str], svc_txt: dict | None) -> tuple[int | None, int | None]:
    """Vendor/product numbers a device announces over Matter's Bonjour records."""
    vid = pid = None
    for s in services or []:
        m = re.match(r"_V(\d+)\._sub\._matter[cd]?\._(?:udp|tcp)", s)
        if m:
            vid = int(m.group(1))
    for svc in ("_matterc._udp", "_matterd._udp", "_matter._tcp"):
        vp = ((svc_txt or {}).get(svc) or {}).get("vp")
        if vp and re.fullmatch(r"\d+(\+\d+)?", vp):
            a = vp.split("+")
            vid = int(a[0])
            pid = int(a[1]) if len(a) > 1 else pid
    if vid in TEST_VIDS:
        return None, None
    return vid, pid


def matter_lookup(vid: int | None, pid: int | None, online: bool = True) -> dict | None:
    """{"vendor", "product"} from the ledger (cached 30 days)."""
    if not vid:
        return None
    key = f"{vid}:{pid or ''}"
    with _lock:
        cache = _dcl_cache()
        hit = cache.get(key)
        if hit and (time.time() - hit.get("t", 0) < 30 * 86400 or not online):
            return hit.get("v")
    if not online:
        return None
    res = {}
    try:
        j = json.loads(_get(f"{DCL}/dcl/vendorinfo/vendors/{vid}", timeout=8))
        info = j.get("vendorInfo") or {}
        res["vendor"] = (info.get("companyPreferredName") or info.get("vendorName") or "").strip() or None
        if pid:
            j = json.loads(_get(f"{DCL}/dcl/model/models/{vid}/{pid}", timeout=8))
            m = j.get("model") or {}
            res["product"] = (m.get("productLabel") or m.get("productName") or "").strip() or None
    except Exception as exc:
        logging.info("Matter ledger lookup %s failed: %s", key, exc)
    with _lock:
        cache = _dcl_cache()
        cache[key] = {"t": time.time(), "v": res or None}
        CACHE.mkdir(parents=True, exist_ok=True)
        (CACHE / "matter.json").write_text(json.dumps(cache))
    return res or None


# ---------------------------------------------------------------------------
# Brand facts: who owns a brand, which platform it's built on
# ---------------------------------------------------------------------------
# Facts we're confident of; Wikidata fills in the rest.
OWNERS = {"ring": "Amazon", "blink": "Amazon", "eero": "Amazon", "amazon": "Amazon", "google nest": "Google", "nest": "Google",
          "fitbit": "Google", "philips hue": "Signify", "signify": "Signify", "eufy": "Anker", "anker": "Anker", "ecobee": "Generac",
          "beats": "Apple", "honeywell home": "Resideo", "qingdao intelligent&precise": "Hisense", "qingdao hisense": "Hisense",
          "hisense": "Hisense", "belkin": "Foxconn Interconnect", "wemo": "Belkin"}
PLATFORMS = {"gosund": "Tuya (Smart Life app)", "teckin": "Tuya (Smart Life app)", "treatlife": "Tuya (Smart Life app)",
             "globe": "Tuya (Smart Life app)", "feit": "Tuya (Smart Life app)", "tuya": "Tuya (Smart Life app)",
             "gsd viet nam": "Wi-Fi module by Gaoshengda (common in TVs)", "espressif": "Espressif Wi-Fi chip",
             "ampak": "AMPAK Wi-Fi module", "azurewave": "AzureWave Wi-Fi module", "murata": "Murata Wi-Fi module"}
WIKIDATA = "https://query.wikidata.org/sparql"


def _wd_cache() -> dict:
    try:
        return json.loads((CACHE / "brands.json").read_text())
    except (OSError, ValueError):
        return {}


def brand_facts(brand: str | None) -> dict:
    """{"owner": "...", "platform": "..."} for a maker name."""
    if not brand:
        return {}
    b = re.sub(r"[^a-z0-9& ]+", " ", brand.lower())
    b = re.sub(r"\b(inc|llc|ltd|co|corp|corporation|gmbh|limited|company|technology|technologies|electronics)\b", " ", b)
    b = re.sub(r"\s+", " ", b).strip()
    out = {}
    for k, v in OWNERS.items():
        if b == k or b.startswith(k + " "):
            if v.lower() != b and not b.startswith(v.lower()):
                out["owner"] = v
            break
    for k, v in PLATFORMS.items():
        if b == k or b.startswith(k):
            out["platform"] = v
            break
    if "owner" not in out:
        w = _wd_cache().get(b)
        if w and w.lower() != b and not b.startswith(w.lower()):
            out["owner"] = w
            out["owner_source"] = "Wikidata"
    return out


def refresh_wikidata(brands: list[str]) -> None:
    names = sorted({re.sub(r"[\"\\]", "", b).strip() for b in brands if b and len(b) < 60})[:150]
    if not names:
        return
    values = " ".join(f'"{n}"@en' for n in names)
    q = ("SELECT ?name ?parentLabel WHERE { VALUES ?name { " + values + " } ?item rdfs:label ?name . "
         "?item wdt:P31 ?t . FILTER(?t IN (wd:Q4830453, wd:Q431289, wd:Q6881511, wd:Q783794, wd:Q891723, wd:Q658255, wd:Q167037)) "
         "?item (wdt:P749|wdt:P127) ?parent . SERVICE wikibase:label { bd:serviceParam wikibase:language \"en\". } }")
    raw = _get(WIKIDATA + "?" + urllib.parse.urlencode({"query": q, "format": "json"}), timeout=60,
               accept="application/sparql-results+json")
    out = _wd_cache()
    for row in json.loads(raw)["results"]["bindings"]:
        n, p = row["name"]["value"].lower(), row.get("parentLabel", {}).get("value", "")
        if p and not re.fullmatch(r"Q\d+", p):
            out.setdefault(n, p)
    CACHE.mkdir(parents=True, exist_ok=True)
    (CACHE / "brands.json").write_text(json.dumps(out))


# ---------------------------------------------------------------------------
# NVD: published vulnerabilities for an exact model (used by the security check)
# ---------------------------------------------------------------------------
NVD = "https://services.nvd.nist.gov/rest/json/cves/2.0"
_nvd_last = 0.0


def nvd_lookup(model: str, online: bool = True) -> dict | None:
    """{"total", "recent" (last 3 years), "latest": [cve ids]} for a model name; cached 7 days."""
    model = (model or "").strip()
    if len(model) < 4 or not any(c.isdigit() for c in model):
        return None                                    # too generic to search meaningfully
    p = CACHE / "nvd.json"
    with _lock:
        try:
            cache = json.loads(p.read_text())
        except (OSError, ValueError):
            cache = {}
        hit = cache.get(model.lower())
        if hit and (time.time() - hit["t"] < 7 * 86400 or not online):
            return hit["v"]
    if not online:
        return None
    global _nvd_last
    wait = 6.5 - (time.time() - _nvd_last)            # NVD allows 5 requests per 30 seconds without a key
    if wait > 0:
        time.sleep(wait)
    _nvd_last = time.time()
    j = json.loads(_get(NVD + "?" + urllib.parse.urlencode({"keywordSearch": model, "keywordExactMatch": "", "resultsPerPage": 50}),
                        timeout=30))
    vulns = [v["cve"] for v in j.get("vulnerabilities", [])]
    cutoff = (_dt.date.today() - _dt.timedelta(days=3 * 365)).isoformat()
    vulns.sort(key=lambda c: c.get("published", ""), reverse=True)
    res = {"total": j.get("totalResults", len(vulns)), "recent": sum(1 for c in vulns if c.get("published", "") >= cutoff),
           "latest": [c["id"] for c in vulns[:3]]}
    with _lock:
        try:
            cache = json.loads(p.read_text())
        except (OSError, ValueError):
            cache = {}
        cache[model.lower()] = {"t": time.time(), "v": res}
        CACHE.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(cache))
    return res


# ---------------------------------------------------------------------------
# Background refresh
# ---------------------------------------------------------------------------
SCHEDULE = [("ieee", 30, refresh_ieee, CACHE / "ieee.json.gz"), ("android", 7, refresh_android, CACHE / "android.json.gz"),
            ("iana", 30, refresh_iana, CACHE / "iana.json.gz")]


def refresh_due(brands: list[str] | None = None, force: bool = False) -> dict:
    """Refresh whatever is out of date. Safe to call from a background thread."""
    done = {}
    for name, days, fn, path in SCHEDULE:
        if force or _age_days(path) > days:
            try:
                fn()
                done[name] = "updated"
                STATUS.setdefault(name, {})["updated"] = _dt.datetime.now().isoformat(timespec="seconds")
            except Exception as exc:
                done[name] = f"failed: {exc}"[:120]
                STATUS.setdefault(name, {})["error"] = str(exc)[:120]
    if brands and (force or _age_days(CACHE / "brands.json") > 30):
        try:
            refresh_wikidata(brands)
            done["wikidata"] = "updated"
        except Exception as exc:
            done["wikidata"] = f"failed: {exc}"[:120]
    return done


def status() -> list[dict]:
    ieee(), android(), iana()
    rows = []
    for name, label, lic in (("ieee", "IEEE maker registries (MA-L, MA-M, MA-S)", "public registry"),
                             ("android", "Android model names (Google Play list)", "Apache-2.0 packaging"),
                             ("iana", "IANA service names", "public registry"),
                             ("recognition", "Home Assistant device rules + Apple models", "Apache-2.0 / MIT")):
        st = STATUS.get(name, {})
        if name == "recognition":
            from . import recognition
            r = recognition.data()
            st = {"entries": len(r.get("integrations", {})) + len(r.get("apple_models", {}))}
        p = {"ieee": CACHE / "ieee.json.gz", "android": CACHE / "android.json.gz", "iana": CACHE / "iana.json.gz"}.get(name)
        rows.append({"name": label, "license": lic, "entries": st.get("entries"), "source": st.get("source", "built in"),
                     "updated": _dt.datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="minutes") if p and p.exists() else None,
                     "error": st.get("error")})
    for label, f, lic in (("Matter certification ledger (CSA)", "matter.json", "public ledger"), ("Wikidata brand owners", "brands.json", "CC0"),
                          ("NVD vulnerability counts", "nvd.json", "public domain"), ("CISA exploited flaws", "kev.json", "public domain")):
        p = CACHE / f
        rows.append({"name": label, "license": lic, "entries": None, "source": "looked up when needed",
                     "updated": _dt.datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="minutes") if p.exists() else None,
                     "error": None})
    return rows
