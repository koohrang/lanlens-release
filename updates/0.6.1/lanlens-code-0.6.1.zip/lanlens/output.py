"""Terminal summary, HTML report, CSV and JSON."""
from __future__ import annotations

import csv
import datetime as _dt
import html as _html
import json
from dataclasses import asdict
from pathlib import Path

from . import __version__
from .classify import CATEGORIES, CATEGORY_LABEL

TEMPLATE = Path(__file__).parent / "report_template.html"


def payload(local, devices, seen_before: bool) -> dict:
    order = {k: i for i, (k, _) in enumerate(CATEGORIES)}
    devs = sorted(devices, key=lambda d: (order[d.category], tuple(int(x) for x in d.ip.split("."))))
    return {
        "version": __version__, "network": str(local.network), "interface": local.interface, "self_ip": local.ip,
        "gateway": local.gateway, "scanned": _dt.datetime.now().isoformat(timespec="seconds"),
        "seen_before": seen_before, "categories": CATEGORIES, "devices": [asdict(d) for d in devs],
    }


def write_all(out: Path, data: dict) -> dict[str, Path]:
    out.mkdir(parents=True, exist_ok=True)
    page = TEMPLATE.read_text()
    title = _html.escape(f"Devices on {data['network']} · lanlens")
    page = page.replace("__TITLE__", title).replace("__LANLENS_DATA__", json.dumps(data).replace("</", "<\\/"))
    paths = {"report": out / "report.html", "csv": out / "devices.csv", "json": out / "devices.json"}
    paths["report"].write_text(page)
    paths["json"].write_text(json.dumps(data, indent=2))
    with paths["csv"].open("w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["category", "type", "name", "ip", "mac", "maker", "model", "confidence", "new", "why",
                    "other_names", "services", "open_ports", "notes"])
        for d in data["devices"]:
            w.writerow([CATEGORY_LABEL[d["category"]], d["type"], d["name"] or "", d["ip"], d["mac"] or "",
                        d["vendor"] or ("private address" if d["randomized_mac"] else ""), d["model"] or "",
                        d["confidence"], "yes" if d["new"] else "", "; ".join(d["reasons"]),
                        ", ".join(d["hostnames"]), " ".join(d["services"]), " ".join(map(str, d["ports"])),
                        "; ".join(d["notes"])])
    return paths


def print_summary(data: dict, say=print) -> None:
    devs = data["devices"]
    say("")
    say(f"  {len(devs)} devices on {data['network']}")
    for key, label in CATEGORIES:
        group = [d for d in devs if d["category"] == key]
        if not group:
            continue
        say("")
        say(f"  {label.upper()} ({len(group)})")
        for d in group:
            name = (d["name"] or "(no name)")[:28]
            maker = d["vendor"] or ("private address" if d["randomized_mac"] else "")
            flag = "  NEW" if d["new"] else ""
            say(f"    {d['ip']:<15} {name:<28} {d['type'][:30]:<30} {maker[:26]}{flag}")
    new = [d for d in devs if d["new"]]
    if new:
        say("")
        say(f"  {len(new)} new since last scan: " + ", ".join(d["name"] or d["ip"] for d in new))
    say("")
