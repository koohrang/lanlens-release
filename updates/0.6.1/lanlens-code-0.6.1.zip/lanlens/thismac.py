"""'This Mac' checks: system, security settings, installed apps (versions,
developer, App Store, updates, known-exploited vulnerabilities, license hints),
background items, listening ports and active connections.

Read-only. Uses built-in macOS commands. Online lookups (latest app versions
from Homebrew's public catalog, CISA's Known Exploited Vulnerabilities list)
are optional and cached for a day.
"""
from __future__ import annotations

import concurrent.futures as cf
import datetime as _dt
import json
import os
import platform
import plistlib
import re
import socket
import subprocess
import time
from pathlib import Path

from .probes import _open

CACHE = Path.home() / ".lanlens" / "cache"
IS_MAC = platform.system() == "Darwin"


def run(cmd: list[str], timeout: float = 15) -> str:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (r.stdout or "") + (r.stderr or "")
    except (OSError, subprocess.SubprocessError):
        return ""


# ---------------------------------------------------------------------------
# System + security
# ---------------------------------------------------------------------------
def system_info(sh=run) -> dict:
    info = {"hostname": socket.gethostname(), "os": platform.platform(), "arch": platform.machine()}
    if not IS_MAC:
        return info
    sw = sh(["sw_vers"])
    pn = re.search(r"ProductName:\s*(.+)", sw)
    pv = re.search(r"ProductVersion:\s*(.+)", sw)
    info["os"] = f"{pn.group(1).strip() if pn else 'macOS'} {pv.group(1).strip() if pv else ''}".strip()
    hw = sh(["system_profiler", "SPHardwareDataType", "-json"], timeout=20)
    try:
        h = json.loads(hw)["SPHardwareDataType"][0]
        info.update({"model": h.get("machine_name"), "model_id": h.get("machine_model") or h.get("model_number"),
                     "chip": h.get("chip_type") or h.get("cpu_type"), "memory": h.get("physical_memory"),
                     "serial": h.get("serial_number")})
    except Exception:
        pass
    boot = sh(["sysctl", "-n", "kern.boottime"])
    m = re.search(r"sec = (\d+)", boot)
    if m:
        days = (time.time() - int(m.group(1))) / 86400
        info["uptime"] = f"{days:.1f} days" if days >= 1 else f"{days * 24:.1f} hours"
    return info


def security_checks(sh=run) -> list[dict]:
    """[{name, ok (True/False/None), detail, fix}]"""
    if not IS_MAC:
        return []
    checks = []

    def add(name, ok, detail, fix=""):
        checks.append({"name": name, "ok": ok, "detail": detail, "fix": fix})

    fv = sh(["fdesetup", "status"])
    add("Disk encryption (FileVault)", "FileVault is On" in fv if fv else None,
        fv.strip().splitlines()[0] if fv.strip() else "Couldn't check",
        "System Settings → Privacy & Security → FileVault → Turn On")
    fw = sh(["/usr/libexec/ApplicationFirewall/socketfilterfw", "--getglobalstate"])
    add("Firewall", ("enabled" in fw.lower() and "disabled" not in fw.lower()) if fw else None,
        fw.strip() or "Couldn't check", "System Settings → Network → Firewall → turn on")
    gk = sh(["spctl", "--status"])
    add("Gatekeeper (blocks unknown apps)", "assessments enabled" in gk if gk else None,
        gk.strip() or "Couldn't check", "Run 'sudo spctl --master-enable' or reset in System Settings → Privacy & Security")
    sip = sh(["csrutil", "status"])
    add("System Integrity Protection", "enabled" in sip.lower() if sip else None,
        sip.strip() or "Couldn't check", "Re-enable from macOS Recovery: csrutil enable")
    au = sh(["defaults", "read", "/Library/Preferences/com.apple.SoftwareUpdate", "AutomaticallyInstallMacOSUpdates"])
    add("Automatic macOS updates", au.strip() == "1" if au.strip() in ("0", "1") else None,
        "On" if au.strip() == "1" else ("Off" if au.strip() == "0" else "Not set (macOS default)"),
        "System Settings → General → Software Update → Automatic Updates")
    al = sh(["defaults", "read", "/Library/Preferences/com.apple.loginwindow", "autoLoginUser"])
    has_auto = bool(al.strip()) and "does not exist" not in al
    add("Automatic login", not has_auto, "Off" if not has_auto else f"On for {al.strip()}",
        "System Settings → Users & Groups → Automatically log in as → Off")
    rl = sh(["systemsetup", "-getremotelogin"])
    if rl.strip() and "administrator" not in rl.lower():
        add("Remote login (SSH)", "Off" in rl, rl.strip(), "System Settings → General → Sharing → Remote Login → off")
    return checks


def pending_updates(sh=run) -> dict:
    if not IS_MAC:
        return {}
    out = sh(["softwareupdate", "-l"], timeout=120)
    if "No new software available" in out:
        return {"count": 0, "items": []}
    items = re.findall(r"^\s*\*\s*Label:\s*(.+)$", out, re.M)
    if not items:
        items = re.findall(r"^\s*\*\s*(.+)$", out, re.M)
    return {"count": len(items), "items": items[:10]} if out else {}


# ---------------------------------------------------------------------------
# Apps
# ---------------------------------------------------------------------------
APP_DIRS = ["/Applications", "/Applications/Utilities", str(Path.home() / "Applications")]


def find_apps() -> list[Path]:
    apps = []
    for base in APP_DIRS:
        b = Path(base)
        if not b.is_dir():
            continue
        for p in b.iterdir():
            if p.suffix == ".app":
                apps.append(p)
            elif p.is_dir() and not p.name.startswith(".") and p.name != "Utilities":
                apps.extend(q for q in p.iterdir() if q.suffix == ".app")      # one level of folders
    return sorted(set(apps), key=lambda p: p.name.lower())


def signer(app: Path, sh=run) -> tuple[str | None, str | None]:
    """(developer, team id) from the code signature."""
    out = sh(["codesign", "-dv", "--verbose=2", str(app)], timeout=10)
    auth = re.search(r"Authority=(Developer ID Application: |Apple Mac OS Application Signing|Software Signing|Apple Distribution: )?([^\n]*)", out)
    team = re.search(r"TeamIdentifier=(\S+)", out)
    if "Authority=Software Signing" in out:
        return "Apple", "Apple"
    if "Authority=Apple Mac OS Application Signing" in out:
        dev = None
    else:
        dev = re.sub(r"\s*\([A-Z0-9]{10}\)$", "", auth.group(2)).strip() if auth else None
    if "code object is not signed" in out:
        return None, "unsigned"
    return dev, (team.group(1) if team and team.group(1) != "not" else None)


def app_info(app: Path, sh=run) -> dict | None:
    try:
        with open(app / "Contents" / "Info.plist", "rb") as fh:
            pl = plistlib.load(fh)
    except Exception:
        return None
    name = pl.get("CFBundleDisplayName") or pl.get("CFBundleName") or app.stem
    info = {
        "name": app.stem if len(app.stem) >= len(str(name)) - 2 else name,
        "file": app.name, "path": str(app), "bundle_id": pl.get("CFBundleIdentifier"),
        "version": str(pl.get("CFBundleShortVersionString") or pl.get("CFBundleVersion") or ""),
        "app_store": (app / "Contents" / "_MASReceipt" / "receipt").exists(),
    }
    dev, team = signer(app, sh)
    info["developer"] = dev
    info["team"] = team
    info["unsigned"] = team == "unsigned"
    info["license"] = license_hint(info)
    return info


def license_hint(a: dict) -> str:
    bid = (a.get("bundle_id") or "").lower()
    if a.get("app_store"):
        return "App Store purchase / download"
    if bid.startswith("com.apple."):
        return "Included with macOS"
    if bid.startswith("com.microsoft.") and Path("/Library/Preferences/com.microsoft.office.licensingV2.plist").exists():
        return "Microsoft license file present"
    if bid.startswith("com.microsoft.office") or bid in ("com.microsoft.word", "com.microsoft.excel", "com.microsoft.powerpoint",
                                                         "com.microsoft.outlook", "com.microsoft.onenote.mac"):
        return "Microsoft 365 (sign-in based)"
    if bid.startswith("com.adobe.") and Path("/Library/Application Support/Adobe/Adobe PCD").exists():
        return "Adobe Creative Cloud licensing present"
    return ""


def list_apps(sh=run) -> list[dict]:
    apps = find_apps()
    with cf.ThreadPoolExecutor(max_workers=8) as ex:
        return [a for a in ex.map(lambda p: app_info(p, sh), apps) if a]


# ---------------------------------------------------------------------------
# Online lookups (optional, cached for a day)
# ---------------------------------------------------------------------------
def _cached_json(name: str, url: str, max_age_h: float = 24, timeout: float = 25):
    CACHE.mkdir(parents=True, exist_ok=True)
    f = CACHE / name
    if f.exists() and time.time() - f.stat().st_mtime < max_age_h * 3600:
        try:
            return json.loads(f.read_text())
        except ValueError:
            pass
    try:
        with _open(url, timeout=timeout) as r:
            data = r.read()
        j = json.loads(data)
        f.write_bytes(data)
        return j
    except Exception:
        if f.exists():
            try:
                return json.loads(f.read_text())
            except ValueError:
                pass
        return None


def latest_versions() -> dict[str, str] | None:
    """App file name ('Google Chrome.app') -> latest version, from Homebrew's public cask catalog."""
    casks = _cached_json("cask.json", "https://formulae.brew.sh/api/cask.json")
    if not casks:
        return None
    out = {}
    for c in casks:
        ver = str(c.get("version") or "")
        if not ver or ver == "latest":
            continue
        ver = ver.split(",")[0]
        for art in c.get("artifacts") or []:
            if isinstance(art, dict) and "app" in art:
                for a in art["app"]:
                    if isinstance(a, str) and a.endswith(".app"):
                        out.setdefault(a.split("/")[-1], ver)
                    elif isinstance(a, dict) and str(a.get("target", "")).endswith(".app"):
                        out.setdefault(a["target"].split("/")[-1], ver)
    return out


def kev() -> list[dict] | None:
    j = _cached_json("kev.json", "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json")
    return j.get("vulnerabilities") if isinstance(j, dict) else None


def _vtuple(v: str) -> tuple:
    nums = re.findall(r"\d+", v or "")
    return tuple(int(n) for n in nums[:4])


def is_older(installed: str, latest: str) -> bool:
    a, b = _vtuple(installed), _vtuple(latest)
    if not a or not b:
        return False
    n = min(len(a), len(b), 3)
    return a[:n] < b[:n]


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def kev_matches(app: dict, vulns: list[dict]) -> list[dict]:
    name = _norm(app["name"])
    dev = _norm(app.get("developer") or "")
    hits = []
    for v in vulns:
        prod, vend = _norm(v.get("product", "")), _norm(v.get("vendorProject", ""))
        if not prod or len(prod) < 3 or prod in ("macos", "ios", "multiple products", "webkit", "kernel"):
            continue
        if re.search(rf"\b{re.escape(prod)}\b", name) and (vend in name or vend in dev or (vend and dev.startswith(vend))):
            hits.append(v)
    return hits


def enrich_apps(apps: list[dict]) -> dict:
    latest = latest_versions()
    vulns = kev()
    for a in apps:
        lv = (latest or {}).get(a["file"])
        if lv:
            a["latest"] = lv
            a["outdated"] = is_older(a["version"], lv)
        if vulns:
            hits = kev_matches(a, vulns)
            if hits:
                a["kev_count"] = len(hits)
                a["kev_latest"] = max(h.get("dateAdded", "") for h in hits)
                a["kev_examples"] = [h.get("cveID") for h in sorted(hits, key=lambda h: h.get("dateAdded", ""), reverse=True)[:3]]
        risk = []
        if a.get("outdated"):
            risk.append("update available")
        if a.get("kev_count") and a.get("outdated"):
            risk.insert(0, "outdated and has actively exploited vulnerabilities")
        if a.get("unsigned"):
            risk.append("not signed by a known developer")
        a["risk"] = risk
    return {"latest_ok": latest is not None, "kev_ok": vulns is not None}


# ---------------------------------------------------------------------------
# Background items, listening ports, connections
# ---------------------------------------------------------------------------
LAUNCH_DIRS = [Path.home() / "Library/LaunchAgents", Path("/Library/LaunchAgents"), Path("/Library/LaunchDaemons")]


def background_items() -> list[dict]:
    out = []
    for d in LAUNCH_DIRS:
        if not d.is_dir():
            continue
        for f in sorted(d.glob("*.plist")):
            try:
                with open(f, "rb") as fh:
                    pl = plistlib.load(fh)
            except Exception:
                continue
            prog = pl.get("Program") or (pl.get("ProgramArguments") or [None])[0]
            suspicious = bool(prog and re.match(r"^(/tmp|/private/tmp|/Users/Shared|/var/folders)", str(prog)))
            out.append({"label": pl.get("Label") or f.stem, "program": prog, "where": str(d).replace(str(Path.home()), "~"),
                        "runs_at_load": bool(pl.get("RunAtLoad") or pl.get("KeepAlive")),
                        "suspicious": suspicious})
    return out


def listening(sh=run) -> list[dict]:
    out = sh(["lsof", "+c", "0", "-nP", "-iTCP", "-sTCP:LISTEN"], timeout=20)
    seen, res = set(), []
    for line in out.splitlines()[1:]:
        f = line.split()
        if len(f) < 9:
            continue
        cmd, addr = f[0].replace("\\x20", " "), f[8]
        m = re.match(r"(.*):(\d+)$", addr)
        if not m:
            continue
        host, port = m.group(1), int(m.group(2))
        key = (cmd, port)
        if key in seen:
            continue
        seen.add(key)
        res.append({"process": cmd, "port": port, "address": host,
                    "exposed": host in ("*", "0.0.0.0", "[::]", "::")})
    return sorted(res, key=lambda r: (not r["exposed"], r["port"]))


def connections(sh=run) -> list[dict]:
    out = sh(["lsof", "+c", "0", "-nP", "-iTCP", "-sTCP:ESTABLISHED"], timeout=20)
    per = {}
    for line in out.splitlines()[1:]:
        f = line.split()
        if len(f) < 9 or "->" not in f[8]:
            continue
        cmd = f[0].replace("\\x20", " ")
        remote = f[8].split("->")[1].rsplit(":", 1)[0].strip("[]")
        p = per.setdefault(cmd, {"process": cmd, "count": 0, "remotes": set()})
        p["count"] += 1
        p["remotes"].add(remote)
    res = []
    for p in per.values():
        res.append({"process": p["process"], "count": p["count"], "remotes": sorted(p["remotes"])[:6],
                    "remote_count": len(p["remotes"])})
    return sorted(res, key=lambda r: -r["count"])


# ---------------------------------------------------------------------------
def collect(progress=lambda m: None) -> dict:
    t0 = time.time()
    data = {"supported": IS_MAC, "collected": _dt.datetime.now().isoformat(timespec="seconds")}
    progress("Reading system information…")
    data["system"] = system_info()
    if not IS_MAC:
        data["note"] = "Detailed checks of apps and security settings are available on macOS."
        return data
    with cf.ThreadPoolExecutor(max_workers=5) as ex:
        f_sec = ex.submit(security_checks)
        f_upd = ex.submit(pending_updates)
        f_apps = ex.submit(list_apps)
        f_bg = ex.submit(background_items)
        f_lis = ex.submit(listening)
        f_con = ex.submit(connections)
        progress("Checking security settings and apps…")
        data["security"] = f_sec.result()
        data["apps"] = f_apps.result()
        progress("Checking for app updates and known vulnerabilities…")
        data["lookups"] = enrich_apps(data["apps"])
        data["background"] = f_bg.result()
        data["listening"] = f_lis.result()
        data["connections"] = f_con.result()
        progress("Checking for macOS updates…")
        try:
            data["os_updates"] = f_upd.result(timeout=150)
        except Exception:
            data["os_updates"] = {}
    data["seconds"] = round(time.time() - t0)
    return data
