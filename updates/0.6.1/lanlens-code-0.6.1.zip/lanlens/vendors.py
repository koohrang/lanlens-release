"""MAC address -> manufacturer, using the IEEE registry bundled with netaddr (offline)."""
from __future__ import annotations

import re
from functools import lru_cache

# Special prefixes the IEEE registry doesn't name helpfully.
_SPECIAL = {
    "52:54:00": "QEMU/KVM virtual machine",
    "00:15:5d": "Microsoft Hyper-V virtual machine",
    "08:00:27": "VirtualBox virtual machine",
    "00:0c:29": "VMware virtual machine",
    "00:50:56": "VMware virtual machine",
    "00:05:69": "VMware virtual machine",
    "00:1c:42": "Parallels virtual machine",
    "02:42:ac": "Docker container",
}

_SUFFIXES = re.compile(
    r"[,.]?\s+(inc|incorporated|corp|corporation|co|company|ltd|limited|llc|gmbh|ag|sa|s\.a|bv|b\.v|"
    r"kg|oy|ab|as|plc|pte|pty|srl|spa|ulc|lp|l\.p|technologies|technology|tech|electronics|"
    r"international|holdings|group|trading|foundation|communications|network|networks|systems|"
    r"devices|mobile|manufacturing|industrial|industries)\b\.?", re.I)

# Friendlier display names for common vendors.
_PRETTY = [
    (r"^apple", "Apple"), (r"^samsung", "Samsung"), (r"^google", "Google"), (r"^nest labs", "Google Nest"),
    (r"^amazon", "Amazon"), (r"^microsoft", "Microsoft"), (r"^sony interactive", "Sony PlayStation"),
    (r"^sony", "Sony"), (r"^lg electronics|^lg innotek", "LG"), (r"^hewlett|^hp inc|^hp ", "HP"),
    (r"^seiko epson", "Epson"), (r"^brother", "Brother"), (r"^canon", "Canon"), (r"^cisco meraki", "Cisco Meraki"),
    (r"^cisco", "Cisco"), (r"^ubiquiti", "Ubiquiti"), (r"^tp-link|^tp link", "TP-Link"), (r"^netgear", "NETGEAR"),
    (r"^espressif", "Espressif (ESP32/ESP8266)"), (r"^tuya|hangzhou tuya", "Tuya"), (r"^philips lighting|^signify", "Philips Hue"),
    (r"^raspberry pi", "Raspberry Pi"), (r"^synology", "Synology"), (r"^qnap", "QNAP"), (r"^roku", "Roku"),
    (r"^sonos", "Sonos"), (r"^nintendo", "Nintendo"), (r"^intel", "Intel"), (r"^dell", "Dell"), (r"^lenovo", "Lenovo"),
    (r"^hon hai|^foxconn", "Foxconn"), (r"^xiaomi|beijing xiaomi", "Xiaomi"), (r"^huawei", "Huawei"),
    (r"^hangzhou hikvision", "Hikvision"), (r"^zhejiang dahua", "Dahua"), (r"^ring", "Ring"), (r"^arlo", "Arlo"),
    (r"^wyze", "Wyze"), (r"^ecobee", "ecobee"), (r"^belkin", "Belkin"), (r"^allterco", "Shelly"), (r"^eero", "eero"),
    (r"^arris", "ARRIS"), (r"^asustek", "ASUS"), (r"^micro-star", "MSI"), (r"^oneplus", "OnePlus"),
    (r"^motorola mobility", "Motorola"), (r"^guangdong oppo", "OPPO"), (r"^vivo mobile", "vivo"),
    (r"^vizio", "VIZIO"), (r"^tcl", "TCL"), (r"^hisense", "Hisense"), (r"^bose", "Bose"), (r"^nvidia", "NVIDIA"),
    (r"^irobot", "iRobot"), (r"^itead", "Sonoff"), (r"^western digital", "Western Digital"),
    (r"^shenzhen reolink", "Reolink"), (r"^ezviz|hangzhou ezviz", "EZVIZ"), (r"^juniper", "Juniper"),
    (r"^arista", "Arista"), (r"^fortinet", "Fortinet"), (r"^palo alto", "Palo Alto Networks"),
    (r"^aruba|^hewlett packard enterprise", "HPE Aruba"), (r"^routerboard|^mikrotik", "MikroTik"),
    (r"^space exploration", "Starlink"), (r"^texas instruments", "Texas Instruments"),
    (r"^silicon lab", "Silicon Labs"), (r"^murata", "Murata"), (r"^azurewave", "AzureWave"), (r"^liteon|^lite-on", "Lite-On"),
    (r"^realtek", "Realtek"), (r"^chamberlain", "Chamberlain (myQ)"), (r"^lutron", "Lutron"), (r"^lifi labs", "LIFX"),
]


def normalize_mac(mac: str) -> str | None:
    """'0:1a:2b:3:4:5' / '00-1A-2B-03-04-05' / '001a.2b03.0405' -> '00:1a:2b:03:04:05'"""
    if not mac:
        return None
    m = mac.strip().lower().replace("-", ":")
    if "." in m and ":" not in m:                              # Cisco dotted
        m = m.replace(".", "")
        m = ":".join(m[i:i + 2] for i in range(0, 12, 2))
    parts = m.split(":")
    if len(parts) != 6:
        return None
    try:
        parts = [f"{int(p, 16):02x}" for p in parts]
    except ValueError:
        return None
    m = ":".join(parts)
    if m in ("00:00:00:00:00:00", "ff:ff:ff:ff:ff:ff"):
        return None
    return m


def is_randomized(mac: str) -> bool:
    """Locally administered bit set: phones, tablets and laptops use these
    'private Wi-Fi addresses' by default, so the maker can't be looked up."""
    try:
        return bool(int(mac.split(":")[0], 16) & 0x02)
    except (ValueError, IndexError, AttributeError):
        return False


def pretty(org: str) -> str:
    low = org.lower().strip()
    for pat, name in _PRETTY:
        if re.search(pat, low):
            return name
    short = _SUFFIXES.sub("", org).strip(" ,.")
    short = _SUFFIXES.sub("", short).strip(" ,.")
    return short or org


@lru_cache(maxsize=4096)
def lookup(mac: str) -> tuple[str | None, str | None]:
    """Return (display_name, registered_org)."""
    if not mac:
        return None, None
    prefix = mac[:8]
    if prefix in _SPECIAL:
        return _SPECIAL[prefix], _SPECIAL[prefix]
    if mac.startswith("02:42:"):
        return "Docker container", "Docker container"
    if is_randomized(mac):
        return None, None
    from . import datasets
    org = datasets.ieee_lookup(mac) or _oui_db().get(mac.replace(":", "")[:6])
    if not org:
        try:
            from netaddr import EUI
            org = EUI(mac).oui.registration().org
        except Exception:
            return None, None
    return pretty(org), org


_DB = None


def _oui_db() -> dict:
    """IEEE registry snapshot bundled with the app (oui-data, BSD-2-Clause)."""
    global _DB
    if _DB is None:
        import gzip
        import json
        from pathlib import Path
        try:
            with gzip.open(Path(__file__).parent / "oui.json.gz", "rt") as fh:
                _DB = json.load(fh)
        except Exception:
            _DB = {}
    return _DB


# ---------------------------------------------------------------------------
# Maker from what a device announces (for private Wi-Fi addresses)
# ---------------------------------------------------------------------------
_APPLE_MODEL = re.compile(r"^(iPhone|iPad|iPod|Watch|AppleTV|AudioAccessory|MacBook|iMac|Macmini|MacPro|Mac\d|Mac1\d|VirtualMac)", re.I)
# Bonjour services only Apple's own operating systems advertise
_APPLE_SERVICES = {"_companion-link._tcp", "_apple-mobdev2._tcp", "_rdlink._tcp", "_sleep-proxy._udp",
                   "_apple-pairable._tcp", "_airdrop._tcp", "_apple-midi._udp", "_continuity._tcp"}
_NAME_MAKERS = [
    (r"iphone|ipad|ipod|macbook|imac|mac-?mini|mac-?studio|mac-?pro|apple-?tv|homepod|apple-?watch", "Apple"),
    (r"galaxy|samsung|\bsm-[agsnftx]\d", "Samsung"), (r"\bpixel\b|pixel-|chromecast|google-?home|nest-", "Google"),
    (r"oneplus", "OnePlus"), (r"xiaomi|redmi|\bpoco\b|\bmi-\d", "Xiaomi"), (r"huawei|honor-", "Huawei"),
    (r"\boppo\b|oppo-", "OPPO"), (r"\bvivo\b|vivo-", "vivo"), (r"motorola|\bmoto[- ]?[gezx]\b", "Motorola"),
    (r"xperia", "Sony"), (r"playstation|\bps[45]\b|ps[45]-", "Sony"), (r"xbox|surface", "Microsoft"),
    (r"nintendo|\bswitch\b", "Nintendo"), (r"kindle|echo-|fire-?tv|amazon-", "Amazon"), (r"roku", "Roku"),
    (r"nokia", "Nokia"), (r"\blg-|lgwebostv|webos", "LG"),
]


def maker_from_clues(model: str | None, services: list[str], names: list[str], ports: list[int],
                     upnp_maker: str | None = None, cast_maker: str | None = None) -> tuple[str, str] | None:
    """(maker, why) worked out from announcements, or None."""
    if model and _APPLE_MODEL.match(model):
        return "Apple", f"reports Apple model {model}"
    svc = set(services or [])
    hit = svc & _APPLE_SERVICES
    if hit:
        return "Apple", f"advertises Apple-only {sorted(hit)[0].strip('_').split('._')[0]} (Bonjour)"
    if 62078 in (ports or []):
        return "Apple", "has the iPhone/iPad sync port open"
    if cast_maker:
        return pretty(cast_maker), "names its maker over Google Cast"
    if upnp_maker:
        return pretty(upnp_maker), "names its maker over UPnP"
    text = " ".join(n for n in names if n).lower()
    for pat, maker in _NAME_MAKERS:
        if re.search(pat, text):
            return maker, "its name suggests it"
    return None
