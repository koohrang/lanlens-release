"""Run a full scan: find devices, ask them who they are, classify them."""
from __future__ import annotations

import concurrent.futures as cf
import datetime as _dt
import ipaddress
import json
import re
from pathlib import Path

from . import datasets, identify, net, probes, recognition
from .classify import Device, classify, risk_notes
from .vendors import is_randomized, lookup, maker_from_clues

_JUNK_NAME = re.compile(r"^([0-9a-f]{2}[:-]?){6}$|^[0-9a-f-]{20,}$|^(unknown|localhost|espressif|esp_[0-9a-f]+)$", re.I)


def clean_name(n: str | None) -> str | None:
    if not n:
        return None
    n = n.strip().rstrip(".")
    n = re.sub(r"\.(local|lan|home|localdomain|home\.arpa|router|fritz\.box|domain|internal)$", "", n, flags=re.I)
    n = n.replace("\\032", " ").replace("\\.", ".")
    n = re.sub(r"^[0-9A-F]{12}@", "", n)                              # AirPlay '36CF52A4B29D@Reza's Mac'
    if re.fullmatch(r"[0-9A-Fa-f]{12,}", n):                           # bare hardware IDs
        return None
    n = re.sub(r"[-_ ]?[0-9a-f]{24,}$", "", n, flags=re.I)          # Chromecast-<uuid>
    n = re.sub(r"\s*\[[0-9A-F]{6}\]$", "", n)                       # 'HP LaserJet [A1B2C3]'
    n = re.sub(r"\s*\[([0-9a-f]{2}:){5}[0-9a-f]{2}\]$", "", n, flags=re.I)  # 'pihole [dc:a6:..]'
    n = re.sub(r"\s*\(\d+\.\d+\.\d+\.\d+\)$", "", n)                         # 'Philips hue (192.168.1.5)'
    if not n or _JUNK_NAME.match(n) or re.match(r"^\d+\.\d+\.\d+\.\d+$", n):
        return None
    return n


def best_name(cands: list[tuple[int, str | None]]) -> str | None:
    best, score = None, -1
    for w, n in cands:
        n = clean_name(n)
        if not n:
            continue
        s = w + (1 if " " in n or "’" in n or "'" in n else 0)
        if s > score:
            best, score = n, s
    return best


def raise_fd_limit(want: int = 4096) -> int:
    """macOS starts apps with a limit of 256 open files; a scan needs more.
    Raise our own soft limit (no admin rights needed) and return what we got."""
    try:
        import resource
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        target = want if hard == resource.RLIM_INFINITY else min(want, hard)
        for t in (target, 2048, 1024):
            if t <= soft:
                return soft
            try:
                resource.setrlimit(resource.RLIMIT_NOFILE, (t, hard))
                return t
            except (ValueError, OSError):
                continue
        return soft
    except Exception:             # Windows has no such limit
        return 4096


def network_key(local: net.LocalNet, devices: list[Device]) -> str:
    gw = next((d.mac for d in devices if d.is_gateway and d.mac), None)
    return f"{local.network}|{gw or ''}"


def scan(interface: str | None = None, subnet: str | None = None, ports: bool = True,
         max_hosts: int = 4096, progress=print, deep: bool = True) -> tuple[net.LocalNet, list[Device]]:
    fd_limit = raise_fd_limit()
    # each port-check worker holds one socket per port at once; leave headroom
    workers = max(4, min(48, (fd_limit - 150) // (len(probes.PORTS) + 4)))
    local = net.detect(interface, subnet)
    t0 = _dt.datetime.now()
    found = net.sweep(local, max_hosts=max_hosts, progress=progress)
    found.pop(local.ip, None)                      # macOS lists its own address too
    ips = sorted(found, key=lambda x: ipaddress.ip_address(x))
    progress(f"Found {len(ips) + 1} devices (including this computer). Identifying them…")
    all_ips = ips + [local.ip]

    with cf.ThreadPoolExecutor(max_workers=5) as ex:
        f_mdns = ex.submit(probes.mdns_browse, local.ip, 5.0)
        f_ssdp = ex.submit(probes.ssdp_discover, local.ip, 3.5)
        f_nb = ex.submit(probes.netbios_names, ips)
        f_mrev = ex.submit(probes.mdns_reverse, ips)
        f_hosts = ex.submit(probes.probe_hosts, ips, ports, workers)
        mdns, ssdp, nb, mrev, ev = (f_mdns.result(), f_ssdp.result(), f_nb.result(),
                                    f_mrev.result(), f_hosts.result())
    extra = {}
    if deep:
        progress("Looking closer at devices that didn't say much…")
        try:
            extra = identify.run_all(local.network, local.ip, ips, {ip: e.ports for ip, e in ev.items()},
                                     workers=max(4, workers // 2))
        except Exception:
            extra = {}

    devices = []
    for ip in all_ips:
        is_self = ip == local.ip
        mac = local.mac if is_self else found.get(ip)
        vendor, org = lookup(mac) if mac else (None, None)
        e = ev.get(ip) or probes.Evidence(ip=ip)
        m = mdns.get(ip, {})
        s = ssdp.get(ip, {})
        x = extra.get(ip, {})
        nbn = nb.get(ip, (None, None))
        txt = m.get("txt", {})
        model = txt.get("model") or txt.get("md") or txt.get("ty") or txt.get("usb_mdl") or txt.get("product") \
            or txt.get("am") or s.get("modelName")
        for src in ("kasa", "ubiquiti", "yeelight", "roku", "cast"):
            if not model and x.get(src, {}).get("model"):
                model = x[src]["model"]
        hostnames = [h for h in [mrev.get(ip), *m.get("hosts", []), nbn[0], e.rdns,
                                 x.get("snmp", {}).get("name")] if h]
        insts = m.get("instances", [])
        name = best_name([(6, s.get("friendlyName")), (6, txt.get("fn")), *[(5, i) for i in insts],
                          (6, x.get("kasa", {}).get("name")), (6, x.get("cast", {}).get("name")),
                          (6, x.get("roku", {}).get("name")), (5, x.get("ubiquiti", {}).get("name")),
                          (5, x.get("yeelight", {}).get("name")), (4, x.get("snmp", {}).get("name")),
                          (4, mrev.get(ip)), *[(4, h) for h in m.get("hosts", [])], (3, nbn[0]), (2, e.rdns)])
        if is_self and not name:
            import socket
            name = clean_name(socket.gethostname())
        rtt, ttl = x.get("ping", (None, None))
        d = Device(
            ip=ip, mac=mac, vendor=vendor, vendor_org=org, randomized_mac=bool(mac and is_randomized(mac)),
            name=name, hostnames=sorted({clean_name(h) for h in hostnames if clean_name(h)}),
            model=(model or None), services=sorted(m.get("services", [])), ports=e.ports,
            upnp={k: v for k, v in s.items() if k in ("friendlyName", "manufacturer", "modelName",
                                                       "modelDescription", "deviceType", "server", "st") and v},
            http_title=e.http_title, is_self=is_self, is_gateway=(ip == local.gateway),
            rtt_ms=rtt, ttl=ttl, os_guess=identify.os_from_ttl(ttl), identity=_identity_lines(x, e),
        )
        if not d.vendor and s.get("manufacturer"):
            d.vendor = s["manufacturer"]
        if not d.vendor and x.get("cast", {}).get("maker"):
            d.vendor = x["cast"]["maker"]
        hits = recognition.match(mac=mac, hostnames=[d.name, *d.hostnames, *hostnames], services=d.services,
                                 svc_txt=m.get("svc_txt"), svc_inst=m.get("svc_inst"), upnp=d.upnp)
        x = {**x, "rules": hits}
        guessed = None
        top = recognition.best_brand(hits)
        if top and (not d.vendor or recognition.is_chip_maker(d.vendor)):
            if d.vendor and d.vendor != top["brand"]:
                d.identity["Wi-Fi chip by"] = d.vendor
            d.vendor = top["brand"]
            d.vendor_org = f"{top['brand']} (recognized from what it announces)"
        if not d.vendor:
            # private Wi-Fi address (or unknown prefix): use what the device says about itself
            guessed = maker_from_clues(d.model, d.services, [d.name, *d.hostnames], d.ports)
            if guessed:
                d.vendor = guessed[0]
                d.vendor_org = f"{guessed[0]} (worked out from what it announces)"
        classify(d, x)
        if guessed:
            d.reasons.append(f"Maker: {guessed[0]}, because it {guessed[1]}")
        nice = recognition.apple_name(d.model)
        if nice:
            d.identity["Apple model code"] = d.model
            d.model = nice
        _enrich(d, m)
        if d.is_gateway and (not d.name or re.search(r"border ?router|openthread", d.name, re.I)):
            d.name = f"{d.vendor} router" if d.vendor else "Your router"
        d.notes = risk_notes(d)
        devices.append(d)
    progress(f"Done in {(_dt.datetime.now() - t0).seconds}s.")
    return local, devices


def _enrich(d: Device, m: dict) -> None:
    """Android model names, Matter ledger, brand owner/platform facts."""
    an = datasets.android_lookup(d.model) or next(filter(None, (datasets.android_lookup(h) for h in d.hostnames)), None)
    if an:
        brand, name = an
        if d.model and d.model.upper() != name.upper():
            d.identity["Android model code"] = d.model
        d.model = name
        if brand and (not d.vendor or recognition.is_chip_maker(d.vendor)):
            d.vendor, d.vendor_org = brand, f"{brand} (from its Android model code)"
        d.reasons.append(f"Model: {name} (Google Play device list)")
    vid, pid = datasets.matter_ids(d.services, m.get("svc_txt"))
    if vid:
        try:
            info = datasets.matter_lookup(vid, pid, online=datasets.ONLINE)
        except Exception:
            info = None
        d.identity["Matter IDs"] = f"vendor {vid}" + (f", product {pid}" if pid else "")
        if info:
            if info.get("vendor"):
                d.identity["Matter vendor"] = info["vendor"]
                if not d.vendor or recognition.is_chip_maker(d.vendor):
                    d.vendor, d.vendor_org = info["vendor"], f"{info['vendor']} (Matter certification ledger)"
            if info.get("product") and not d.model:
                d.model = info["product"]
    facts = datasets.brand_facts(d.vendor_org or d.vendor)
    if facts.get("owner"):
        d.identity["Owned by"] = facts["owner"] + (" (Wikidata)" if facts.get("owner_source") else "")
    if facts.get("platform"):
        d.identity["Built on"] = facts["platform"]
    meanings = [f"{s.strip('_').split('._')[0]}: {datasets.service_meaning(s)}" for s in d.services if datasets.service_meaning(s)]
    if meanings:
        d.identity["Services"] = "; ".join(dict.fromkeys(meanings))[:400]


def _identity_lines(x: dict, e) -> dict:
    out = {}
    if x.get("kasa"):
        out["TP-Link Kasa"] = " · ".join(filter(None, [x["kasa"].get("name"), x["kasa"].get("model"), x["kasa"].get("desc")]))
    if x.get("ubiquiti"):
        out["Ubiquiti"] = " · ".join(filter(None, [x["ubiquiti"].get("name"), x["ubiquiti"].get("model"),
                                                  x["ubiquiti"].get("firmware")]))
    if x.get("yeelight"):
        out["Yeelight"] = " · ".join(filter(None, [x["yeelight"].get("name"), x["yeelight"].get("model")]))
    if x.get("tuya"):
        out["Tuya"] = "broadcasts as a Tuya smart device" + (f" (product {x['tuya']['model']})" if x["tuya"].get("model") else "")
    if x.get("snmp"):
        out["SNMP"] = " · ".join(filter(None, [x["snmp"].get("name"), (x["snmp"].get("descr") or "")[:120]]))
    if x.get("cast"):
        out["Google Cast"] = " · ".join(filter(None, [x["cast"].get("name"), x["cast"].get("model")]))
    if x.get("roku"):
        out["Roku"] = " · ".join(filter(None, [x["roku"].get("name"), x["roku"].get("model")]))
    if x.get("cert"):
        c = x["cert"]
        out["HTTPS certificate"] = " · ".join(filter(None, [c.get("cn"), c.get("org"), f"issued by {c['issuer']}" if c.get("issuer") else None]))
    if x.get("ssh"):
        out["SSH"] = x["ssh"]
    if e.http_server:
        out["Web server"] = e.http_server
    return {k: v for k, v in out.items() if v}
