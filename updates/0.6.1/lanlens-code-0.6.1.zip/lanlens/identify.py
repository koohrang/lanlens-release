"""Deeper identification for devices that don't announce a name.

Each probe uses a device's own local discovery/management protocol, read-only:
  * Ping                 - online check, response time, OS family hint (TTL)
  * TP-Link Kasa         - UDP 9999 'get_sysinfo' -> alias, model
  * Ubiquiti discovery   - UDP 10001 -> hostname, model, firmware
  * Yeelight             - SSDP-style search on 1982 -> model, name
  * Tuya                 - listens for the broadcasts Tuya devices send
  * SNMP (public)        - sysName / sysDescr from printers, NAS, network gear
  * Google Cast          - /setup/eureka_info -> device name, model
  * Roku ECP             - /query/device-info -> name, model
  * TLS certificate      - subject/issuer of the device's HTTPS certificate
  * SSH banner           - the greeting line (e.g. dropbear on embedded devices)
"""
from __future__ import annotations

import concurrent.futures as cf
import ipaddress
import json
import os
import platform
import random
import re
import socket
import ssl
import struct
import subprocess
import tempfile
import time
import xml.etree.ElementTree as ET

from .probes import _open

SYSTEM = platform.system()


# ---------------------------------------------------------------------------
# Ping: online, latency, TTL
# ---------------------------------------------------------------------------
def ping(ip: str) -> tuple[float | None, int | None]:
    if SYSTEM == "Windows":
        cmd = ["ping", "-n", "1", "-w", "1000", ip]
    elif SYSTEM == "Darwin":
        cmd = ["ping", "-c", "1", "-t", "2", ip]
    else:
        cmd = ["ping", "-c", "1", "-W", "1", ip]
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=4).stdout
    except (OSError, subprocess.SubprocessError):
        return None, None
    m_ttl = re.search(r"ttl[=:](\d+)", out, re.I)
    m_t = re.search(r"time[=<]([\d.]+)\s*ms", out, re.I)
    return (float(m_t.group(1)) if m_t else None), (int(m_ttl.group(1)) if m_ttl else None)


def os_from_ttl(ttl: int | None) -> str | None:
    if not ttl:
        return None
    if ttl <= 64:
        return "Apple / Linux / Android / embedded"
    if ttl <= 128:
        return "Windows (or Xbox)"
    return "Network device / embedded"


def ping_all(ips: list[str], workers: int = 24) -> dict[str, tuple]:
    with cf.ThreadPoolExecutor(max_workers=workers) as ex:
        return dict(zip(ips, ex.map(ping, ips)))


# ---------------------------------------------------------------------------
# TP-Link Kasa (UDP 9999, XOR "autokey" obfuscation, start key 171)
# ---------------------------------------------------------------------------
def _kasa_enc(s: str) -> bytes:
    k, out = 171, bytearray()
    for c in s.encode():
        k = k ^ c
        out.append(k)
    return bytes(out)


def _kasa_dec(b: bytes) -> str:
    k, out = 171, bytearray()
    for c in b:
        out.append(k ^ c)
        k = c
    return out.decode("utf-8", "ignore")


def _udp_collect(send, port_filter=None, wait=2.5, bind_port=0, bcast=True) -> dict[str, bytes]:
    got: dict[str, bytes] = {}
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        if bcast:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        s.bind(("", bind_port))
        s.settimeout(0.25)
        send(s)
        end = time.time() + wait
        while time.time() < end:
            try:
                data, (ip, port) = s.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                break
            if port_filter is None or port == port_filter:
                got.setdefault(ip, data)
    return got


def kasa(broadcast: str, ips: list[str]) -> dict[str, dict]:
    pkt = _kasa_enc('{"system":{"get_sysinfo":{}}}')

    def send(s):
        for target in [broadcast] + ips:
            try:
                s.sendto(pkt, (target, 9999))
            except OSError:
                pass
    out = {}
    for ip, data in _udp_collect(send, 9999).items():
        try:
            info = json.loads(_kasa_dec(data))["system"]["get_sysinfo"]
        except Exception:
            continue
        out[ip] = {"name": info.get("alias"), "model": info.get("model"),
                   "kind": info.get("type") or info.get("mic_type"), "desc": info.get("dev_name")}
    return out


# ---------------------------------------------------------------------------
# Ubiquiti discovery (UDP 10001)
# ---------------------------------------------------------------------------
def ubiquiti(broadcast: str, ips: list[str]) -> dict[str, dict]:
    def send(s):
        for target in [broadcast] + ips:
            try:
                s.sendto(b"\x01\x00\x00\x00", (target, 10001))
            except OSError:
                pass
    out = {}
    for ip, data in _udp_collect(send, 10001).items():
        if len(data) < 4 or data[0] not in (1, 2):
            continue
        info, off = {}, 4
        while off + 3 <= len(data):
            t, ln = data[off], struct.unpack(">H", data[off + 1:off + 3])[0]
            v = data[off + 3:off + 3 + ln]
            off += 3 + ln
            if t == 0x0B:
                info["name"] = v.decode("utf-8", "ignore")
            elif t in (0x0C, 0x14) and v:
                info["model"] = v.decode("utf-8", "ignore")
            elif t == 0x03:
                info["firmware"] = v.decode("utf-8", "ignore")
        if info:
            out[ip] = info
    return out


# ---------------------------------------------------------------------------
# Yeelight (multicast 239.255.255.250:1982)
# ---------------------------------------------------------------------------
def yeelight(local_ip: str) -> dict[str, dict]:
    msg = b'M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1982\r\nMAN: "ssdp:discover"\r\nST: wifi_bulb\r\n\r\n'

    def send(s):
        try:
            s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(local_ip))
        except OSError:
            pass
        s.sendto(msg, ("239.255.255.250", 1982))
    out = {}
    for ip, data in _udp_collect(send, None, wait=2.0, bcast=False).items():
        txt = data.decode("utf-8", "ignore")
        if "yeelight" not in txt.lower():
            continue
        hdr = dict((k.strip().lower(), v.strip()) for k, v in (l.split(":", 1) for l in txt.split("\r\n") if ":" in l))
        out[ip] = {"model": hdr.get("model"), "name": hdr.get("name") or None}
    return out


# ---------------------------------------------------------------------------
# Tuya: devices broadcast on UDP 6666 (plain) / 6667 (encrypted) every few s
# ---------------------------------------------------------------------------
def tuya_listen(wait: float = 6.0) -> dict[str, dict]:
    seen: dict[str, dict] = {}
    socks = []
    for port in (6666, 6667):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            if hasattr(socket, "SO_REUSEPORT"):
                try:
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
                except OSError:
                    pass
            s.bind(("", port))
            s.settimeout(0.2)
            socks.append(s)
        except OSError:
            continue
    end = time.time() + wait
    while socks and time.time() < end:
        for s in socks:
            try:
                data, (ip, _) = s.recvfrom(2048)
            except (socket.timeout, OSError):
                continue
            if data[:4] == b"\x00\x00\x55\xaa":
                info = {"kind": "Tuya smart device"}
                m = re.search(rb'"productKey"\s*:\s*"([^"]+)"', data)
                if m:
                    info["model"] = m.group(1).decode()
                seen.setdefault(ip, info)
    for s in socks:
        s.close()
    return seen


# ---------------------------------------------------------------------------
# SNMP v2c GET with community 'public' (minimal BER)
# ---------------------------------------------------------------------------
SNMP_OIDS = {"1.3.6.1.2.1.1.1.0": "descr", "1.3.6.1.2.1.1.5.0": "name", "1.3.6.1.2.1.1.2.0": "object_id"}


def _ber_len(n: int) -> bytes:
    if n < 0x80:
        return bytes([n])
    b = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(b)]) + b


def _tlv(tag: int, v: bytes) -> bytes:
    return bytes([tag]) + _ber_len(len(v)) + v


def _int(n: int) -> bytes:
    return _tlv(0x02, n.to_bytes(max(1, (n.bit_length() + 8) // 8), "big", signed=True))


def _oid(o: str) -> bytes:
    p = [int(x) for x in o.split(".")]
    out = bytearray([p[0] * 40 + p[1]])
    for n in p[2:]:
        chunk = [n & 0x7F]
        n >>= 7
        while n:
            chunk.append(0x80 | (n & 0x7F))
            n >>= 7
        out += bytes(reversed(chunk))
    return _tlv(0x06, bytes(out))


def snmp_packet(reqid: int, community: str = "public") -> bytes:
    vbs = b"".join(_tlv(0x30, _oid(o) + b"\x05\x00") for o in SNMP_OIDS)
    pdu = _tlv(0xA0, _int(reqid) + _int(0) + _int(0) + _tlv(0x30, vbs))
    return _tlv(0x30, _int(1) + _tlv(0x04, community.encode()) + pdu)


def _ber_read(b: bytes, i: int):
    tag = b[i]
    ln = b[i + 1]
    i += 2
    if ln & 0x80:
        n = ln & 0x7F
        ln = int.from_bytes(b[i:i + n], "big")
        i += n
    return tag, b[i:i + ln], i + ln


def _oid_str(v: bytes) -> str:
    p = [v[0] // 40, v[0] % 40]
    n = 0
    for c in v[1:]:
        n = (n << 7) | (c & 0x7F)
        if not c & 0x80:
            p.append(n)
            n = 0
    return ".".join(map(str, p))


def snmp_parse(data: bytes) -> dict[str, str]:
    out = {}
    _, msg, _ = _ber_read(data, 0)
    i = 0
    _, _, i = _ber_read(msg, i)          # version
    _, _, i = _ber_read(msg, i)          # community
    _, pdu, _ = _ber_read(msg, i)
    j = 0
    for _ in range(3):
        _, _, j = _ber_read(pdu, j)      # reqid, error, index
    _, vbl, _ = _ber_read(pdu, j)
    k = 0
    while k < len(vbl):
        _, vb, k = _ber_read(vbl, k)
        _, oid, m = _ber_read(vb, 0)
        tag, val, _ = _ber_read(vb, m)
        name = SNMP_OIDS.get(_oid_str(oid))
        if not name or tag in (0x05, 0x80, 0x81, 0x82):
            continue
        out[name] = _oid_str(val) if tag == 0x06 else val.decode("utf-8", "ignore").strip()
    return out


def snmp(ips: list[str], wait: float = 2.0) -> dict[str, dict]:
    def send(s):
        for ip in ips:
            try:
                s.sendto(snmp_packet(random.randint(1, 2**30)), (ip, 161))
            except OSError:
                pass
    out = {}
    for ip, data in _udp_collect(send, 161, wait=wait, bcast=False).items():
        try:
            info = snmp_parse(data)
        except Exception:
            continue
        if info:
            out[ip] = info
    return out


# ---------------------------------------------------------------------------
# HTTP-based: Google Cast, Roku
# ---------------------------------------------------------------------------
def cast_info(ip: str) -> dict | None:
    try:
        with _open(f"http://{ip}:8008/setup/eureka_info?params=name,device_info", timeout=2.5) as r:
            j = json.loads(r.read(100_000))
        di = j.get("device_info") or {}
        return {"name": j.get("name"), "model": di.get("model_name") or j.get("model_name"),
                "maker": di.get("manufacturer")}
    except Exception:
        return None


def roku_info(ip: str) -> dict | None:
    try:
        with _open(f"http://{ip}:8060/query/device-info", timeout=2.5) as r:
            root = ET.fromstring(r.read(100_000))
        g = lambda t: (root.findtext(t) or "").strip() or None
        return {"name": g("user-device-name") or g("friendly-device-name"), "model": g("friendly-model-name") or g("model-name"),
                "is_tv": g("is-tv") == "true"}
    except Exception:
        return None


# ---------------------------------------------------------------------------
# TLS certificate and SSH banner
# ---------------------------------------------------------------------------
def tls_cert(ip: str, port: int) -> dict | None:
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        with socket.create_connection((ip, port), timeout=2.5) as raw:
            with ctx.wrap_socket(raw, server_hostname=None) as s:
                der = s.getpeercert(binary_form=True)
    except Exception:
        return None
    if not der:
        return None
    try:
        with tempfile.NamedTemporaryFile("w", suffix=".pem", delete=False) as fh:
            fh.write(ssl.DER_cert_to_PEM_cert(der))
            path = fh.name
        try:
            info = ssl._ssl._test_decode_cert(path)     # stdlib decoder (no extra packages)
        finally:
            os.unlink(path)
    except Exception:
        return None

    def flat(x):
        d = {}
        for rdn in x or ():
            for k, v in rdn:
                d[k] = v
        return d
    subj, iss = flat(info.get("subject")), flat(info.get("issuer"))
    sans = [v for k, v in info.get("subjectAltName", ()) if k == "DNS"][:4]
    out = {"cn": subj.get("commonName"), "org": subj.get("organizationName"),
           "issuer": iss.get("organizationName") or iss.get("commonName"), "sans": sans}
    return {k: v for k, v in out.items() if v}


def ssh_banner(ip: str) -> str | None:
    try:
        with socket.create_connection((ip, 22), timeout=2.5) as s:
            s.settimeout(2.5)
            data = s.recv(256)
        line = data.split(b"\n")[0].decode("utf-8", "ignore").strip()
        return line if line.startswith("SSH-") else None
    except Exception:
        return None


# ---------------------------------------------------------------------------
def broadcast_of(network: ipaddress.IPv4Network) -> str:
    return str(network.broadcast_address)


def run_all(network, local_ip: str, ips: list[str], ports: dict[str, list[int]], workers: int = 16) -> dict:
    """Returns {ip: {"ping": (rtt, ttl), "kasa": {...}, ...}}."""
    res: dict[str, dict] = {ip: {} for ip in ips}
    bcast = broadcast_of(network)
    with cf.ThreadPoolExecutor(max_workers=7) as ex:
        jobs = {
            "ping": ex.submit(ping_all, ips),
            "kasa": ex.submit(kasa, bcast, ips),
            "ubiquiti": ex.submit(ubiquiti, bcast, ips),
            "yeelight": ex.submit(yeelight, local_ip),
            "tuya": ex.submit(tuya_listen),
            "snmp": ex.submit(snmp, ips),
        }
        per_host = {}

        def host(ip):
            p = set(ports.get(ip, []))
            r = {}
            if 8008 in p:
                r["cast"] = cast_info(ip)
            if 8060 in p:
                r["roku"] = roku_info(ip)
            for port in (443, 8443):
                if port in p:
                    c = tls_cert(ip, port)
                    if c:
                        r["cert"] = c
                        break
            if 22 in p:
                r["ssh"] = ssh_banner(ip)
            return ip, {k: v for k, v in r.items() if v}
        with cf.ThreadPoolExecutor(max_workers=workers) as hx:
            for ip, r in hx.map(host, ips):
                per_host[ip] = r
        for name, fut in jobs.items():
            try:
                val = fut.result()
            except Exception:
                continue
            for ip, v in val.items():
                if ip in res and v:
                    res[ip][name] = v
    for ip, r in per_host.items():
        res[ip].update(r)
    return res
