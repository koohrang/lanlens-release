"""Ask devices who they are, using the protocols they already speak.

* Reverse DNS  - the name your router's DHCP/DNS gave the device
* mDNS/Bonjour - Apple devices, printers, Chromecasts, smart-home gear
* SSDP/UPnP    - TVs, routers, media players, many IoT devices
* NetBIOS      - Windows PCs and NAS boxes
* A few TCP ports + the web page title, for devices that announce nothing

All are standard, read-only lookups. Nothing is logged in to or changed.
"""
from __future__ import annotations

import concurrent.futures as cf
import html
import random
import re
import socket
import ssl
import struct
import time
import urllib.request
import xml.etree.ElementTree as ET
from collections import defaultdict
from dataclasses import dataclass, field

# Never send LAN requests through a configured web proxy.
_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))
_OPENER_TLS = None


def _open(url: str, timeout: float):
    global _OPENER_TLS
    if url.startswith("https"):
        if _OPENER_TLS is None:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE           # LAN devices use self-signed certificates
            _OPENER_TLS = urllib.request.build_opener(urllib.request.ProxyHandler({}),
                                                      urllib.request.HTTPSHandler(context=ctx))
        return _OPENER_TLS.open(urllib.request.Request(url, headers={"User-Agent": "lanlens"}), timeout=timeout)
    return _OPENER.open(urllib.request.Request(url, headers={"User-Agent": "lanlens"}), timeout=timeout)


PORTS = {
    22: "ssh", 23: "telnet", 53: "dns", 80: "http", 443: "https", 445: "smb", 515: "lpd", 548: "afp",
    554: "rtsp", 631: "ipp", 1400: "sonos", 1883: "mqtt", 3389: "rdp", 5000: "upnp/airplay", 5900: "vnc",
    7000: "airplay", 8008: "cast-http", 8009: "cast", 8080: "http-alt", 8443: "https-alt", 8883: "mqtt-tls",
    9100: "jetdirect", 32400: "plex", 62078: "apple-lockdown",
    8060: "roku", 9999: "kasa", 6668: "tuya", 55443: "yeelight", 8123: "home-assistant", 1880: "node-red",
    8001: "samsung-tv", 8002: "samsung-tv-tls", 7547: "tr-069", 6466: "android-tv", 9295: "playstation",
}


@dataclass
class Evidence:
    ip: str
    rdns: str | None = None
    netbios: str | None = None
    netbios_group: str | None = None
    mdns_names: list[str] = field(default_factory=list)
    mdns_services: set[str] = field(default_factory=set)
    mdns_txt: dict[str, str] = field(default_factory=dict)       # model, md, fn, ty, ...
    ssdp: dict[str, str] = field(default_factory=dict)          # friendlyName, manufacturer, modelName, deviceType, server
    ports: list[int] = field(default_factory=list)
    http_title: str | None = None
    http_server: str | None = None


# ---------------------------------------------------------------------------
# Reverse DNS
# ---------------------------------------------------------------------------
def reverse_dns(ip: str) -> str | None:
    try:
        name = socket.gethostbyaddr(ip)[0]
    except (OSError, UnicodeError):
        return None
    if not name or name == ip or re.match(r"^\d+[-.]\d+[-.]\d+[-.]\d+", name):
        return None
    return name


# ---------------------------------------------------------------------------
# NetBIOS node status (UDP 137)
# ---------------------------------------------------------------------------
def _nbstat_packet() -> bytes:
    tid = random.randint(0, 0xFFFF)
    header = struct.pack(">HHHHHH", tid, 0x0000, 1, 0, 0, 0)
    name = b"\x20" + b"CKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + b"\x00"     # '*' encoded
    return header + name + struct.pack(">HH", 0x21, 0x01)


def netbios_names(ips: list[str], timeout: float = 1.5) -> dict[str, tuple[str | None, str | None]]:
    out: dict[str, tuple[str | None, str | None]] = {}
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.settimeout(0.2)
        pkt = _nbstat_packet()
        for ip in ips:
            try:
                s.sendto(pkt, (ip, 137))
            except OSError:
                pass
        end = time.time() + timeout
        while time.time() < end:
            try:
                data, (ip, _) = s.recvfrom(2048)
            except socket.timeout:
                continue
            except OSError:
                break
            try:
                # skip header(12) + name(34) + type/class/ttl/len (10)
                n = data[56]
                names = []
                for i in range(n):
                    off = 57 + i * 18
                    nm = data[off:off + 15].decode("ascii", "ignore").strip()
                    suffix = data[off + 15]
                    flags = struct.unpack(">H", data[off + 16:off + 18])[0]
                    names.append((nm, suffix, bool(flags & 0x8000)))
                host = next((nm for nm, sfx, grp in names if sfx == 0x00 and not grp), None)
                group = next((nm for nm, sfx, grp in names if sfx == 0x00 and grp), None)
                if host:
                    out[ip] = (host, group)
            except (IndexError, struct.error):
                continue
    return out


# ---------------------------------------------------------------------------
# mDNS / Bonjour
# ---------------------------------------------------------------------------
def _dns_name(labels: str) -> bytes:
    return b"".join(bytes([len(p)]) + p.encode() for p in labels.strip(".").split(".")) + b"\x00"


def _read_name(data: bytes, off: int, depth: int = 0) -> tuple[str, int]:
    labels, jumped, end = [], False, off
    while depth < 20:
        ln = data[off]
        if ln == 0:
            off += 1
            break
        if ln & 0xC0 == 0xC0:
            ptr = struct.unpack(">H", data[off:off + 2])[0] & 0x3FFF
            if not jumped:
                end = off + 2
            jumped = True
            off = ptr
            depth += 1
            continue
        labels.append(data[off + 1:off + 1 + ln].decode("utf-8", "ignore"))
        off += 1 + ln
    return ".".join(labels), (end if jumped else off)


def mdns_reverse(ips: list[str], timeout: float = 2.0) -> dict[str, str]:
    """Unicast reverse lookup straight to each device's mDNS port (Apple devices,
    Linux with Avahi, many printers answer this even with no services)."""
    out = {}
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.settimeout(0.2)
        for ip in ips:
            q = ".".join(reversed(ip.split("."))) + ".in-addr.arpa"
            pkt = struct.pack(">HHHHHH", 0, 0, 1, 0, 0, 0) + _dns_name(q) + struct.pack(">HH", 12, 0x8001)
            try:
                s.sendto(pkt, (ip, 5353))
            except OSError:
                pass
        end = time.time() + timeout
        while time.time() < end:
            try:
                data, (ip, _) = s.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                break
            try:
                qd, an = struct.unpack(">HH", data[4:8])
                off = 12
                for _ in range(qd):
                    _, off = _read_name(data, off)
                    off += 4
                for _ in range(an):
                    _, off = _read_name(data, off)
                    rtype, _, _, rdlen = struct.unpack(">HHIH", data[off:off + 10])
                    off += 10
                    if rtype == 12:
                        name, _ = _read_name(data, off)
                        if name:
                            out[ip] = name
                    off += rdlen
            except (IndexError, struct.error):
                continue
    return out


def mdns_browse(local_ip: str, wait: float = 4.0) -> dict[str, dict]:
    """Browse every advertised Bonjour service type. Returns {ip: {...}}."""
    result: dict[str, dict] = defaultdict(lambda: {"services": set(), "hosts": [], "instances": [], "txt": {},
                                                  "svc_txt": {}, "svc_inst": {}})
    try:
        from zeroconf import IPVersion, ServiceBrowser, ServiceListener, Zeroconf, ZeroconfServiceTypes
    except ImportError:
        return {}
    try:
        zc = Zeroconf(interfaces=[local_ip], ip_version=IPVersion.V4Only)
    except Exception:
        return {}
    try:
        try:
            types = set(ZeroconfServiceTypes.find(zc=zc, timeout=min(2.5, wait)))
        except Exception:
            types = set()
        types |= {"_device-info._tcp.local.", "_googlecast._tcp.local.", "_airplay._tcp.local.",
                  "_ipp._tcp.local.", "_hap._tcp.local.", "_companion-link._tcp.local."}
        infos = []

        class L(ServiceListener):
            def add_service(self, zc_, type_, name):
                infos.append((type_, name))

            def update_service(self, zc_, type_, name):
                pass

            def remove_service(self, zc_, type_, name):
                pass

        browsers = [ServiceBrowser(zc, t, L()) for t in types]
        time.sleep(wait / 2)
        seen = set()
        for type_, name in list(infos):
            if (type_, name) in seen:
                continue
            seen.add((type_, name))
            try:
                info = zc.get_service_info(type_, name, timeout=800)
            except Exception:
                info = None
            if not info:
                continue
            addrs = info.parsed_addresses(IPVersion.V4Only) if hasattr(info, "parsed_addresses") else []
            txt = {}
            for k, v in (info.properties or {}).items():
                try:
                    txt[k.decode().lower()] = (v or b"").decode("utf-8", "ignore")
                except Exception:
                    pass
            inst = name[: -len(type_) - 1] if name.endswith(type_) else name
            for ip in addrs:
                r = result[ip]
                svc = type_.replace(".local.", "")
                r["services"].add(svc)
                if svc not in r["svc_txt"]:
                    r["svc_txt"][svc] = {k: v[:120] for k, v in list(txt.items())[:40]}
                if inst and inst not in r["svc_inst"].setdefault(svc, []):
                    r["svc_inst"][svc].append(inst)
                if info.server and info.server.rstrip(".").replace(".local", "") not in r["hosts"]:
                    r["hosts"].append(info.server.rstrip(".").replace(".local", ""))
                if inst and type_.replace(".local.", "") not in ("_device-info._tcp", "_sleep-proxy._udp", "_meshcop._udp",
                                                                 "_trel._udp", "_srpl-tls._tcp", "_matter._tcp", "_matterc._udp") \
                        and inst not in r["instances"]:
                    r["instances"].append(inst)
                for k in ("model", "md", "fn", "ty", "manufacturer", "usb_mfg", "usb_mdl", "product", "am", "deviceid"):
                    if txt.get(k) and k not in r["txt"]:
                        r["txt"][k] = txt[k]
        for b in browsers:
            try:
                b.cancel()
            except Exception:
                pass
    finally:
        try:
            zc.close()
        except Exception:
            pass
    return dict(result)


# ---------------------------------------------------------------------------
# SSDP / UPnP
# ---------------------------------------------------------------------------
def ssdp_discover(local_ip: str, wait: float = 3.0) -> dict[str, dict]:
    msg = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\n"
           "MX: 2\r\nST: ssdp:all\r\n\r\n").encode()
    found: dict[str, dict] = {}
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP) as s:
        s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
        try:
            s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(local_ip))
            s.bind((local_ip, 0))
        except OSError:
            pass
        s.settimeout(0.3)
        sends = [0.0, 0.8, 1.8]
        start = time.time()
        end = start + wait
        while time.time() < end:
            while sends and time.time() - start >= sends[0]:
                sends.pop(0)
                try:
                    s.sendto(msg, ("239.255.255.250", 1900))
                except OSError:
                    return {}
            try:
                data, (ip, _) = s.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                break
            hdr = {}
            for line in data.decode("utf-8", "ignore").split("\r\n")[1:]:
                if ":" in line:
                    k, v = line.split(":", 1)
                    hdr[k.strip().lower()] = v.strip()
            d = found.setdefault(ip, {"st": set()})
            if hdr.get("st"):
                d["st"].add(hdr["st"])
            for k in ("location", "server"):
                if hdr.get(k) and k not in d:
                    d[k] = hdr[k]
    # fetch descriptions
    def fetch(ip_loc):
        ip, loc = ip_loc
        xml = None
        for attempt in range(2):
            try:
                with _open(loc, timeout=2.5) as r:
                    xml = r.read(200_000)
                break
            except Exception:
                time.sleep(0.3)
        if xml is None:
            return ip, {}
        try:
            root = ET.fromstring(xml)
            ns = {"u": root.tag.split("}")[0].strip("{")} if root.tag.startswith("{") else {}
            dev = root.find("u:device", ns) if ns else root.find("device")
            if dev is None:
                return ip, {}
            g = lambda tag: (dev.findtext(f"u:{tag}", namespaces=ns) if ns else dev.findtext(tag)) or ""
            return ip, {"friendlyName": g("friendlyName").strip(), "manufacturer": g("manufacturer").strip(),
                        "modelName": g("modelName").strip(), "modelDescription": g("modelDescription").strip(),
                        "deviceType": g("deviceType").strip()}
        except Exception:
            return ip, {}
    jobs = [(ip, d["location"]) for ip, d in found.items() if d.get("location", "").startswith("http")]
    with cf.ThreadPoolExecutor(max_workers=16) as ex:
        for ip, desc in ex.map(fetch, jobs):
            found[ip].update({k: v for k, v in desc.items() if v})
    for d in found.values():
        d["st"] = " ".join(sorted(d["st"]))
    return found


# ---------------------------------------------------------------------------
# Ports and web page title
# ---------------------------------------------------------------------------
def open_ports(ip: str, ports=PORTS, timeout: float = 1.0) -> list[int]:
    """Check all ports at once with non-blocking connects (a plain TCP
    handshake, closed immediately)."""
    import errno
    import selectors
    sel = selectors.DefaultSelector()
    socks = {}
    for p in ports:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        except OSError:                      # out of file handles: check fewer ports
            break
        s.setblocking(False)
        rc = s.connect_ex((ip, p))
        if rc in (0, errno.EINPROGRESS, errno.EWOULDBLOCK, getattr(errno, "WSAEWOULDBLOCK", -1)):
            sel.register(s, selectors.EVENT_WRITE, p)
            socks[p] = s
        else:
            s.close()
    res = []
    end = time.time() + timeout
    while socks and time.time() < end:
        for key, _ in sel.select(timeout=max(0.0, end - time.time())):
            s, p = key.fileobj, key.data
            if s.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR) == 0:
                res.append(p)
            sel.unregister(s)
            s.close()
            socks.pop(p, None)
    for s in socks.values():
        try:
            sel.unregister(s)
        except Exception:
            pass
        s.close()
    sel.close()
    return sorted(res)


def http_info(ip: str, ports: list[int]) -> tuple[str | None, str | None]:
    for p, scheme in ((80, "http"), (8080, "http"), (443, "https"), (8443, "https")):
        if p not in ports:
            continue
        try:
            with _open(f"{scheme}://{ip}:{p}/", timeout=2.5) as r:
                body = r.read(65536).decode("utf-8", "ignore")
                server = r.headers.get("Server")
        except urllib.error.HTTPError as e:
            body, server = "", e.headers.get("Server") if e.headers else None
        except Exception:
            continue
        m = re.search(r"<title[^>]*>(.*?)</title>", body, re.I | re.S)
        title = html.unescape(re.sub(r"\s+", " ", m.group(1))).strip()[:80] if m else None
        if title or server:
            return title, server
    return None, None


def probe_hosts(ips: list[str], scan_ports: bool = True, workers: int = 48) -> dict[str, Evidence]:
    ev = {ip: Evidence(ip=ip) for ip in ips}

    def one(ip):
        e = ev[ip]
        e.rdns = reverse_dns(ip)
        if scan_ports:
            # spread the order so we don't hit every device on the same port at once
            ports = list(PORTS)
            random.shuffle(ports)
            e.ports = sorted(open_ports(ip, ports))
            e.http_title, e.http_server = http_info(ip, e.ports)
    with cf.ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(one, ips))
    return ev
