"""Brand and type recognition from what devices announce, using rules taken
from Home Assistant (Apache-2.0) and Apple's model codes (MIT list). The data
lives in data/recognition.json; refresh it with update_recognition_data.py.

Everything here runs offline on this computer.
"""
from __future__ import annotations

import json
import re
from fnmatch import fnmatchcase
from functools import lru_cache
from pathlib import Path

DATA = Path(__file__).parent / "data" / "recognition.json"

# Companies that make Wi-Fi chips/modules or white-label platforms rather than the product itself
CHIP_MAKERS = re.compile(
    r"espressif|tuya|azurewave|ampak|murata|realtek|silicon lab|lite-?on|universal global|hon hai|foxconn|bilian|"
    r"rf-link|ai-link|gaoshengda|beken|bouffalo|winner ?micro|mediatek|qualcomm|broadcom|texas instruments|"
    r"microchip|nordic|cypress|marvell|cloud network technology|smart innovation|^shenzhen|^hangzhou|^zhejiang", re.I)


@lru_cache(maxsize=1)
def data() -> dict:
    try:
        return json.loads(DATA.read_text())
    except (OSError, ValueError):
        return {"integrations": {}, "rules": {"dhcp": [], "zeroconf": {}, "ssdp": [], "homekit": {}}, "apple_models": {}}


def is_chip_maker(vendor: str | None) -> bool:
    return bool(vendor and CHIP_MAKERS.search(vendor))


def apple_name(code: str | None) -> str | None:
    return data()["apple_models"].get(code or "")


def _m(value, pattern) -> bool:
    return fnmatchcase(str(value or "").lower(), str(pattern).lower())


def match(mac: str | None = None, hostnames: list[str] | None = None, services: list[str] | None = None,
          svc_txt: dict | None = None, svc_inst: dict | None = None, upnp: dict | None = None) -> list[dict]:
    """All rules this device matches: [{"domain","brand","category","type","w","why"}], strongest first."""
    D = data()
    R, I = D["rules"], D["integrations"]
    hosts = [h for h in (hostnames or []) if h]
    svc_txt, svc_inst, upnp = svc_txt or {}, svc_inst or {}, upnp or {}
    mac_hex = re.sub(r"[^0-9A-Fa-f]", "", mac or "").upper()
    hits: dict[str, dict] = {}
    rank = {"strong": 3, "medium": 2, "weak": 1}

    def add(domain, w, why):
        i = I.get(domain)
        if not i:
            return
        if domain not in hits or rank[w] > rank[hits[domain]["w"]]:
            hits[domain] = {"domain": domain, "brand": i.get("brand"), "category": i["category"], "type": i["type"],
                            "w": w if i.get("brand") else ("medium" if w == "strong" else "weak"), "why": why}

    for r in R["dhcp"]:
        hp, mp = r.get("hostname"), r.get("macaddress")
        if hp and not any(_m(h, hp) for h in hosts):
            continue
        if mp and not (mac_hex and fnmatchcase(mac_hex, mp.upper())):
            continue
        what = " and ".join(filter(None, [f"name like “{hp}”" if hp else None, "its hardware address block" if mp else None]))
        add(r["domain"], "strong" if hp and mp else "medium" if hp else "weak", f"{what} matches {I.get(r['domain'], {}).get('integration', r['domain'])} (Home Assistant rule)")
    for svc in services or []:
        for r in R["zeroconf"].get(svc, []):
            if r.get("name") and not any(_m(n, r["name"]) for n in svc_inst.get(svc, [])):
                continue
            props = r.get("properties") or {}
            if props and not all(_m((svc_txt.get(svc) or {}).get(k.lower()), v) for k, v in props.items()):
                continue
            add(r["domain"], "strong", f"advertises {svc.strip('_').split('._')[0]} like {I.get(r['domain'], {}).get('integration', r['domain'])} (Home Assistant rule)")
    md = (svc_txt.get("_hap._tcp") or svc_txt.get("_hap._udp") or {}).get("md")
    if md:
        # Home Assistant matches HomeKit models by prefix ("EB" = ecobee "EB-STATE5"); longest prefix wins
        for pat, domain in sorted(R["homekit"].items(), key=lambda kv: -len(kv[0])):
            if _m(md, pat) if any(ch in pat for ch in "*?[") else md.lower().startswith(pat.lower()):
                add(domain, "strong", f"HomeKit model “{md}”")
                break
    if upnp:
        sts = set(str(upnp.get("st", "")).split())
        for r in R["ssdp"]:
            ok = True
            for k, v in r.items():
                if k == "domain":
                    continue
                if k in ("st", "nt"):
                    if not any(_m(s, v) for s in sts):
                        ok = False
                        break
                elif not _m(upnp.get(k), v):
                    ok = False
                    break
            if ok:
                add(r["domain"], "strong", f"UPnP announcement matches {I.get(r['domain'], {}).get('integration', r['domain'])} (Home Assistant rule)")
    return sorted(hits.values(), key=lambda h: (-rank[h["w"]], h["brand"] is None))


def best_brand(hits: list[dict]) -> dict | None:
    return next((h for h in hits if h.get("brand")), None)
