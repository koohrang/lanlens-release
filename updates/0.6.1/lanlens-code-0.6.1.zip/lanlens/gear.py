"""Wired topology: log in to switches/routers (read-only, via the bundled
NetAtlas engine), map how the gear is cabled, then place every LanLens device
on the exact switch port (or Wi-Fi access point) it's connected to."""
from __future__ import annotations

import ipaddress
import json
import logging
import os
import platform
import subprocess
import threading
import traceback
from collections import defaultdict

KEYCHAIN_SERVICE = "LanLens network gear"
_mem_secrets: dict[str, str] = {}


# ---------------------------------------------------------------------------
# Password storage: macOS Keychain; elsewhere kept in memory only
# ---------------------------------------------------------------------------
def save_password(account: str, password: str) -> bool:
    if platform.system() == "Darwin":
        r = subprocess.run(["security", "add-generic-password", "-a", account, "-s", KEYCHAIN_SERVICE,
                            "-w", password, "-U"], capture_output=True, timeout=15)
        return r.returncode == 0
    _mem_secrets[account] = password
    return True


def load_password(account: str) -> str | None:
    if platform.system() == "Darwin":
        r = subprocess.run(["security", "find-generic-password", "-a", account, "-s", KEYCHAIN_SERVICE, "-w"],
                           capture_output=True, text=True, timeout=15)
        return r.stdout.rstrip("\n") if r.returncode == 0 else None
    return _mem_secrets.get(account)


def delete_password(account: str) -> None:
    if platform.system() == "Darwin":
        subprocess.run(["security", "delete-generic-password", "-a", account, "-s", KEYCHAIN_SERVICE],
                       capture_output=True, timeout=15)
    _mem_secrets.pop(account, None)


# ---------------------------------------------------------------------------
def _norm_port(p: str | None) -> str:
    from netatlas.platforms import normalize_ifname
    return (normalize_ifname(p) or "").lower()


def attach(snapshot, lan_devices: list) -> tuple[dict, dict]:
    """Return ({device_key: {"switch", "port", "via", "vlan"}}, stats)."""
    link_ports = defaultdict(set)
    for l in snapshot.links:
        link_ports[l.a].add(_norm_port(l.a_if))
        link_ports[l.b].add(_norm_port(l.b_if))
    roles = {h: d.role for h, d in snapshot.devices.items()}
    # mac -> candidate (switch, port, vlan, macs_on_port)
    per_port = defaultdict(set)
    entries = []
    for h, d in snapshot.devices.items():
        for e in getattr(d, "mac_table", []) or []:
            port = _norm_port(e["port"])
            if port in link_ports[h]:
                continue                     # learned on an uplink, not where it's plugged in
            per_port[(h, port)].add(e["mac"])
            entries.append((e["mac"], h, e["port"], e.get("vlan")))
    best: dict[str, tuple] = {}
    rank = {"access": 0, "unknown": 1, "distribution": 2, "core": 3, "edge": 4, "firewall": 5}
    for mac, sw, port, vlan in entries:
        score = (len(per_port[(sw, _norm_port(port))]), rank.get(roles.get(sw) or "unknown", 1))
        if mac not in best or score < best[mac][0]:
            best[mac] = (score, sw, port, vlan)
    out = {}
    by_port = defaultdict(list)
    for d in lan_devices:
        if not d.mac or d.mac not in best:
            continue
        _, sw, port, vlan = best[d.mac]
        out[d.key] = {"switch": sw, "port": port, "vlan": vlan, "via": None}
        by_port[(sw, _norm_port(port))].append(d)
    # Several devices on one port behind an access point -> they're Wi-Fi clients of it
    for (sw, port), devs in by_port.items():
        aps = [d for d in devs if d.category == "network" and not d.is_gateway]
        if aps and len(devs) > 1:
            ap = aps[0]
            for d in devs:
                if d is not ap:
                    out[d.key]["via"] = ap.key
    # Devices the switches know about but LanLens couldn't see (other subnets/VLANs)
    lan_macs = {d.mac for d in lan_devices if d.mac}
    arp_ips = {}
    for d in snapshot.devices.values():
        for a in getattr(d, "arp", []) or []:
            arp_ips[a["mac"]] = a["ip"]
    hidden = [m for m in best if m not in lan_macs]
    stats = {"placed": len(out), "lan_total": len([d for d in lan_devices if d.online]),
             "other_subnets": len(hidden),
             "other_subnet_examples": [{"mac": m, "ip": arp_ips.get(m), "switch": best[m][1], "port": best[m][2]}
                                       for m in hidden[:20]]}
    return out, stats


class GearMapper:
    """Runs a NetAtlas crawl in the background and keeps the latest result."""

    def __init__(self, store):
        self.store = store
        self.status = {"running": False, "stage": "", "error": None, "log": []}
        self.result = None
        self.lock = threading.Lock()

    def settings(self) -> dict:
        s = dict(self.store.data["settings"].get("gear", {}))
        s["has_password"] = bool(s.get("username") and s.get("remember") and load_password(self._account(s)))
        return s

    @staticmethod
    def _account(s: dict) -> str:
        return f"{s.get('username', '')}@{','.join(s.get('seeds', []))}"

    def start(self, seeds: list[str], username: str, password: str | None, remember: bool,
              platform_hint: str | None, get_lan_devices) -> str | None:
        seeds = [x.strip() for x in seeds if x.strip()]
        if not seeds or not username:
            return "Enter at least one switch or router address and a username."
        s = {"seeds": seeds, "username": username, "remember": bool(remember), "platform": platform_hint or None}
        acct = self._account(s)
        if not password:
            password = load_password(acct) if remember else None
            if not password:
                return "Enter the password."
        elif remember:
            save_password(acct, password)
        if not remember:
            delete_password(acct)
        self.store.data["settings"]["gear"] = s
        self.store.save()
        with self.lock:
            if self.status["running"]:
                return "Already mapping."
            self.status = {"running": True, "stage": "Connecting…", "error": None, "log": []}
        threading.Thread(target=self._run, args=(s, password, get_lan_devices), daemon=True).start()
        return None

    def _run(self, s: dict, password: str, get_lan_devices):
        try:
            from netatlas.analysis import analyze, subnets, summary_text
            from netatlas.collectors import SSHCollector
            from netatlas.crawler import CrawlScope, Target, assemble, discover
            from netatlas.layout import compute_layout
            host_map = json.loads(os.environ.get("LANLENS_GEAR_HOSTMAP", "{}"))   # tests only
            host_map = {k: tuple(v) for k, v in host_map.items()}
            col = SSHCollector(s["username"], password, timeout=15, host_map=host_map)

            def progress(msg):
                self.status["log"] = (self.status["log"] + [msg.strip()])[-40:]
                self.status["stage"] = msg.strip()
            seeds = [Target(host=x, platform=s.get("platform")) for x in s["seeds"]]
            devices, failures = discover(seeds, col, CrawlScope(resolve_dns=False, max_depth=8), workers=8, progress=progress)
            if not devices:
                why = next(iter(failures.values()), ("error", "no response"))
                raise RuntimeError(f"Couldn't log in to {', '.join(s['seeds'])}: {why[0].replace('_', ' ')} {why[1]}".strip())
            snap = assemble(devices, failures, s["seeds"], name="network gear")
            findings = analyze(snap)
            subs = subnets(snap)
            layout = compute_layout(snap, subs)
            lan = get_lan_devices()
            placed, stats = attach(snap, lan)
            self._snap = snap
            self.result = {
                "nodes": [{"id": h, "x": round(x, 1), "y": round(y, 1), "role": snap.devices[h].role or "unknown",
                           "managed": snap.devices[h].managed, "model": snap.devices[h].model,
                           "mgmt_ip": snap.devices[h].mgmt_ip, "status": snap.devices[h].status,
                           "vendor": snap.devices[h].vendor, "os": snap.devices[h].os_version}
                          for h, (x, y) in layout["nodes"].items()],
                "links": [{"a": l.a, "b": l.b, "a_if": l.a_if, "b_if": l.b_if, "one_sided": len(l.seen_from) < 2
                           and snap.devices[l.a].managed and snap.devices[l.b].managed}
                          for l in snap.links if l.a in layout["nodes"] and l.b in layout["nodes"]],
                "bbox": layout["bbox"], "placed": placed, "stats": stats,
                "summary": summary_text(snap, findings),
                "findings": [{"severity": f.severity, "title": f.title, "detail": f.detail} for f in findings][:30],
                "mapped_at": snap.created,
            }
            self.status.update(running=False, stage="")
        except Exception as exc:
            logging.error("gear mapping failed: %s", traceback.format_exc())
            self.status.update(running=False, stage="", error=str(exc))

    def view(self, lan_devices) -> dict | None:
        """Latest result, with devices re-placed after any newer LanLens scan."""
        if not self.result:
            return None
        snap = getattr(self, "_snap", None)
        if snap is not None and lan_devices:
            placed, stats = attach(snap, lan_devices)
            return dict(self.result, placed=placed, stats=stats)
        return self.result
