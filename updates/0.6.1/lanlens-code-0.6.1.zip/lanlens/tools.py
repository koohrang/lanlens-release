"""Network tools: ping, traceroute, DNS lookup and DNS speed check,
Wake-on-LAN and a thorough open-port check with plain-English notes.

Everything here is read-only except Wake-on-LAN, which sends the standard
"wake up" packet a sleeping computer listens for.
"""
from __future__ import annotations

import concurrent.futures as cf
import ipaddress
import os
import platform
import random
import re
import shutil
import socket
import statistics
import struct
import subprocess
import time

from .probes import open_ports, reverse_dns, _dns_name, _read_name

SYSTEM = platform.system()
HOST_RE = re.compile(r"^(?=.{1,253}$)[A-Za-z0-9_](?:[A-Za-z0-9_.-]*[A-Za-z0-9])?$")


def clean_host(h: str) -> str:
    """Accept an IP address or host name only (it is passed to system tools)."""
    h = (h or "").strip().rstrip(".")
    try:
        return str(ipaddress.ip_address(h))
    except ValueError:
        pass
    if not HOST_RE.match(h) or h.startswith("-"):
        raise ValueError("Enter an IP address or a host name, like 192.168.1.1 or apple.com.")
    return h


def _run(cmd: list[str], timeout: float) -> str:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.stdout + p.stderr
    except subprocess.TimeoutExpired as e:
        out = e.stdout or ""
        return out.decode() if isinstance(out, bytes) else out
    except OSError as e:
        raise RuntimeError(f"Couldn't run {cmd[0]}: {e}")


# ---------------------------------------------------------------------------
# Ping
# ---------------------------------------------------------------------------
def ping(host: str, count: int = 5) -> dict:
    host = clean_host(host)
    count = max(1, min(20, int(count)))
    if SYSTEM == "Windows":
        cmd = ["ping", "-n", str(count), "-w", "1000", host]
    elif SYSTEM == "Darwin":
        cmd = ["ping", "-c", str(count), "-t", str(count + 3), host]
    else:
        cmd = ["ping", "-c", str(count), "-W", "1", "-w", str(count + 3), host]
    out = _run(cmd, timeout=count + 8)
    times = [float(x) for x in re.findall(r"time[=<]([\d.]+)\s*ms", out, re.I)]
    ip = re.search(r"\((\d+\.\d+\.\d+\.\d+)\)|\[(\d+\.\d+\.\d+\.\d+)\]", out)
    if re.search(r"unknown host|cannot resolve|could not find host|name or service not known", out, re.I):
        raise RuntimeError(f"Couldn't find {host}: the name doesn't resolve.")
    ttl = re.search(r"ttl[=:](\d+)", out, re.I)
    return {"host": host, "ip": (ip.group(1) or ip.group(2)) if ip else None, "sent": count, "received": len(times),
            "loss_pct": round(100 * (count - len(times)) / count),
            "min_ms": round(min(times), 1) if times else None, "avg_ms": round(statistics.mean(times), 1) if times else None,
            "max_ms": round(max(times), 1) if times else None,
            "jitter_ms": round(statistics.mean(abs(a - b) for a, b in zip(times, times[1:])), 1) if len(times) > 1 else None,
            "ttl": int(ttl.group(1)) if ttl else None, "times": times}


# ---------------------------------------------------------------------------
# Traceroute
# ---------------------------------------------------------------------------
def parse_traceroute(out: str) -> list[dict]:
    hops = []
    for line in out.splitlines():
        m = re.match(r"^\s*(\d+)\s+(.*)$", line)
        if not m:
            continue
        n, rest = int(m.group(1)), m.group(2)
        ip = re.search(r"(\d+\.\d+\.\d+\.\d+)", rest)
        ms = [float(x) for x in re.findall(r"([\d.]+)\s*ms", rest)]
        hops.append({"hop": n, "ip": ip.group(1) if ip else None, "ms": round(min(ms), 1) if ms else None})
    return hops


def traceroute(host: str, max_hops: int = 20) -> dict:
    host = clean_host(host)
    if SYSTEM == "Windows":
        cmd = ["tracert", "-d", "-h", str(max_hops), "-w", "1000", host]
    else:
        exe = shutil.which("traceroute") or ("/usr/sbin/traceroute" if os.path.exists("/usr/sbin/traceroute") else None)
        if not exe:
            raise RuntimeError("traceroute isn't installed on this computer.")
        cmd = [exe, "-n", "-q", "1", "-w", "1", "-m", str(max_hops), host]
    out = _run(cmd, timeout=max_hops * 2 + 10)
    if re.search(r"unknown host|cannot resolve|Name or service not known", out, re.I):
        raise RuntimeError(f"Couldn't find {host}: the name doesn't resolve.")
    hops = parse_traceroute(out)
    ips = [h["ip"] for h in hops if h["ip"]]
    with cf.ThreadPoolExecutor(max_workers=12) as ex:
        names = dict(zip(ips, ex.map(reverse_dns, ips)))
    for h in hops:
        h["name"] = names.get(h["ip"]) if h["ip"] else None
        try:
            a = ipaddress.ip_address(h["ip"]) if h["ip"] else None
            h["kind"] = None if a is None else ("shared (CGNAT)" if a in ipaddress.ip_network("100.64.0.0/10")
                                                 else "private" if a.is_private else "internet")
        except ValueError:
            h["kind"] = None
    return {"host": host, "hops": hops}


# ---------------------------------------------------------------------------
# DNS
# ---------------------------------------------------------------------------
QTYPES = {"A": 1, "NS": 2, "CNAME": 5, "PTR": 12, "MX": 15, "TXT": 16, "AAAA": 28}
QNAMES = {v: k for k, v in QTYPES.items()}


def dns_servers() -> list[str]:
    servers = []
    if SYSTEM == "Darwin":
        out = _run(["scutil", "--dns"], timeout=5)
        servers = re.findall(r"nameserver\[\d+\]\s*:\s*(\S+)", out)
    else:
        try:
            with open("/etc/resolv.conf") as fh:
                servers = re.findall(r"^\s*nameserver\s+(\S+)", fh.read(), re.M)
        except OSError:
            pass
    seen, out = set(), []
    for s in servers:
        try:
            ipaddress.ip_address(s)
        except ValueError:
            continue
        if s not in seen:
            seen.add(s)
            out.append(s)
    return out


def dns_query(name: str, qtype: str = "A", server: str | None = None, timeout: float = 2.0) -> dict:
    """One raw DNS question over UDP. Returns answers and the time it took."""
    qt = QTYPES[qtype.upper()]
    server = server or (dns_servers() or ["1.1.1.1"])[0]
    if qtype.upper() == "PTR":
        try:
            name = ipaddress.ip_address(name).reverse_pointer
        except ValueError:
            pass
    tid = random.randint(0, 0xFFFF)
    pkt = struct.pack(">HHHHHH", tid, 0x0100, 1, 0, 0, 0) + _dns_name(name.rstrip(".")) + struct.pack(">HH", qt, 1)
    fam = socket.AF_INET6 if ":" in server else socket.AF_INET
    with socket.socket(fam, socket.SOCK_DGRAM) as s:
        s.settimeout(timeout)
        t = time.perf_counter()
        s.sendto(pkt, (server, 53))
        while True:
            data, _ = s.recvfrom(4096)
            if len(data) >= 12 and struct.unpack(">H", data[:2])[0] == tid:
                break
        ms = (time.perf_counter() - t) * 1000
    _, flags, qd, an, _, _ = struct.unpack(">HHHHHH", data[:12])
    rcode = flags & 0xF
    off = 12
    for _ in range(qd):
        _, off = _read_name(data, off)
        off += 4
    answers = []
    for _ in range(an):
        _, off = _read_name(data, off)
        rtype, _, ttl, rdlen = struct.unpack(">HHIH", data[off:off + 10])
        off += 10
        rd = data[off:off + rdlen]
        if rtype == 1 and rdlen == 4:
            val = socket.inet_ntoa(rd)
        elif rtype == 28 and rdlen == 16:
            val = socket.inet_ntop(socket.AF_INET6, rd)
        elif rtype in (2, 5, 12):
            val = _read_name(data, off)[0]
        elif rtype == 15:
            val = f"{struct.unpack('>H', rd[:2])[0]} {_read_name(data, off + 2)[0]}"
        elif rtype == 16:
            parts, i = [], 0
            while i < len(rd):
                ln = rd[i]
                parts.append(rd[i + 1:i + 1 + ln].decode("utf-8", "replace"))
                i += 1 + ln
            val = "".join(parts)
        else:
            val = rd.hex()
        answers.append({"type": QNAMES.get(rtype, str(rtype)), "value": val, "ttl": ttl})
        off += rdlen
    return {"name": name, "type": qtype.upper(), "server": server, "ms": round(ms, 1),
            "status": {0: "ok", 2: "server failure", 3: "no such name", 5: "refused"}.get(rcode, f"error {rcode}"),
            "answers": answers}


def dns_lookup(name: str, qtype: str = "A") -> dict:
    name = clean_host(name)
    qtype = (qtype or "A").upper()
    if qtype not in QTYPES:
        raise ValueError("Unsupported record type.")
    try:
        ipaddress.ip_address(name)
        qtype = "PTR"
    except ValueError:
        pass
    try:
        return dns_query(name, qtype)
    except socket.timeout:
        raise RuntimeError("Your DNS server didn't answer in time.")
    except OSError as e:
        raise RuntimeError(f"Couldn't reach your DNS server: {e}")


PUBLIC_DNS = [("Cloudflare", "1.1.1.1"), ("Google", "8.8.8.8"), ("Quad9", "9.9.9.9")]
BENCH_NAMES = ["apple.com", "google.com", "amazon.com", "netflix.com", "wikipedia.org", "microsoft.com"]


def dns_benchmark(rounds: int = 2) -> dict:
    """Compare how fast your current DNS answers against well-known public ones."""
    mine = dns_servers()
    cands = [("Yours" + (f" ({s})" if len(mine) > 1 else ""), s) for s in mine[:2]] + \
            [(n, s) for n, s in PUBLIC_DNS if s not in mine]

    def bench(item):
        label, server = item
        times, fails = [], 0
        for r in range(rounds):
            for n in BENCH_NAMES:
                q = n if r == 0 else f"www.{n}"          # a second name per site on the next round
                try:
                    times.append(dns_query(q, "A", server, timeout=1.5)["ms"])
                except Exception:
                    fails += 1
        return {"label": label, "server": server, "mine": server in mine,
                "median_ms": round(statistics.median(times), 1) if times else None,
                "failures": fails, "answered": len(times)}
    with cf.ThreadPoolExecutor(max_workers=len(cands) or 1) as ex:
        res = list(ex.map(bench, cands))
    ok = [r for r in res if r["median_ms"] is not None]
    best = min(ok, key=lambda r: r["median_ms"]) if ok else None
    cur = next((r for r in res if r["mine"] and r["median_ms"] is not None), None)
    advice = None
    if best and cur and not best["mine"] and cur["median_ms"] - best["median_ms"] >= 10:
        advice = (f"{best['label']} ({best['server']}) answered about {round(cur['median_ms'] - best['median_ms'])} ms "
                  f"faster than your current DNS. You can set it in your router's DNS settings (for every device) or "
                  f"in System Settings → Network → Details → DNS (this Mac only).")
    elif cur:
        advice = "Your current DNS is about as fast as the public alternatives. No change needed."
    return {"results": res, "advice": advice, "servers": mine}


# ---------------------------------------------------------------------------
# Wake-on-LAN
# ---------------------------------------------------------------------------
def wake(mac: str, broadcasts: list[str] | None = None) -> dict:
    hexs = re.sub(r"[^0-9a-fA-F]", "", mac or "")
    if len(hexs) != 12:
        raise ValueError("That isn't a valid MAC address.")
    pkt = b"\xff" * 6 + bytes.fromhex(hexs) * 16
    targets = list(dict.fromkeys((broadcasts or []) + ["255.255.255.255"]))
    sent = 0
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        for b in targets:
            for port in (9, 7):
                try:
                    s.sendto(pkt, (b, port))
                    sent += 1
                except OSError:
                    pass
    if not sent:
        raise RuntimeError("Couldn't send the wake-up packet on this network.")
    return {"mac": ":".join(hexs[i:i + 2] for i in range(0, 12, 2)).lower(), "sent_to": targets}


# ---------------------------------------------------------------------------
# Thorough port check
# ---------------------------------------------------------------------------
# port -> (service, risk level or None, plain-English note)
SERVICES: dict[int, tuple[str, str | None, str]] = {
    20: ("FTP data", "medium", "Old file-transfer protocol; passwords travel unencrypted."),
    21: ("FTP", "medium", "File sharing with unencrypted passwords. Turn it off unless you need it."),
    22: ("SSH", None, "Encrypted remote login. Fine if you use it and the password is strong."),
    23: ("Telnet", "high", "Unencrypted remote login, a favorite target of botnets. Turn it off."),
    25: ("SMTP mail", "low", "Mail server. Unusual on a home device."),
    53: ("DNS", None, "Answers name lookups (normal for routers)."),
    67: ("DHCP", None, "Hands out addresses (normal for routers)."),
    69: ("TFTP", "medium", "Unauthenticated file transfer, sometimes used for firmware."),
    80: ("Web (HTTP)", "low", "Web page without encryption. Logins on this page can be read by others on the network."),
    81: ("Web (alt)", "low", "Extra web page, often a camera."),
    88: ("Kerberos", None, "Network login service."),
    110: ("POP3 mail", "low", "Mail pickup without encryption."),
    111: ("RPC", "low", "Unix remote-procedure service."),
    123: ("Time (NTP)", None, "Clock sync."),
    135: ("Windows RPC", "low", "Windows service; keep it off untrusted networks."),
    137: ("NetBIOS", None, "Windows name service."),
    139: ("Windows file sharing (old)", "medium", "Old SMB file sharing."),
    143: ("IMAP mail", "low", "Mail access without encryption."),
    161: ("SNMP", "low", "Device monitoring; often uses the default 'public' password."),
    389: ("LDAP", "low", "Directory service."),
    443: ("Web (HTTPS)", None, "Encrypted web page."),
    445: ("Windows file sharing (SMB)", "medium", "Shared folders. Fine on a PC or NAS you use; risky on other devices."),
    515: ("Printer (LPD)", None, "Printing."),
    548: ("Apple file sharing (AFP)", None, "Old Mac file sharing."),
    554: ("Camera video (RTSP)", "medium", "Live video stream. Make sure it requires a password."),
    587: ("Mail submission", None, "Sending mail."),
    623: ("IPMI", "high", "Server out-of-band management; known for weak security."),
    631: ("Printing (IPP)", None, "Printing."),
    873: ("rsync", "medium", "File sync; can expose files without a password."),
    902: ("VMware", None, "VMware remote console."),
    993: ("IMAP (TLS)", None, "Encrypted mail access."),
    995: ("POP3 (TLS)", None, "Encrypted mail pickup."),
    1080: ("SOCKS proxy", "medium", "Proxy server; check it isn't open to everyone."),
    1194: ("OpenVPN", None, "VPN server."),
    1400: ("Sonos", None, "Sonos speaker control."),
    1433: ("SQL Server", "medium", "Database server."),
    1723: ("PPTP VPN", "medium", "Outdated VPN with broken encryption."),
    1883: ("MQTT", "medium", "Smart-home messaging, often without a password."),
    1900: ("UPnP", None, "Device discovery."),
    2049: ("NFS", "medium", "Network file sharing; often no password."),
    2375: ("Docker API", "high", "Unprotected Docker control; anyone on the network can take over this machine."),
    2376: ("Docker API (TLS)", "low", "Docker control with encryption."),
    3000: ("Web app", None, "Development or dashboard web app."),
    3306: ("MySQL", "medium", "Database server."),
    3389: ("Remote Desktop", "medium", "Windows Remote Desktop. Keep it off the internet."),
    3478: ("STUN", None, "Video-call/NAT helper."),
    4444: ("Unknown (often malware)", "medium", "Port commonly used by remote-control tools."),
    5000: ("UPnP/AirPlay/NAS", None, "Often AirPlay, a NAS page or a dev server."),
    5001: ("NAS (HTTPS)", None, "Often a Synology page."),
    5060: ("SIP (VoIP)", "low", "Internet phone signaling."),
    5353: ("mDNS", None, "Bonjour."),
    5432: ("PostgreSQL", "medium", "Database server."),
    5555: ("Android debug (ADB)", "high", "Lets anyone on the network control this Android device or TV. Turn off 'ADB debugging'."),
    5800: ("VNC (web)", "medium", "Screen sharing."),
    5900: ("Screen sharing (VNC)", "medium", "Remote screen control. Make sure it has a strong password."),
    6379: ("Redis", "high", "Database that usually has no password."),
    6466: ("Android TV remote", None, "TV remote control."),
    6668: ("Tuya", None, "Tuya smart-device control."),
    7000: ("AirPlay", None, "AirPlay receiver."),
    7547: ("TR-069 (ISP management)", "low", "Your provider's remote-management port."),
    8000: ("Web (alt)", "low", "Extra web page."),
    8008: ("Google Cast", None, "Chromecast/Google speaker."),
    8009: ("Google Cast", None, "Chromecast/Google speaker."),
    8060: ("Roku", None, "Roku control."),
    8080: ("Web (alt)", "low", "Extra web page without encryption."),
    8081: ("Web (alt)", "low", "Extra web page."),
    8123: ("Home Assistant", None, "Home Assistant."),
    8443: ("Web (HTTPS alt)", None, "Encrypted web page."),
    8883: ("MQTT (TLS)", None, "Encrypted smart-home messaging."),
    8888: ("Web (alt)", "low", "Extra web page, often a dev tool."),
    9000: ("Web (alt)", "low", "Extra web page."),
    9100: ("Printer (raw)", None, "Printing."),
    9200: ("Elasticsearch", "high", "Search database that is often open without a password."),
    9999: ("Kasa", None, "TP-Link Kasa control."),
    10000: ("Webmin", "medium", "Server admin panel."),
    11211: ("Memcached", "high", "Cache server with no password."),
    27017: ("MongoDB", "high", "Database that is often open without a password."),
    32400: ("Plex", None, "Plex media server."),
    49152: ("UPnP", None, "Device control (common on routers and TVs)."),
    62078: ("Apple device sync", None, "iPhone/iPad sync."),
}
TOP_PORTS = sorted(set(SERVICES) | set(range(1, 1025)) | {
    1025, 1026, 1027, 1028, 1029, 1110, 1234, 1521, 1720, 1755, 1900, 2000, 2001, 2082, 2083, 2086, 2087, 2121, 2222,
    2717, 3001, 3128, 3268, 3283, 3689, 3690, 3784, 4000, 4040, 4321, 4443, 4567, 4899, 5009, 5050, 5190, 5222, 5357,
    5431, 5601, 5631, 5666, 5985, 5986, 6000, 6001, 6443, 6646, 6667, 7001, 7070, 7100, 7443, 7681, 7777, 8001, 8002,
    8010, 8020, 8042, 8069, 8082, 8083, 8086, 8088, 8089, 8090, 8091, 8096, 8180, 8181, 8200, 8291, 8333, 8400, 8500,
    8554, 8649, 8800, 8873, 8899, 8920, 9001, 9002, 9080, 9090, 9091, 9093, 9295, 9443, 9500, 9876, 10001, 10243,
    10443, 12345, 20000, 32469, 37777, 49153, 49154, 49155, 50000, 51413, 55443, 554, 8554})


def is_lan(host: str) -> bool:
    try:
        a = ipaddress.ip_address(host)
    except ValueError:
        return False
    return a.is_private or a.is_link_local


def port_check(host: str, thorough: bool = True, timeout: float = 1.2) -> dict:
    """TCP-connect check (opens and immediately closes a connection on each port)."""
    host = clean_host(host)
    try:
        ip = str(ipaddress.ip_address(host))
    except ValueError:
        try:
            ip = socket.gethostbyname(host)
        except OSError:
            raise RuntimeError(f"Couldn't find {host}.")
    if not is_lan(ip):
        raise ValueError("Port checks are limited to devices on your own network.")
    ports = TOP_PORTS if thorough else sorted(SERVICES)
    found: list[int] = []
    chunk = 200
    for i in range(0, len(ports), chunk):
        found += open_ports(ip, ports[i:i + chunk], timeout=timeout)
    return {"host": host, "ip": ip, "checked": len(ports), "open": [describe_port(p) for p in sorted(set(found))]}


def describe_port(p: int) -> dict:
    name, risk, note = SERVICES.get(p, (None, None, ""))
    if name is None:
        from . import datasets
        iana = datasets.port_meaning(p)
        try:
            name = iana or socket.getservbyport(p, "tcp")
        except OSError:
            name = "Unknown service"
        note = note or "Not a common service; check what's running if you don't recognize it."
    return {"port": p, "service": name, "risk": risk, "note": note}
