"""Entry point used by the Mac app (double-click). See server.py."""
import sys

from .server import main

if __name__ == "__main__":
    sys.exit(main())
