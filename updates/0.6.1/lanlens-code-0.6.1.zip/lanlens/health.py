"""Network health: internet/router reachability every minute (outage log),
Wi-Fi quality over time, and on-demand speed tests.

Speed tests use Cloudflare's public speed-test endpoints (the same ones
speed.cloudflare.com uses). Nothing else leaves your network.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
import platform
import re
import socket
import statistics
import subprocess
import threading
import time
from pathlib import Path

from .identify import ping
from .probes import _open

HEALTH = Path.home() / ".lanlens" / "health.json"
SPEED_BASE = os.environ.get("LANLENS_SPEED_URL", "https://speed.cloudflare.com")
INTERNET_TARGETS = [("1.1.1.1", 443), ("8.8.8.8", 443), ("9.9.9.9", 443)]
if os.environ.get("LANLENS_INET_TARGETS"):                       # tests only
    INTERNET_TARGETS = [(h, int(p)) for h, p in (x.split(":") for x in os.environ["LANLENS_INET_TARGETS"].split(","))]
KEEP_DAYS = 14


def now_iso() -> str:
    return _dt.datetime.now().isoformat(timespec="seconds")


# ---------------------------------------------------------------------------
# Probes
# ---------------------------------------------------------------------------
def tcp_ms(host: str, port: int, timeout: float = 3.0) -> float | None:
    t = time.perf_counter()
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return round((time.perf_counter() - t) * 1000, 1)
    except OSError:
        return None


def internet_check(targets=None) -> dict:
    targets = targets or INTERNET_TARGETS
    times = [tcp_ms(h, p) for h, p in targets[:2]]
    ok = [t for t in times if t is not None]
    if not ok:                                   # try a third before calling it down
        t3 = tcp_ms(*targets[2]) if len(targets) > 2 else None
        ok = [t3] if t3 is not None else []
    dns_ok = True
    if not os.environ.get("LANLENS_INET_TARGETS"):
        try:
            socket.getaddrinfo("www.apple.com", 443)
        except OSError:
            dns_ok = False
    return {"up": bool(ok), "ms": min(ok) if ok else None, "dns": dns_ok}


def wifi_info(sh=None) -> dict | None:
    """Current Wi-Fi link on macOS via system_profiler (no admin needed)."""
    if platform.system() != "Darwin" and sh is None:
        return None
    run = sh or (lambda: subprocess.run(["system_profiler", "SPAirPortDataType", "-json"],
                                        capture_output=True, text=True, timeout=30).stdout)
    try:
        j = json.loads(run())
        ifaces = j["SPAirPortDataType"][0].get("spairport_airport_interfaces", [])
    except Exception:
        return None
    for i in ifaces:
        cur = i.get("spairport_current_network_information")
        if not cur:
            continue
        sn = cur.get("spairport_signal_noise", "")
        m = re.search(r"(-?\d+)\s*dBm\s*/\s*(-?\d+)\s*dBm", sn)
        ch = cur.get("spairport_network_channel", "")
        band = re.search(r"(2GHz|5GHz|6GHz)", str(ch))
        return {"ssid": cur.get("_name") if cur.get("_name") not in (None, "<redacted>") else None,
                "rssi": int(m.group(1)) if m else None, "noise": int(m.group(2)) if m else None,
                "rate": cur.get("spairport_network_rate"), "phy": cur.get("spairport_network_phymode"),
                "channel": str(ch) or None, "band": band.group(1).replace("GHz", " GHz") if band else None,
                "security": cur.get("spairport_security_mode", "").replace("spairport_security_mode_", "").replace("_", " ") or None}
    return {"wired": True}


def signal_quality(rssi: int | None) -> str | None:
    if rssi is None:
        return None
    return "excellent" if rssi >= -55 else "good" if rssi >= -65 else "fair" if rssi >= -72 else "poor"


# ---------------------------------------------------------------------------
# Speed test
# ---------------------------------------------------------------------------
def speed_test(progress=lambda m: None, base: str | None = None, budget_s: float = 8.0) -> dict:
    base = (base or SPEED_BASE).rstrip("/")
    progress("Measuring latency…")
    lat, fails = [], 0
    for _ in range(8):
        t = time.perf_counter()
        try:
            with _open(f"{base}/__down?bytes=0", timeout=5) as r:
                r.read()
            lat.append((time.perf_counter() - t) * 1000)
        except Exception:
            fails += 1
            if fails >= 2 and not lat:
                break
    if not lat:
        raise RuntimeError("Couldn't reach the speed-test server. Check your internet connection.")
    latency = round(statistics.median(lat), 1)
    jitter = round(statistics.mean(abs(a - b) for a, b in zip(lat, lat[1:])), 1) if len(lat) > 1 else 0.0

    def down(nbytes):
        t = time.perf_counter()
        got = 0
        with _open(f"{base}/__down?bytes={nbytes}", timeout=30) as r:
            while True:
                chunk = r.read(256 * 1024)
                if not chunk:
                    break
                got += len(chunk)
        return got, time.perf_counter() - t

    def up(nbytes):
        import urllib.request
        data = os.urandom(min(nbytes, 1 << 20)) * max(1, nbytes // (1 << 20))
        req = urllib.request.Request(f"{base}/__up", data=data[:nbytes], method="POST",
                                     headers={"Content-Type": "application/octet-stream"})
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        t = time.perf_counter()
        with opener.open(req, timeout=60) as r:
            r.read()
        return nbytes, time.perf_counter() - t

    def measure(fn, label):
        progress(f"Testing {label} speed…")
        results, size, spent, last = [], 1_000_000, 0.0, None
        while spent < budget_s and size <= 100_000_000:
            try:
                n, secs = fn(size)
            except Exception:
                break
            spent += secs
            last = n * 8 / max(secs, 1e-6) / 1e6
            if secs > 0.25:
                results.append(last)
            size = size * 4 if secs < 1.5 else size * 2 if secs < budget_s / 3 else size
            if secs > budget_s / 2:
                break
        if not results and last:
            results = [last]                     # very fast link: even the largest transfer finished quickly
        return round(max(results), 1) if results else None

    dl = measure(down, "download")
    ul = measure(up, "upload")
    return {"time": now_iso(), "down_mbps": dl, "up_mbps": ul, "latency_ms": latency, "jitter_ms": jitter,
            "server": base.split("//")[-1]}


# ---------------------------------------------------------------------------
# Monitor + history
# ---------------------------------------------------------------------------
class Health:
    def __init__(self, path: Path = HEALTH):
        self.path = path
        try:
            self.data = json.loads(path.read_text())
        except (OSError, ValueError):
            self.data = {}
        for k in ("samples", "outages", "speedtests", "wifi", "ip_changes"):
            self.data.setdefault(k, [])
        self.lock = threading.RLock()
        self.speed = {"running": False, "stage": "", "error": None}
        self.gateway = None
        self._down_since = None
        self._down_kind = None

    def save(self):
        with self.lock:
            cutoff = (_dt.datetime.now() - _dt.timedelta(days=KEEP_DAYS)).isoformat()
            for k in ("samples", "wifi"):
                self.data[k] = [s for s in self.data[k] if s["t"] >= cutoff]
            self.data["outages"] = self.data["outages"][-300:]
            self.data["speedtests"] = self.data["speedtests"][-200:]
            self.data["ip_changes"] = self.data["ip_changes"][-100:]
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                tmp = self.path.with_suffix(".tmp")
                tmp.write_text(json.dumps(self.data))
                tmp.replace(self.path)
            except OSError:
                pass

    def record(self, gw_ms: float | None, inet: dict, t: str | None = None) -> None:
        """Add one reachability sample and open/close outage records."""
        t = t or now_iso()
        with self.lock:
            self.data["samples"].append({"t": t, "gw": gw_ms, "inet": inet.get("ms"), "up": inet.get("up"),
                                         "dns": inet.get("dns")})
            if inet.get("up") and inet.get("dns", True):
                if self._down_since:
                    self.data["outages"].append({"start": self._down_since, "end": t, "kind": self._down_kind})
                    self._down_since = self._down_kind = None
            else:
                kind = ("Router unreachable (local network)" if gw_ms is None and self.gateway
                        else "Internet down" if not inet.get("up") else "DNS not answering")
                if not self._down_since:
                    self._down_since, self._down_kind = t, kind

    def record_wifi(self, info: dict | None, t: str | None = None):
        if info and not info.get("wired"):
            with self.lock:
                self.data["wifi"].append({"t": t or now_iso(), "rssi": info.get("rssi"), "noise": info.get("noise"),
                                          "rate": info.get("rate"), "channel": info.get("channel")})

    def tick(self):
        gw = None
        if self.gateway:
            rtt, _ = ping(self.gateway)
            gw = rtt
        self.record(gw, internet_check())

    def monitor(self, stop: threading.Event, every: int = 60, wifi_every: int = 300):
        every = int(os.environ.get("LANLENS_HEALTH_EVERY", every))
        last_wifi = 0.0
        while not stop.is_set():
            try:
                self.tick()
                if time.time() - last_wifi > wifi_every:
                    last_wifi = time.time()
                    self.last_wifi = wifi_info()
                    self.record_wifi(self.last_wifi)
                self.save()
            except Exception:
                pass
            stop.wait(every)

    def record_public_ip(self, ip: str | None, isp: str | None = None, t: str | None = None) -> bool:
        """Log the public address when it changes. Returns True if it changed."""
        if not ip:
            return False
        with self.lock:
            log = self.data["ip_changes"]
            if log and log[-1]["ip"] == ip:
                return False
            log.append({"t": t or now_iso(), "ip": ip, "isp": isp})
            return len(log) > 1

    def run_speed_test(self):
        with self.lock:
            if self.speed["running"]:
                return False
            self.speed = {"running": True, "stage": "Starting…", "error": None}

        def work():
            try:
                res = speed_test(progress=lambda m: self.speed.update(stage=m))
                with self.lock:
                    self.data["speedtests"].append(res)
                self.save()
                self.speed = {"running": False, "stage": "", "error": None}
            except Exception as exc:
                self.speed = {"running": False, "stage": "", "error": str(exc)}
        threading.Thread(target=work, daemon=True).start()
        return True

    def summary(self, hours: int = 24) -> dict:
        with self.lock:
            cutoff = (_dt.datetime.now() - _dt.timedelta(hours=hours)).isoformat()
            s = [x for x in self.data["samples"] if x["t"] >= cutoff]
            up = [x for x in s if x["up"] and x.get("dns", True)]
            outs = [o for o in self.data["outages"] if o["end"] >= cutoff]
            if self._down_since:
                outs = outs + [{"start": self._down_since, "end": None, "kind": self._down_kind}]
            inet = [x["inet"] for x in s if x["inet"] is not None]
            gw = [x["gw"] for x in s if x["gw"] is not None]
            last = s[-1] if s else None
            wifi = [w for w in self.data["wifi"] if w["t"] >= cutoff]
            return {
                "hours": hours, "samples": len(s),
                "uptime_pct": round(100 * len(up) / len(s), 2) if s else None,
                "now": last, "outages": outs[-50:],
                "inet_median": round(statistics.median(inet), 1) if inet else None,
                "gw_median": round(statistics.median(gw), 1) if gw else None,
                "series": [{"t": x["t"], "gw": x["gw"], "inet": x["inet"], "up": x["up"]} for x in s][-1500:],
                "wifi": wifi[-600:], "wifi_now": getattr(self, "last_wifi", None),
                "speedtests": self.data["speedtests"][-30:], "speed": self.speed,
                "ip_changes": self.data["ip_changes"][-20:],
                "monitoring_since": self.data["samples"][0]["t"] if self.data["samples"] else None,
            }
