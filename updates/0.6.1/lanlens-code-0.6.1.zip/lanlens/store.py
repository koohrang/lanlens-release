"""Everything LanLens remembers, kept in ~/.lanlens/store.json on this computer:
device history (first/last seen, online history) and your own labels."""
from __future__ import annotations

import datetime as _dt
import json
import threading
from dataclasses import asdict
from pathlib import Path

from .classify import CATEGORY_LABEL, Device

STORE = Path.home() / ".lanlens" / "store.json"
OLD_HISTORY = Path.home() / ".lanlens" / "history.json"
_lock = threading.RLock()
SEEN_KEEP = 3000          # per-device scan timestamps (about 10 days at one scan every 5 minutes)
SCANS_KEEP = 3000
GAP = _dt.timedelta(hours=2)   # longer than this between scans = LanLens wasn't running


def now() -> str:
    return _dt.datetime.now().isoformat(timespec="seconds")


def device_key(d: Device) -> str:
    return d.mac or f"ip:{d.ip}"


class Store:
    def __init__(self, path: Path = STORE):
        self.path = path
        try:
            self.data = json.loads(path.read_text())
        except (OSError, ValueError):
            self.data = {}
        self.data.setdefault("networks", {})
        self.data.setdefault("labels", {})
        self.data.setdefault("settings", {"watch_minutes": 10})

    def save(self) -> None:
        with _lock:
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                tmp = self.path.with_suffix(".tmp")
                tmp.write_text(json.dumps(self.data, separators=(",", ":")))
                tmp.replace(self.path)
            except OSError:
                pass

    # ------------------------------------------------------------------
    def labels(self) -> dict:
        return self.data["labels"]

    def set_label(self, key: str, **fields) -> dict:
        with _lock:
            lab = self.data["labels"].setdefault(key, {})
            for k, v in fields.items():
                if k not in ("name", "notes", "trusted", "category", "type", "owner", "alert"):
                    continue
                if v in (None, "", False) and k not in ("trusted",):
                    lab.pop(k, None)
                else:
                    lab[k] = v
            if not lab:
                self.data["labels"].pop(key, None)
            self.save()
            return lab

    # ------------------------------------------------------------------
    def merge_scan(self, network_key: str, devices: list[Device]) -> tuple[list[Device], bool]:
        """Record a scan. Returns (online + offline devices, seen_before)."""
        with _lock:
            net = self.data["networks"].setdefault(network_key, {"devices": {}, "scans": []})
            known = net["devices"]
            first_scan = not net["scans"]
            ts = now()
            online_keys = set()
            for d in devices:
                k = device_key(d)
                d.key = k
                online_keys.add(k)
                rec = known.get(k)
                if rec is None:
                    d.new = not first_scan and not d.is_self
                    rec = known[k] = {"first_seen": ts, "seen": []}
                d.first_seen = rec["first_seen"]
                rec["last_seen"] = ts
                rec["seen"] = (rec.get("seen", []) + [ts])[-SEEN_KEEP:]
                d.last_seen = ts
                d.seen_count = len(rec["seen"])
                d.online = True
                rec["snapshot"] = {k2: v for k2, v in asdict(d).items()
                                   if k2 not in ("new", "online", "notes", "custom_name", "trusted", "owner", "alert")}
            net["scans"] = (net["scans"] + [{"time": ts, "online": len(devices)}])[-SCANS_KEEP:]
            out = list(devices)
            for k, rec in known.items():
                if k in online_keys or "snapshot" not in rec:
                    continue
                snap = dict(rec["snapshot"])
                snap = {f: snap[f] for f in Device.__dataclass_fields__ if f in snap}
                d = Device(**snap)
                d.key, d.online, d.new = k, False, False
                d.first_seen, d.last_seen, d.seen_count = rec.get("first_seen"), rec.get("last_seen"), len(rec.get("seen", []))
                d.notes = []
                out.append(d)
            self.save()
            return out, not first_scan

    def forget(self, network_key: str, key: str) -> None:
        with _lock:
            self.data["networks"].get(network_key, {}).get("devices", {}).pop(key, None)
            self.data["labels"].pop(key, None)
            self.save()

    def scans(self, network_key: str) -> list[dict]:
        return self.data["networks"].get(network_key, {}).get("scans", [])

    # ------------------------------------------------------------------
    # Presence history
    # ------------------------------------------------------------------
    def timeline(self, network_key: str, key: str, hours: int = 24) -> dict:
        """Online/offline stretches for one device, built from the scan history.
        [{"start", "end", "state": "online"|"offline"|"unknown"}]"""
        with _lock:
            net = self.data["networks"].get(network_key, {})
            rec = net.get("devices", {}).get(key, {})
            seen = set(rec.get("seen", []))
            first = rec.get("first_seen") or ""
            times = [s["time"] for s in net.get("scans", []) if s["time"] >= first]   # before it ever joined = unknown
        return {"segments": segments(times, seen, hours), "first_seen": rec.get("first_seen"),
                "last_seen": rec.get("last_seen")}

    def activity(self, network_key: str, hours: int = 48, names: dict | None = None) -> list[dict]:
        """Arrivals, departures and first appearances across all devices, newest first."""
        names = names or {}
        with _lock:
            net = self.data["networks"].get(network_key, {})
            times = [s["time"] for s in net.get("scans", [])]
            devs = {k: (set(r.get("seen", [])), r.get("first_seen")) for k, r in net.get("devices", {}).items()}
        cutoff = (_dt.datetime.now() - _dt.timedelta(hours=hours)).isoformat()
        out = []
        for k, (seen, first) in devs.items():
            prev = None
            for i, t in enumerate(times):
                on = t in seen
                if prev is not None and on != prev[1] and t >= cutoff:
                    gap = _dt.datetime.fromisoformat(t) - _dt.datetime.fromisoformat(prev[0])
                    if gap <= GAP:
                        out.append({"t": t, "key": k, "event": "online" if on else "offline", "name": names.get(k)})
                prev = (t, on)
            if first and first >= cutoff and times and first != times[0]:
                out.append({"t": first, "key": k, "event": "new", "name": names.get(k)})
        # "online" right after "new" at the same time is redundant
        news = {(e["key"], e["t"]) for e in out if e["event"] == "new"}
        out = [e for e in out if not (e["event"] == "online" and (e["key"], e["t"]) in news)]
        return sorted(out, key=lambda e: e["t"], reverse=True)[:300]

    def strips(self, network_key: str, hours: int = 24, buckets: int = 24) -> dict:
        """Per device, one state per time bucket: 1 online, 0 offline, None not watched."""
        now = _dt.datetime.now()
        start = now - _dt.timedelta(hours=hours)
        size = hours * 3600 / buckets
        with _lock:
            net = self.data["networks"].get(network_key, {})
            scans = [s["time"] for s in net.get("scans", []) if s["time"] >= start.isoformat()]
            devs = {k: set(r.get("seen", [])) for k, r in net.get("devices", {}).items()}
        idx = [min(buckets - 1, int((_dt.datetime.fromisoformat(t) - start).total_seconds() // size)) for t in scans]
        out = {}
        for k, seen in devs.items():
            row = [None] * buckets
            for t, i in zip(scans, idx):
                if t in seen:
                    row[i] = 1
                elif row[i] is None:
                    row[i] = 0
            out[k] = row
        return out

    def presence(self) -> dict:
        return self.data.setdefault("presence", {})


def segments(times: list[str], seen: set, hours: int = 24, now: _dt.datetime | None = None) -> list[dict]:
    now = now or _dt.datetime.now()
    start = now - _dt.timedelta(hours=hours)
    pts = [(_dt.datetime.fromisoformat(t), t in seen) for t in times]
    pts = [p for p in pts if p[0] >= start - GAP]
    out: list[dict] = []

    def add(a, b, state):
        a = max(a, start)
        if b <= a:
            return
        if out and out[-1]["state"] == state and out[-1]["end"] == a.isoformat(timespec="seconds"):
            out[-1]["end"] = b.isoformat(timespec="seconds")
        else:
            out.append({"start": a.isoformat(timespec="seconds"), "end": b.isoformat(timespec="seconds"), "state": state})
    if not pts:
        return [{"start": start.isoformat(timespec="seconds"), "end": now.isoformat(timespec="seconds"), "state": "unknown"}]
    if pts[0][0] > start:
        add(start, pts[0][0], "unknown")
    for (t, on), nxt in zip(pts, pts[1:] + [(now, None)]):
        end = nxt[0]
        if end - t > GAP:                      # LanLens wasn't watching for a while
            add(t, t + _dt.timedelta(minutes=10), "online" if on else "offline")
            add(t + _dt.timedelta(minutes=10), end, "unknown")
        else:
            add(t, end, "online" if on else "offline")
    return out


def update_presence(state: dict, devices: list[Device], labels: dict, ts: str | None = None,
                    away_after_misses: int = 3, away_after_min: int = 15) -> list[tuple[Device, str]]:
    """Track arrivals/departures for devices that have an owner or alert set.
    Returns [(device, "arrived"|"left")] for changes worth announcing. A phone
    only counts as gone after it's been missing for a few scans, because phones
    nap on Wi-Fi."""
    ts = ts or now()
    t_now = _dt.datetime.fromisoformat(ts)
    changes = []
    for d in devices:
        lab = labels.get(d.key or "") or {}
        if not (lab.get("owner") or lab.get("alert")):
            state.pop(d.key, None)
            continue
        st = state.get(d.key)
        if st is None:
            state[d.key] = {"home": d.online, "since": ts, "missed": 0}
            continue
        if d.online:
            st["missed"] = 0
            if not st["home"]:
                st.update(home=True, since=ts)
                changes.append((d, "arrived"))
        else:
            st["missed"] = st.get("missed", 0) + 1
            last = _dt.datetime.fromisoformat(d.last_seen) if d.last_seen else None
            if st["home"] and st["missed"] >= away_after_misses and (not last or t_now - last >= _dt.timedelta(minutes=away_after_min)):
                st.update(home=False, since=d.last_seen or ts)
                changes.append((d, "left"))
    return changes


def apply_labels(devices: list[Device], labels: dict) -> None:
    for d in devices:
        lab = labels.get(d.key or "")
        if not lab:
            continue
        if lab.get("name"):
            d.auto_name = d.name
            d.name = lab["name"]
        d.user_notes = lab.get("notes", "")
        d.owner = lab.get("owner", "")
        d.alert = bool(lab.get("alert"))
        d.trusted = bool(lab.get("trusted"))
        if lab.get("category") in CATEGORY_LABEL:
            d.category = lab["category"]
            d.type = lab.get("type") or d.type
            d.confidence = "set by you"
