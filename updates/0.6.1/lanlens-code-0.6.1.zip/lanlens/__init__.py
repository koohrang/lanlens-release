"""lanlens - see every device on your network, sorted by type."""
__version__ = "0.6.1"
