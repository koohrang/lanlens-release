"""Mac app plumbing: start at login, Anthropic key in Keychain, self-update.

Self-update: see the "Self-update" section below. Every update must be signed
with the LanLens release key; most updates replace only the code.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import platform
import plistlib
import re
import shutil
import subprocess
import tempfile
import urllib.request
import zipfile
from pathlib import Path

IS_MAC = platform.system() == "Darwin"
LABEL = "app.lanlens.scanner"
AGENT = Path.home() / "Library" / "LaunchAgents" / f"{LABEL}.plist"
KEY_SERVICE = "LanLens Anthropic API key"


def app_path() -> Path | None:
    p = os.environ.get("LANLENS_APP_PATH")
    return Path(p).resolve() if p else None


def in_applications(p: Path | None) -> bool:
    return bool(p) and "AppTranslocation" not in str(p) and (str(p).startswith("/Applications/")
                                                              or str(p).startswith(str(Path.home() / "Applications")))


# ---------------------------------------------------------------------------
# Start at login (a per-user LaunchAgent; no admin rights)
# ---------------------------------------------------------------------------
def login_item_plist(app: Path) -> bytes:
    return plistlib.dumps({
        "Label": LABEL,
        "ProgramArguments": [str(app / "Contents" / "MacOS" / "LanLens"), "--background"],
        "RunAtLoad": True,
        "KeepAlive": False,
        "ProcessType": "Interactive",
        "LimitLoadToSessionType": "Aqua",
    })


def login_item_enabled() -> bool:
    return AGENT.exists()


def set_login_item(on: bool) -> str | None:
    """Returns an error message, or None on success."""
    if on:
        app = app_path()
        if not in_applications(app):
            return "Move LanLens into your Applications folder first, then turn this on."
        AGENT.parent.mkdir(parents=True, exist_ok=True)
        AGENT.write_bytes(login_item_plist(app))
        return None
    if AGENT.exists():
        if IS_MAC:
            subprocess.run(["launchctl", "bootout", f"gui/{os.getuid()}/{LABEL}"], capture_output=True, timeout=10)
        AGENT.unlink()
    return None


# ---------------------------------------------------------------------------
# Anthropic API key (Keychain on macOS; memory elsewhere)
# ---------------------------------------------------------------------------
_mem_key = {"k": None}


def get_api_key() -> str | None:
    if os.environ.get("LANLENS_ANTHROPIC_KEY"):
        return os.environ["LANLENS_ANTHROPIC_KEY"]
    if IS_MAC:
        r = subprocess.run(["security", "find-generic-password", "-a", os.environ.get("USER", "user"), "-s", KEY_SERVICE, "-w"],
                           capture_output=True, text=True, timeout=10)
        return (r.stdout.strip() or None) if r.returncode == 0 else None
    return _mem_key["k"]


def set_api_key(key: str | None) -> None:
    acct = os.environ.get("USER", "user")
    if IS_MAC:
        if key:
            subprocess.run(["security", "add-generic-password", "-a", acct, "-s", KEY_SERVICE, "-w", key, "-U"],
                           capture_output=True, timeout=10)
        else:
            subprocess.run(["security", "delete-generic-password", "-a", acct, "-s", KEY_SERVICE], capture_output=True, timeout=10)
    _mem_key["k"] = key or None


# ---------------------------------------------------------------------------
# Self-update
# ---------------------------------------------------------------------------
# Feed (latest.json, published next to each release):
#   {"version": "0.5.1", "notes": "...",
#    "code": {"url": ".../lanlens-code-0.5.1.zip", "sha256": "...", "min_shell": 1},
#    "app":  {"url": ".../LanLens-0_5_1-mac.zip", "sha256": "..."},          (optional)
#    "sig":  "<Ed25519 signature of everything above>"}
# A code-only update replaces just the LanLens code (kept in Application
# Support), so the app macOS approved never changes and nothing asks again.
# The full app is only replaced when the launcher/runtime itself changes.
DEFAULT_FEED = "koohrang/lanlens-release"   # can also be changed in Settings
# "owner/repo" means: latest.json at the top of that GitHub repository (files stored in the repo itself)


def normalize_feed(v: str | None) -> str | None:
    v = (v or "").strip()
    if not v:
        return None
    if re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", v):
        return f"https://raw.githubusercontent.com/{v}/main/latest.json"
    m = re.fullmatch(r"https://github\.com/([A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+?)(?:\.git|/)?", v)
    if m:
        return f"https://raw.githubusercontent.com/{m.group(1)}/main/latest.json"
    if v.startswith(("https://", "http://127.0.0.1", "http://localhost")):
        return v
    return None


def feed_url(setting: str | None = None) -> str | None:
    if os.environ.get("LANLENS_UPDATE_FEED"):
        return os.environ["LANLENS_UPDATE_FEED"]
    if normalize_feed(setting):
        return normalize_feed(setting)
    app = app_path()
    if app and (app / "Contents" / "Info.plist").exists():
        try:
            with open(app / "Contents" / "Info.plist", "rb") as fh:
                v = normalize_feed(plistlib.load(fh).get("LLUpdateFeedURL"))
                if v:
                    return v
        except Exception:
            pass
    return normalize_feed(DEFAULT_FEED)


def _vt(v: str) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", v)[:4])


def _boot():
    try:
        import lanlens_boot
        return lanlens_boot
    except Exception:
        return None


def signed_payload(feed: dict) -> bytes:
    return json.dumps({k: v for k, v in feed.items() if k != "sig"}, sort_keys=True, separators=(",", ":")).encode()


def check_update(current: str, setting: str | None = None) -> dict | None:
    url = feed_url(setting)
    if not url:
        return None
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}) if url.startswith(("http://127.", "http://localhost")) else urllib.request.ProxyHandler())
    with opener.open(url, timeout=15) as r:
        feed = json.loads(r.read(200_000))
    if not feed.get("version") or _vt(feed["version"]) <= _vt(current):
        return None
    boot = _boot()
    if not boot or not boot.verify_signature(signed_payload(feed), str(feed.get("sig") or "")):
        raise RuntimeError("The update feed isn't signed with the LanLens release key, so it was ignored.")
    shell = int(os.environ.get("LANLENS_SHELL_VERSION") or 0)
    code, app = feed.get("code") or {}, feed.get("app") or {}
    if shell and code.get("url") and code.get("sha256") and int(code.get("min_shell", 1)) <= shell:
        return {**feed, "method": "code"}
    if app.get("url") and app.get("sha256"):
        return {**feed, "method": "app"}
    return None


def team_id(app: Path) -> str | None:
    if not IS_MAC:
        return None
    r = subprocess.run(["codesign", "-dv", "--verbose=2", str(app)], capture_output=True, text=True, timeout=30)
    m = re.search(r"TeamIdentifier=(\S+)", r.stderr + r.stdout)
    return m.group(1) if m and m.group(1) != "not" else None


def _download(url: str, sha256: str, dest: Path, progress=lambda m: None) -> None:
    progress("Downloading update…")
    h = hashlib.sha256()
    with urllib.request.urlopen(url, timeout=120) as r, open(dest, "wb") as fh:
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            h.update(chunk)
            fh.write(chunk)
    if h.hexdigest().lower() != sha256.lower():
        raise RuntimeError("The download didn't match its checksum, so it wasn't installed.")


def install_code(feed: dict, progress=lambda m: None) -> Path:
    """Download a signed code-only update into LanLens's own folder. Returns that folder."""
    boot = _boot()
    if not boot:
        raise RuntimeError("This copy of LanLens can't take code-only updates; download the full app once.")
    ver = feed["version"]
    if not re.fullmatch(r"\d+(\.\d+){1,3}", ver):
        raise RuntimeError("The update has an invalid version number.")
    root = boot.code_root()
    root.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="lanlens-update-"))
    try:
        zpath = work / "code.zip"
        _download(feed["code"]["url"], feed["code"]["sha256"], zpath, progress)
        progress("Checking the update's signature…")
        part = root / f"{ver}.partial"
        shutil.rmtree(part, ignore_errors=True)
        part.mkdir()
        with zipfile.ZipFile(zpath) as zf:
            total = 0
            for info in zf.infolist():
                name = info.filename
                if name.endswith("/"):
                    continue
                rel = Path(name)
                if rel.is_absolute() or ".." in rel.parts or not (name in ("manifest.json", "manifest.sig") or name.startswith("lanlens/")):
                    raise RuntimeError("The update contains unexpected files, so it wasn't installed.")
                total += info.file_size
                if total > 50_000_000:
                    raise RuntimeError("The update is unexpectedly large, so it wasn't installed.")
                out = part / rel
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_bytes(zf.read(info))
        if boot.verify_dir(part) != ver:
            shutil.rmtree(part, ignore_errors=True)
            raise RuntimeError("The update isn't signed with the LanLens release key, so it wasn't installed.")
        progress("Installing…")
        final = root / ver
        shutil.rmtree(final, ignore_errors=True)
        part.rename(final)
        running = os.environ.get("LANLENS_CODE_DIR")
        good = sorted((d for d in root.iterdir() if d.is_dir() and d != final and (d / ".good").exists()),
                      key=lambda d: _vt(d.name))
        keep = {final, *(good[-1:])}                     # the new code + the last version that started fine
        for d in root.iterdir():
            if d.is_dir() and d not in keep and str(d) != running:
                shutil.rmtree(d, ignore_errors=True)
        return final
    finally:
        shutil.rmtree(work, ignore_errors=True)


def install_update(feed: dict, progress=lambda m: None) -> Path:
    """Install the update the feed offers. Returns the app to relaunch."""
    if feed.get("method") == "code":
        install_code(feed, progress)
        app = app_path()
        if not app:
            raise RuntimeError("Update installed. Quit and reopen LanLens to start using it.")
        return app
    app = app_path()
    if not app or not app.exists():
        raise RuntimeError("Couldn't find the running LanLens app.")
    if "AppTranslocation" in str(app):
        raise RuntimeError("Move LanLens into your Applications folder first, then update.")
    work = Path(tempfile.mkdtemp(prefix="lanlens-update-"))
    zpath = work / "update.zip"
    _download(feed["app"]["url"], feed["app"]["sha256"], zpath, progress)
    progress("Checking the new version…")
    out = work / "x"
    if IS_MAC:
        subprocess.run(["ditto", "-x", "-k", str(zpath), str(out)], check=True, timeout=300)
    else:
        with zipfile.ZipFile(zpath) as z:
            z.extractall(out)
        for p in out.rglob("*"):
            if p.parent.name == "MacOS":
                p.chmod(0o755)
    new = next(out.glob("*.app"), None)
    if not new:
        raise RuntimeError("The update didn't contain an app.")
    cur_team = team_id(app)
    if cur_team:
        r = subprocess.run(["codesign", "--verify", "--deep", "--strict", str(new)], capture_output=True, timeout=120)
        if r.returncode != 0 or team_id(new) != cur_team:
            raise RuntimeError("The update isn't signed by the same developer, so it wasn't installed.")
    progress("Installing…")
    backup = app.with_name(app.name + ".old")
    if backup.exists():
        shutil.rmtree(backup, ignore_errors=True)
    app.rename(backup)
    try:
        shutil.move(str(new), str(app))
    except Exception:
        backup.rename(app)
        raise
    shutil.rmtree(backup, ignore_errors=True)
    shutil.rmtree(work, ignore_errors=True)
    return app


def relaunch_later(app: Path) -> None:
    """Start the new version a moment after this process exits."""
    if IS_MAC:
        subprocess.Popen(["/bin/sh", "-c", f"sleep 2; open -n '{app}'"], start_new_session=True)
    else:
        subprocess.Popen(["/bin/sh", "-c", f"sleep 2; '{app}/Contents/MacOS/LanLens' >/dev/null 2>&1"], start_new_session=True)


# ---------------------------------------------------------------------------
# Menu-bar icon (separate process so a problem there can never stop the app)
# ---------------------------------------------------------------------------
def start_menubar() -> subprocess.Popen | None:
    if not IS_MAC or os.environ.get("LANLENS_NO_MENUBAR"):
        return None
    try:
        import rumps  # noqa: F401
    except Exception as exc:
        logging.info("menu bar unavailable: %s", exc)
        return None
    import sys
    log = Path.home() / "Library" / "Logs" / "LanLens" / "menubar.log"
    log.parent.mkdir(parents=True, exist_ok=True)
    return subprocess.Popen([sys.executable, "-m", "lanlens.menubar"], stdout=open(log, "a"), stderr=subprocess.STDOUT,
                            start_new_session=False)
