"""'Ask your network': plain-English questions about your devices, health and Mac.

Two engines:
  * Built-in (default, offline): understands common questions -- what's new,
    what's offline, what needs attention, where is X plugged in, outages, speed...
  * Claude (optional): with your own Anthropic API key, any question is answered
    by Claude using a compact summary of what LanLens knows. Only that summary is
    sent -- never passwords.
"""
from __future__ import annotations

import datetime as _dt
import json
import re
import urllib.request

from .classify import CATEGORY_LABEL

import os

API = os.environ.get("LANLENS_ANTHROPIC_API", "https://api.anthropic.com/v1")


# ---------------------------------------------------------------------------
# Time phrases
# ---------------------------------------------------------------------------
WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]


def parse_since(q: str, now: _dt.datetime | None = None) -> tuple[_dt.datetime | None, str]:
    now = now or _dt.datetime.now()
    q = q.lower()
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    if "last night" in q or "overnight" in q:
        return (today - _dt.timedelta(hours=4)) if now.hour >= 6 else (today - _dt.timedelta(hours=4)), "since last night"
    if "today" in q or "this morning" in q:
        return today, "today"
    if "yesterday" in q:
        return today - _dt.timedelta(days=1), "since yesterday"
    if "this week" in q:
        return today - _dt.timedelta(days=today.weekday()), "this week"
    m = re.search(r"(?:last|past)\s+(\d+)\s*(minute|min|hour|hr|day|week)s?", q)
    if m:
        n, unit = int(m.group(1)), m.group(2)
        delta = {"minute": _dt.timedelta(minutes=n), "min": _dt.timedelta(minutes=n), "hour": _dt.timedelta(hours=n),
                 "hr": _dt.timedelta(hours=n), "day": _dt.timedelta(days=n), "week": _dt.timedelta(weeks=n)}[unit]
        return now - delta, f"in the last {n} {unit}{'s' if n != 1 else ''}"
    if re.search(r"last (hour)", q):
        return now - _dt.timedelta(hours=1), "in the last hour"
    if re.search(r"last week|past week", q):
        return now - _dt.timedelta(days=7), "in the last week"
    for i, day in enumerate(WEEKDAYS):
        if f"since {day}" in q or f"on {day}" in q or (day in q and "since" in q):
            back = (today.weekday() - i) % 7 or 7
            return today - _dt.timedelta(days=back), f"since {day.title()}"
    return None, ""


def _name(d: dict) -> str:
    return d.get("name") or d.get("vendor") or d.get("ip") or "unnamed device"


def _when(iso: str | None) -> str:
    if not iso:
        return "unknown time"
    t = _dt.datetime.fromisoformat(iso)
    return t.strftime("%a %-I:%M %p") if hasattr(t, "strftime") else iso


def _list(devs: list[dict], limit: int = 12, extra=lambda d: "") -> str:
    lines = [f"• {_name(d)} — {d['type']} ({d['ip']}){extra(d)}" for d in devs[:limit]]
    if len(devs) > limit:
        lines.append(f"…and {len(devs) - limit} more")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Built-in engine
# ---------------------------------------------------------------------------
CAT_WORDS = {
    "iot": r"iot|smart ?home|smart devices?|cameras?|plugs?|bulbs?|lights?|thermostats?|doorbells?|speakers?",
    "mobile": r"phones?|mobiles?|ipads?|tablets?|iphones?|androids?",
    "computer": r"computers?|laptops?|pcs?|macs?|desktops?",
    "media": r"tvs?|televisions?|media|streamers?|consoles?|xbox|playstation|roku|chromecast|sonos",
    "printer": r"printers?|scanners?",
    "server": r"servers?|nas|storage",
    "network": r"routers?|switch(es)?|access points?|aps?|network gear|wi-?fi points?",
    "unknown": r"unknowns?|unidentified|mystery",
}


def local_answer(q: str, ctx: dict) -> dict:
    """Return {"answer", "devices": [keys], "engine": "built-in"} or answer=None if not understood."""
    ql = q.lower().strip()
    devs = ctx.get("devices", [])
    online = [d for d in devs if d.get("online")]
    since, phrase = parse_since(ql)
    out = lambda text, ds=(): {"answer": text, "devices": [d["key"] for d in ds], "engine": "built-in"}

    # where is X plugged in / connected
    m = re.search(r"where(?:'s| is)\s+(?:my\s+|the\s+)?(.+?)\s*(?:plugged|connected|attached|located)?\s*(?:in(?:to)?)?\??$", ql)
    if m and ("plugged" in ql or "connected" in ql or "port" in ql or "switch" in ql):
        target = _find(m.group(1), devs)
        if target:
            at = (ctx.get("topology") or {}).get("placed", {}).get(target["key"])
            if at:
                via = next((x for x in devs if x["key"] == at.get("via")), None)
                where = f"Wi-Fi through {_name(via)}, which is on {at['switch']} port {at['port']}" if via \
                    else f"{at['switch']} port {at['port']}" + (f" (VLAN {at['vlan']})" if at.get("vlan") else "")
                return out(f"{_name(target)} is connected to {where}.", [target])
            if ctx.get("topology"):
                return out(f"The switches didn't list {_name(target)}'s address in their tables. It may be on Wi-Fi "
                           f"behind an access point that LanLens didn't log in to.", [target])
            return out("To see switch ports, map your network gear first (Map tab → Wired topology).", [target])

    if re.search(r"\b(new|joined|appeared|connected for the first time|showed up)\b", ql):
        first = ctx.get("first_scan")
        lst = [d for d in devs if d.get("first_seen") and (since is None and d.get("new")
                                                            or since and d["first_seen"] >= since.isoformat())]
        if first and since and since.isoformat() <= first:
            lst = [d for d in lst if d["first_seen"] > first]
            if not lst:
                return out(f"LanLens started watching this network at {_when(first)}, and nothing new has joined since then.")
            return out(f"LanLens started watching at {_when(first)}. Since then {len(lst)} device{'s' if len(lst) != 1 else ''} joined:\n"
                       + _list(lst, extra=lambda d: f", first seen {_when(d['first_seen'])}"), lst)
        if since is None and not lst:
            lst = [d for d in devs if d.get("new")]
        if not lst:
            return out(f"No new devices {phrase or 'since your last scan'}.")
        return out(f"{len(lst)} new device{'s' if len(lst) != 1 else ''} {phrase or 'since your last scan'}:\n"
                   + _list(lst, extra=lambda d: f", first seen {_when(d['first_seen'])}"), lst)

    if re.search(r"\b(offline|left|disappeared|missing|gone|not online|went away|dropped)\b", ql):
        lst = [d for d in devs if not d.get("online")]
        if since:
            lst = [d for d in lst if d.get("last_seen") and d["last_seen"] >= since.isoformat()]
        if not lst:
            return out(f"Nothing went offline {phrase}." if phrase else "Every device LanLens knows about is online.")
        return out(f"{len(lst)} device{'s are' if len(lst) != 1 else ' is'} offline:\n"
                   + _list(lst, extra=lambda d: f", last seen {_when(d['last_seen'])}"), lst)

    if re.search(r"\b(changed|change|different|happened)\b", ql):
        s = since or (_dt.datetime.now() - _dt.timedelta(days=1))
        new = [d for d in devs if d.get("first_seen") and d["first_seen"] >= s.isoformat()]
        gone = [d for d in devs if not d.get("online") and d.get("last_seen") and d["last_seen"] >= s.isoformat()]
        outs = [o for o in (ctx.get("health") or {}).get("outages", []) if (o.get("end") or "9") >= s.isoformat()]
        parts = [f"Since {s.strftime('%a %-I:%M %p')}:"]
        parts.append(f"• {len(new)} new device{'s' if len(new) != 1 else ''}" + (": " + ", ".join(_name(d) for d in new[:6]) if new else ""))
        parts.append(f"• {len(gone)} went offline" + (": " + ", ".join(_name(d) for d in gone[:6]) if gone else ""))
        parts.append(f"• {len(outs)} internet outage{'s' if len(outs) != 1 else ''}")
        return out("\n".join(parts), new + gone)

    if re.search(r"\b(risk|risky|danger|attention|warning|secure|safe|vulnerab|flag|worry|worried|look at)\b", ql) \
            and not re.search(r"\bmac\b|this computer|my laptop", ql):
        lst = [d for d in online if d.get("notes")]
        if not lst:
            return out("Nothing on the network is flagged right now.")
        return out(f"{len(lst)} device{'s' if len(lst) != 1 else ''} worth a look:\n"
                   + "\n".join(f"• {_name(d)} ({d['ip']}): {'; '.join(d['notes'])}" for d in lst[:12]), lst)

    if re.search(r"(outage|internet (down|drop|out|cut)|went down|disconnect|connection drop)", ql):
        h = ctx.get("health") or {}
        outs = h.get("outages", [])
        if since:
            outs = [o for o in outs if (o.get("end") or "9") >= since.isoformat()]
        if not h.get("samples"):
            return out("LanLens hasn't been monitoring long enough yet. Leave it running (or turn on Start at login).")
        if not outs:
            return out(f"No outages {phrase or 'in the last 24 hours'}. Uptime: {h.get('uptime_pct')}%.")
        lines = [f"• {o['kind']}: {_when(o['start'])} → {_when(o['end']) if o.get('end') else 'ongoing'}" for o in outs[-10:]]
        return out(f"{len(outs)} outage{'s' if len(outs) != 1 else ''} {phrase or 'in the last 24 hours'}:\n" + "\n".join(lines))

    if re.search(r"\b(speed|fast|slow|bandwidth|mbps)\b", ql):
        st = (ctx.get("health") or {}).get("speedtests", [])
        if not st:
            return out("No speed test yet. Open the Health tab and click “Run speed test”.")
        last = st[-1]
        return out(f"Last speed test ({_when(last['time'])}): {last.get('down_mbps')} Mbps down, "
                   f"{last.get('up_mbps')} Mbps up, {last.get('latency_ms')} ms latency.")

    if re.search(r"wi-?fi|signal", ql):
        w = (ctx.get("health") or {}).get("wifi_now")
        if not w:
            return out("No Wi-Fi reading yet (or this Mac is on Ethernet).")
        if w.get("wired"):
            return out("This Mac is connected by Ethernet, not Wi-Fi.")
        from .health import signal_quality
        return out(f"Wi-Fi signal is {signal_quality(w.get('rssi'))} ({w.get('rssi')} dBm, noise {w.get('noise')} dBm) "
                   f"on {w.get('band') or 'channel ' + str(w.get('channel'))}, link rate {w.get('rate')} Mbps.")

    if re.search(r"\bmac\b|this computer|my laptop|update|apps?\b", ql) and ctx.get("mac"):
        mac = ctx["mac"]
        bad = [c["name"] for c in mac.get("security", []) if c.get("ok") is False]
        outd = [a["name"] for a in mac.get("apps", []) if a.get("outdated")]
        expl = [a["name"] for a in mac.get("apps", []) if a.get("outdated") and a.get("kev_count")]
        parts = [f"Security settings: {'all good' if not bad else 'needs attention — ' + ', '.join(bad)}."]
        parts.append(f"Apps with updates: {len(outd)}" + (f" ({', '.join(outd[:8])})" if outd else "") + ".")
        if expl:
            parts.append(f"Update first: {', '.join(expl)} (actively exploited flaws on record).")
        return out(" ".join(parts))

    for cat, pat in CAT_WORDS.items():
        if re.search(rf"\b({pat})\b", ql) and re.search(r"how many|which|list|show|what|any", ql):
            lst = [d for d in online if d.get("category") == cat]
            label = CATEGORY_LABEL[cat]
            if not lst:
                return out(f"No {label.lower()} devices online right now.")
            return out(f"{len(lst)} {label} device{'s' if len(lst) != 1 else ''} online:\n" + _list(lst, 20), lst)

    if re.search(r"how many( devices)?|count|total", ql):
        cats = {}
        for d in online:
            cats[d["category"]] = cats.get(d["category"], 0) + 1
        return out(f"{len(online)} devices online ({len(devs) - len(online)} offline). "
                   + ", ".join(f"{n} {CATEGORY_LABEL[c]}" for c, n in sorted(cats.items(), key=lambda kv: -kv[1])) + ".")

    m = re.search(r"(?:what|who) is (?:this |the |my )?(.+?)\??$", ql) or re.search(r"(?:tell me about|info on|details for) (.+?)\??$", ql)
    if m:
        target = _find(m.group(1), devs)
        if target:
            d = target
            bits = [f"{_name(d)} is a {d['type']} ({CATEGORY_LABEL.get(d['category'], '')})",
                    f"IP {d['ip']}", f"made by {d['vendor']}" if d.get("vendor") else "",
                    "online now" if d.get("online") else f"offline since {_when(d.get('last_seen'))}",
                    f"first seen {_when(d.get('first_seen'))}"]
            why = "; ".join(d.get("reasons", [])[:3])
            return out(", ".join(b for b in bits if b) + (f". Identified because: {why}." if why else "."), [d])
    return {"answer": None, "devices": [], "engine": "built-in"}


def _find(text: str, devs: list[dict]) -> dict | None:
    t = re.sub(r"[^a-z0-9.:\- ']", "", text.lower()).strip()
    if not t:
        return None
    for d in devs:
        if t in (d.get("ip") or "", (d.get("mac") or "")):
            return d
    best, score = None, 0
    words = [w for w in re.split(r"[\s'’-]+", t) if len(w) > 1 and w not in ("the", "my", "a", "an", "device", "s")]
    for d in devs:
        hay = " ".join(filter(None, [d.get("name"), d.get("type"), d.get("vendor"), d.get("model"), *d.get("hostnames", [])])).lower()
        hay = hay + " " + re.sub(r"[\s'’-]+", "", hay)
        s = sum(1 for w in words if w in hay)
        if s > score:
            best, score = d, s
    return best


# ---------------------------------------------------------------------------
# Claude engine (optional, user's own API key)
# ---------------------------------------------------------------------------
_MODEL_CACHE: dict[str, str] = {}


def _api(path: str, key: str, body: dict | None = None, timeout: float = 60):
    req = urllib.request.Request(f"{API}{path}", data=json.dumps(body).encode() if body else None,
                                 method="POST" if body else "GET",
                                 headers={"x-api-key": key, "anthropic-version": "2023-06-01",
                                          "content-type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())


def pick_model(key: str) -> str:
    if key in _MODEL_CACHE:
        return _MODEL_CACHE[key]
    models = [m["id"] for m in _api("/models?limit=50", key).get("data", [])]   # newest first
    choice = next((m for m in models if "sonnet" in m), None) or next((m for m in models if "haiku" in m), None) \
        or (models[0] if models else None)
    if not choice:
        raise RuntimeError("No Claude models are available for this API key.")
    _MODEL_CACHE[key] = choice
    return choice


def compact_context(ctx: dict) -> str:
    devs = [{k: d.get(k) for k in ("name", "type", "category", "ip", "mac", "vendor", "model", "online", "first_seen",
                                   "last_seen", "new", "trusted", "notes", "user_notes")} for d in ctx.get("devices", [])]
    topo = ctx.get("topology") or {}
    keymap = {d["key"]: (d.get("name") or d.get("ip")) for d in ctx.get("devices", [])}
    placed = {keymap.get(k, k): f"{v['switch']} {v['port']}" + (f" via {keymap.get(v['via'], v['via'])}" if v.get("via") else "")
              for k, v in (topo.get("placed") or {}).items()}
    h = ctx.get("health") or {}
    mac = ctx.get("mac") or {}
    data = {
        "now": _dt.datetime.now().isoformat(timespec="minutes"), "network": ctx.get("network"), "devices": devs,
        "switch_ports": placed, "gear_findings": [f["title"] for f in topo.get("findings", [])][:15],
        "health": {"uptime_pct_24h": h.get("uptime_pct"), "outages": h.get("outages", [])[-20:],
                   "latest_speedtests": h.get("speedtests", [])[-5:], "wifi_now": h.get("wifi_now"),
                   "median_internet_ms": h.get("inet_median"), "median_router_ms": h.get("gw_median")},
        "internet": {k: (ctx.get("internet") or {}).get(k) for k in ("public", "nat", "dns")} if ctx.get("internet") else None,
        "router_upnp": {k: ((ctx.get("internet") or {}).get("router") or {}).get(k) for k in ("model", "wan_ip", "uptime_s", "forwards")}
        if ctx.get("internet") else None,
        "security": {k: (ctx.get("security") or {}).get(k) for k in ("score", "grade", "findings", "passed", "time")}
        if ctx.get("security") else None,
        "this_mac": {"system": mac.get("system"), "security": mac.get("security"),
                     "apps_needing_attention": [{k: a.get(k) for k in ("name", "version", "latest", "kev_count", "unsigned")}
                                                for a in mac.get("apps", []) if a.get("outdated") or a.get("kev_count") or a.get("unsigned")][:40]}
        if mac else None,
    }
    return json.dumps(data, default=str)[:180_000]


SYSTEM = ("You are LanLens, a friendly home/office network assistant built by network people. Answer the user's question "
          "using ONLY the JSON snapshot provided (devices on their network, switch ports, health history, and their Mac). "
          "Be concise and concrete: name devices, IPs, times. If the data doesn't contain the answer, say so and suggest "
          "what in LanLens would reveal it (e.g. run a speed test, map network gear, keep watching). Plain text, short "
          "bullet points when listing. Never invent devices.")


def claude_answer(q: str, ctx: dict, key: str, history: list[dict] | None = None) -> dict:
    model = pick_model(key)
    msgs = list(history or [])[-6:]
    msgs.append({"role": "user", "content": f"<snapshot>{compact_context(ctx)}</snapshot>\n\nQuestion: {q}"})
    r = _api("/messages", key, {"model": model, "max_tokens": 900, "system": SYSTEM, "messages": msgs})
    text = "".join(b.get("text", "") for b in r.get("content", []) if b.get("type") == "text").strip()
    keys = [d["key"] for d in ctx.get("devices", []) if d.get("name") and d["name"] in text][:20]
    return {"answer": text or "(no answer)", "devices": keys, "engine": f"Claude ({model})"}


def answer(q: str, ctx: dict, key: str | None = None, prefer_claude: bool = True) -> dict:
    if key and prefer_claude:
        try:
            return claude_answer(q, ctx, key)
        except Exception as exc:
            res = local_answer(q, ctx)
            res["note"] = f"Claude wasn't reachable ({str(exc)[:80]}), so this is the built-in answer."
            if res["answer"]:
                return res
            return {"answer": f"Claude wasn't reachable: {str(exc)[:120]}", "devices": [], "engine": "error"}
    res = local_answer(q, ctx)
    if res["answer"] is None:
        res["answer"] = ("I can answer things like: “what's new since last night?”, “what's offline?”, "
                         "“anything risky?”, “where is the printer plugged in?”, “any outages today?”, "
                         "“how fast is my internet?”, “how many cameras?”, “what is 192.168.1.43?”. "
                         "Add your Anthropic API key in Settings to ask anything.")
    return res
